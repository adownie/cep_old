startList = function() {
if (document.all&&document.getElementById) {
navRoot = document.getElementById("header-navigation");
for (i=0; i<navRoot.childNodes.length; i++) {
node = navRoot.childNodes[i];
if (node.nodeName=="LI") {
node.onmouseover=function() {
this.className+=" hover";
  }
  node.onmouseout=function() {
  this.className=this.className.replace(" hover", "");
   }
   }
  }
 }
}
window.onload=startList;