<?php
include '../../../../../wp-blog-header.php';
headway_gzip();
header("content-type: application/x-javascript");

$id = $_GET['id'];

$leaf_order = get_post_meta($id, '_leafs', true);						// Get Leaf Order
if(!$leaf_order) $leaf_order = get_option('system-page-'.$id.'-leafs');

if($leaf_order != NULL){												    // If the leaf order custom field is not empty.  If this is not here it'll throw some nasty errors.
	foreach($leaf_order as $leaf){										// Start foreach loop for every leaf/box.
		$leaf_config = get_post_meta($id, '_'.$leaf, true);
		$item_options = get_post_meta($id, '_'.$leaf.'_options', true);
		
		if(!$leaf_config) $leaf_config = get_option('system-page-'.$id.'-'.$leaf);
		if(!$item_options) $item_options = get_option('system-page-'.$id.'-'.$leaf.'_options');
		
		$item_options = db_to_leaf($item_options);
?>
<?php if($leaf_config[0] == 'featured'): ?>
	<?php if($item_options['rotate_posts'] == 'on'): ?>
	jQuery(function(){
		jQuery('#<?php echo $leaf?> div.featured-leaf-content').cycle({ 
		    fx:      '<?php echo $item_options['animation_type']?>', 
			<?php if($item_options['rotate_nav_location'] == 'inside'): ?>
			prev: '.<?php echo $leaf ?>_featured_prev',
			next: '.<?php echo $leaf ?>_featured_next',
			<?php elseif($item_options['rotate_nav_location'] == 'outside'): ?>
			prev: '#<?php echo $leaf ?>_featured_prev',
			next: '#<?php echo $leaf ?>_featured_next',
			<?php endif; ?>
		    speed:    <?php echo $item_options['animation_speed']*1000?>, 
		    timeout:  <?php echo $item_options['animation_timeout']*1000?> 
		});
	});
	<?php endif; ?>
<?php endif; ?>
<?php if($leaf_config[0] == 'rotator'): ?>
	jQuery(function(){
		jQuery('#<?php echo $leaf?> div.rotator-images').cycle({ 
		    fx:      '<?php echo $item_options['animation_type']?>', 
		    speed:    <?php echo $item_options['animation_speed']*1000?>, 
		    timeout:  <?php echo $item_options['animation_timeout']*1000?> 
		});
	});
<?php endif; ?>
<?php if($leaf_config[0] == 'content-slider'): ?>
	
	
	jQuery(function(){
	    jQuery("#<?php echo $leaf?> div.leaf-content div.content-slider-controller").jFlow({
			slides: "#content-slider-slides-<?php echo $leaf ?>",
			controller: ".jFlowControl",
			slideWrapper : "#content-slider-container-<?php echo $leaf ?>",
			selectedWrapper: "jFlowSelected",
			width: "<?php echo $leaf_config[2]-20 ?>px",
			height: "<?php echo $leaf_config[3]-20 ?>px",
			duration: <?php echo $item_options['animation_speed']*1000?>,
			prev: ".jFlowPrev",
			next: ".jFlowNext"
	    });
	});
	
	
	
<? endif; ?>

<?php 
}
}
?>