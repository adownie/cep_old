<?
include '../../../../../wp-blog-header.php';
headway_gzip();
header("Content-type: text/css");
?>
body {
	<? if(color('background')){ ?>background: #<?php echo color('background') ?>;<? } ?>
}
a:link, a:visited {
	<? if(color('default-hyperlink')){ ?>color: #<?php echo color('default-hyperlink') ?>;<? } ?>
}
div#wrapper {
	<? if(color('wrapper-border') && color('wrapper-border') != 'none'){ ?>border-color: #<?php echo color('wrapper-border') ?>;<? } ?>
	<? if(color('wrapper-border') == 'none'){ ?>border: none;<? } ?>
}
body.header-inside div#header, body.header-outside div#header-container {
	<? if(color('header-background')){ ?>background: #<?php echo color('header-background') ?>;<? } ?>
	<? if(color('header-bottom-border') && color('header-bottom-border') != 'none'){ ?>border-bottom:1px solid #<?php echo color('header-bottom-border') ?>;<? } ?>
	<? if(color('header-bottom-border') == 'none'){ ?>border-bottom: none;<? } ?>
}
div.header-link-top a.header-link-text-inside:link, div#top a.header-link-text-inside:visited {
	<? if(color('header-link')){ ?>color: #<?php echo color('header-link') ?>;<? } ?>
	<? if(color('header-link-underline') && color('header-link-underline') != 'none' && get_option('show_tagline')){ ?>border-bottom:1px solid #<?php echo color('header-link-underline') ?>;<? } ?>
	<? if(color('header-link-underline') == 'none' || !get_option('show_tagline')){ ?>border-bottom: none;<? } ?>
}
h1#tagline {
	<? if(color('header-tagline')){ ?>color: #<?php echo color('header-tagline') ?>;<? } ?>
}
body.header-inside div#navigation, body.header-outside div#navigation-container {
	<? if(color('navigation-background')){ ?>background: #<?php echo color('navigation-background') ?>;<? } ?>
	<? if(color('navigation-bottom-border') && color('navigation-bottom-border') != 'none'){ ?>border-bottom:1px solid #<?php echo color('navigation-bottom-border') ?>;<? } ?>
	<? if(color('navigation-bottom-border') == 'none'){ ?>border-bottom: none;<? } ?>
}
ul.navigation li.page-parent.hover a, ul.navigation li.page-parent:hover a {
	<? if(color('navigation-bottom-border') == 'none'){ ?>border-bottom: none;<? } ?>
}
ul.navigation li a:link, ul.navigation li a:visited, ul.navigation li ul li a:link, ul.navigation li ul li a:visited, ul.navigation li.page-parent a:link, ul.navigation li.page-parent a:visited {
	<? if(color('navigation-link-color')){ ?>color: #<?php echo color('navigation-link-color') ?>;<? } ?>	
	<? if(color('navigation-background')){ ?>background: #<?php echo color('navigation-background') ?>;<? } ?>
	<? if(color('navigation-link-border') && color('navigation-link-border') != 'none'){ ?>border-right:1px solid #<?php echo color('navigation-link-border') ?>;<? } ?>
	<? if(color('navigation-link-border') == 'none'){ ?>border: none;<? } ?>
}
ul.navigation li ul {
	<? if(color('navigation-background')){ ?>background: #<?php echo color('navigation-background') ?>;<? } ?>
}
ul.navigation li ul li a:link, ul.navigation li ul li a:visited, ul.navigation li ul li a.current-page-item:link, ul.navigation li ul li a.current-page-item:visited {
	border-right: none;
	background: none;
}
ul.navigation li.current-page-item ul, ul.navigation li.current-page-parent ul { 
	<? if(color('navigation-background')){ ?>background: #<?php echo color('navigation-background') ?>;<? } ?>
}
.header-outside ul.navigation, ul.navigation li ul {
	<? if(color('navigation-link-border')){ ?>border-color: #<?php echo color('navigation-link-border') ?>;<? } ?>
	<? if(color('navigation-link-border') && color('navigation-link-border') != 'none'){ ?>border-color: #<?php echo color('navigation-link-border') ?>;<? } ?>
	<? if(color('navigation-link-border') == 'none'){ ?>border: none;<? } ?>
}
<? if(color('navigation-link-border') == 'none'){ ?>
body.header-outside ul.navigation {
	margin: 0;
}
<? } ?>
ul.navigation li.current-page-item a:link, 
ul.navigation li.current-page-item a:visited, 
ul.navigation li.current-page-item a:hover, 
ul.navigation li.current-page-parent a:link, 
ul.navigation li.current-page-parent a:visited, 
ul.navigation li.current-page-parent a:hover, 
ul.navigation li ul li.current-page-item a:link, 
ul.navigation li ul li.current-page-item a:visited, 
ul.navigation li ul li.current-page-item a:hover, 
ul.navigation li.current-page-item ul li a:link, 
ul.navigation li.current-page-parent ul li a:link, 
ul.navigation li.current-page-item ul li a:visited, 
ul.navigation li.current-page-parent ul li a:visited{
	<? if(color('navigation-link-color-active')){ ?>color: #<?php echo color('navigation-link-color-active') ?>;<? } ?>
	<? if(color('navigation-link-background-active')){ ?>background: #<?php echo color('navigation-link-background-active') ?>;<? } ?>
}
ul.navigation li.page-parent ul li a, ul.navigation li.page-parent.hover ul li a, ul.navigation li.page-parent:hover ul li a {
	<? if(color('navigation-link-border') == 'none'){ ?>
		border: none;
		margin: 0 0 0 1px;
	<? } ?>
}
body.header-inside div#breadcrumbs, body.header-outside div#breadcrumbs-container {
	<? if(color('breadcrumbs-background')){ ?>background: #<?php echo color('breadcrumbs-background') ?>;<? } ?>
	<? if(color('breadcrumbs-color')){ ?>color: #<?php echo color('breadcrumbs-color') ?>;<? } ?>	
	<? if(color('breadcrumbs-bottom-border') && color('breadcrumbs-bottom-border') != 'none'){ ?>border-bottom:1px solid #<?php echo color('breadcrumbs-bottom-border') ?>;<? } ?>
	<? if(color('breadcrumbs-bottom-border') == 'none'){ ?>border-bottom: none;<? } ?>
}
div#breadcrumbs a {
	<? if(color('breadcrumbs-hyperlink-color')){ ?>color: #<?php echo color('breadcrumbs-hyperlink-color') ?>;<? } ?>
}
.entry-title, .entry-title a, .page-title {
	<? if(color('post-title')){ ?>color: #<?php echo color('post-title') ?>;<? } ?>
}
.entry-title a:hover {
	<? if(color('post-title-hover')){ ?>color: #<?php echo color('post-title-hover') ?>;<? } ?>
}
.entry-content {
	<? if(color('post-content')){ ?>color: #<?php echo color('post-content') ?>;<? } ?>
}
.entry-content a:link, .entry-content a:visited {
	<? if(color('post-hyperlink')){ ?>color: #<?php echo color('post-hyperlink') ?>;<? } ?>
}
.entry-content h2 {
	<? if(color('post-content-h2')){ ?>color: #<?php echo color('post-content-h2') ?>;<? } ?>
}
.entry-content h3 {
	<? if(color('post-content-h3')){ ?>color: #<?php echo color('post-content-h3') ?>;<? } ?>
}
.entry-content h4 {
	<? if(color('post-content-h4')){ ?>color: #<?php echo color('post-content-h4') ?>;<? } ?>
}
.entry-meta {
	<? if(color('post-meta')){ ?>color: #<?php echo color('post-meta') ?>;<? } ?>
}
.entry-meta a{
	<? if(color('post-meta-hyperlink')){ ?>color: #<?php echo color('post-meta-hyperlink') ?>;<? } ?>
}
div.box div.leaf-top {
	<? if(color('leaf-title')){ ?>color: #<?php echo color('leaf-title') ?>;<? } ?>
	<? if(color('leaf-title-underline')){ ?>border-bottom-color: #<?php echo color('leaf-title-underline') ?>;<? } ?>
}
div.box div.leaf-top a {
	<? if(color('leaf-title-hyperlink')){ ?>color: #<?php echo color('leaf-title-hyperlink') ?>;<? } ?>
}
div.box div.leaf-content {
	<? if(color('leaf-content')){ ?>color: #<?php echo color('leaf-content') ?>;<? } ?>
}
span.widget-title {
	<? if(color('widget-title')){ ?>color: #<?php echo color('widget-title') ?>;<? } ?>
}
div.sidebar {
	<? if(color('sidebar-bg')){ ?>background: #<?php echo color('sidebar-bg') ?>;<? } ?>
}
div.sidebar a {
	<? if(color('sidebar-hyperlinks')){ ?>color: #<?php echo color('sidebar-hyperlinks') ?>;<? } ?>
}
div#footer {
	<? if(color('footer-top-border')){ ?>border-top-color: #<?php echo color('footer-top-border') ?>;<? } ?>
	<? if(color('footer-bg')){ ?>background: #<?php echo color('footer-bg') ?>;<? } ?>
}
div.post, div.small-post, div.small-excerpts-row {
	<? if(color('post-bottom-border')){ ?>border-bottom-color: #<?php echo color('post-bottom-border') ?>;<? } ?>
}