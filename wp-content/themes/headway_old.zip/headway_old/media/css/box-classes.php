<?php 
include '../../../../../wp-blog-header.php';
headway_gzip();
header("Content-type: text/css"); 


$id = $_GET['id'];

$leaf_order = get_post_meta($id, '_leafs', true);						// Get Leaf Order
if(!$leaf_order) $leaf_order = get_option('system-page-'.$id.'-leafs');

if($leaf_order != NULL){												    // If the leaf order custom field is not empty.  If this is not here it'll throw some nasty errors.
	foreach($leaf_order as $leaf){										// Start foreach loop for every leaf/box.
		$leaf_config = get_post_meta($id, '_'.$leaf, true);
		$item_options = get_post_meta($id, '_'.$leaf.'_options', true);
		
		if(!$leaf_config) $leaf_config = get_option('system-page-'.$id.'-'.$leaf);
		if(!$item_options) $item_options = get_option('system-page-'.$id.'-'.$leaf.'_options');
		
		$item_options = db_to_leaf($item_options);

		if($item_options['no-padding']){
			$leaf_config[2] = $leaf_config[2] + 18;
			$leaf_config[3] = $leaf_config[3] + 18;
			$no_padding[$leaf] = 'padding: 0;';
		}
?>
#<?php echo $leaf?> {
	width: <?php echo $leaf_config[2]?>px;
	height: <?php echo $leaf_config[3]?>px;
	<?php echo $no_padding[$leaf]; ?>
}

<? 
	}
}
?>