<?php 
include '../../../../../wp-blog-header.php';
headway_gzip();
header("Content-type: text/css"); 
?>

div#wrapper														{ margin:<?php echo get_option('wrapper-margin')?>px auto; width:<?php echo get_option('wrapper-width')?>px; clear:both; border: 1px solid #333; }
div#container 													{ width:<?php echo get_option('wrapper-width')?>px; }
.header-outside div#wrapper										{ border-width: 0 1px 1px 1px; margin: 0 auto; }
                                              
#header-container 							  					{ width: 100%; border-bottom: 1px solid #888; float:left; }                            
#header 									  					{ margin: 0 auto; width:<?php echo get_option('wrapper-width')?>px; clear: both; float: left; }                            
.header-inside #header 						  					{ border-bottom: 1px solid #888; }                            
.header-outside #header 					  					{ float: none; }                            
                                                                             
	div.header-link-top						  					{ font-size: 3.4em; margin: 10px 0 5px 10px; }  
	div.header-link-top a.header-link-text-inside				{ color: #333; }                      
	div.header-link-image										{ margin: <?php echo (get_option('header-image-margin') || get_option('header-image-margin') == '0') ? get_option('header-image-margin') : '15px'; ?>; }
	a.header-link-image-inside									{ float: left; margin: 0; }    
	a.header-link-image-inside img								{ float: left; }    
	h1#tagline 								  					{ font-size: 2em; margin: 0 0 10px 10px; color: #777; }                            
	                                                                                                                                               
	                                                                         
                                                                             
#navigation-container 						  					{ border-bottom: 1px solid #888; float: left; width: 100%; }                            
#navigation 								  					{ float: left; width:<?php echo get_option('wrapper-width')?>px; display: block; }                            
.header-inside #navigation 					  					{ border-bottom: 1px solid #888; }                            
.header-outside #navigation					  					{ float: none; margin: 0 auto; }                            
                                                                             
	ul.navigation 							  					{ margin: 0; padding: 0; list-style: none; float: left;position: relative;z-index: 100; }      
	.header-outside ul.navigation								{ border-left: 1px solid #888; margin: 0 0 0 -1px; position: relative;z-index: 100; }                      
	ul.navigation li 						  					{ float: left; list-style: none; margin: 0; position: relative; }                             
	ul.navigation li a:link, ul.navigation li a:visited			{ padding: 10px; text-decoration: none; border-right: 1px solid #666; display: inline-block; }                            
	ul.navigation li a:hover 				  					{ text-decoration: underline; }
	ul.navigation li.current-page-item a, 
	ul.navigation li.current-page-parent a	  					{ text-decoration: none; background: #eee; }
	
	ul.navigation li.current-page-parent a:hover				{ background: #eee; text-decoration: none; }
	
	
                                                                             
	ul.navigation li ul 					  					{ display: none; position: absolute; float: left; clear: left; background: #fff; padding: 0; border: 1px solid #888; border-width: 0 1px 1px 1px; z-index: 10000; margin: 0 0 0 -1px; }                   
	ul.navigation li.current-page-parent ul 					{ background: #eee; }        
	ul.navigation li.hover ul, ul.navigation li:hover ul   	 	{ display: block; }
	ul.navigation li ul li 										{ margin: 0; list-style: none; float: none; }
	ul.navigation li ul li a:visited, 
	ul.navigation li ul li a:link								{ padding: 6px 10px; border: none; width: auto; }
	ul.navigation li ul li.current-page-item a					{ text-decoration: underline; }
	ul.navigation li.current-page-parent ul li a:hover			{ text-decoration: underline; }
	ul.navigation li.current-page-item ul li a:hover			{ text-decoration: underline; }
	



#breadcrumbs-container 											{ border-bottom: 1px solid #888; clear: both; }
#breadcrumbs 													{ float: left; width:<?php echo get_option('wrapper-width')?>px; height: 25px; line-height: 25px; }
.header-inside #breadcrumbs 									{ border-bottom: 1px solid #888; }
.header-outside #breadcrumbs 									{ float: none; margin: 0 auto; }

	#breadcrumbs p 												{ padding: 0; margin: 0 10px; display: block; width:<?php echo get_option('wrapper-width')-20?>px;overflow:hidden; }



#container 														{ margin: 10px 0;}


.box 															{ float:left; width:250px; margin: 5px; background: #eee; padding: 10px 10px 0; overflow: hidden; }
.box-right														{ float: right; }
.featured-image-left 											{ float:left; }
.featured-image-right 											{ float:right; }
div.leaf-content div.featured-post-container, 
div.featured-leaf-content 										{ float:left; display: block; width: 100%; }
div.featured-entry-content										{ float: left; display: block; width: 100%; margin: -5px 0 5px; }
div.leaf-content .entry-meta 									{ display: block; clear: both; }
.fluid-height													{ height: auto !important; }


#footer 														{ clear: both; width: 100%; }


.align-left, .alignleft											{ float: left; margin: 0 7px 0 0; }
.align-right, .alignright										{ float: right; margin: 0 0 0 7px; }
.aligncenter													{ display:block; margin-left:auto; margin-right:auto; clear: both; }

.widget-title 													{ margin: 0 0 10px; display: block; }
li.widget														{ margin: 0 0 25px; }



label															{ display: block; }
input, textarea, label											{ clear: both; }
input, textarea													{ margin: 0 0 10px; }


div.post														{ display: block; }

.entry-meta .left												{ float: left; margin: 0 0 10px; }
.entry-meta .right												{ float: right; margin: 0 0 10px; }
	.meta-below-content .left,
	.meta-below-content .right,
	.meta-above-title .left,
	.meta-above-title .right									{ margin: 0; }
	
div#nav-below												    { margin: 10px 0; }

div.leaf-content div											{ display: inline; }
div.content-slider div.leaf-content div							{ display: block; }
div.feed		 div 											{ display: block; }

div.content-slider-controller									{ margin: -20px 0 0 0; }

.featured-image-left 											{ float: left; }
.featured-image-right 											{ float: right; }

div.horizontal-sidebar ul li.widget								{ float: left; margin: 0 15px 0 15px; width: 20%; }