<?
include '../../../../../wp-blog-header.php';
headway_gzip();
header("Content-type: text/css");
?>
a:hover													{text-decoration:none;}
body													{background:#414141;}
div#wrapper												{background:#fff;border-color:#222;border-width:1px 3px 3px 1px;}
#heaa:hover 											{ text-decoration: none; }

body													{ background: #414141; }
div#wrapper 											{ background: #fff; border-color: #222; border-width: 1px 3px 3px 1px; }
#header-container, 
#navigation-container,
#breadcrumbs-container      							{ background: #fff; font-size: 1.1em; } 

div.header-link-text		 							{ font-size: 3.4em; margin: 20px 0 6px 15px; float: left; }  
div.header-link-image									{ float: left; }
div.header-link-top a.header-link-text-inside:link, 
div#top a.header-link-text-inside:visited				{ color: #555; text-decoration: none; padding: 0 0 5px 0; border-bottom: 1px solid #ddd; margin: 0 0 10px; }
div.header-link-image a									{ border-bottom: none; }
div.header-link-top a.header-link-text-inside:hover		{ color: #777; }                          
h1#tagline 				 								{ font-size: 2em; margin: 0 0 20px 15px; color: #888; float: left; clear: left; }



ul.navigation 
li.page-parent.hover a,
ul.navigation 
li.page-parent:hover a									{ padding: 10px 10px 10px; z-index: 10001; position: relative; border-bottom: none; }

ul.navigation li.page-parent a							{ background: #fff; }


ul.navigation 
li.current-page-parent a,
ul.navigation 
li.current-page-item a									{ background: #eee; }

ul.navigation li ul li.current-page-item a:link, 
ul.navigation li ul li.current-page-item a:visited 		{ text-decoration: underline; }




ul.navigation li ul 									{ border-width: 1px; z-index: 10002; margin-top: 0; padding: 0 0 1px; }
ul.navigation 
li.page-parent ul li a,	
ul.navigation 
li.page-parent.hover ul li a,
ul.navigation 
li.page-parent:hover ul li a							{ padding: 6px 10px 8px; border-bottom: none; width: 100px; border-right: none;}



                                                                                                                                                                                                                 
                                                                                                                                                                                      
div#container .box										{ background: none; }  
div.featured-post 										{ background: none; }                                                                                                                       
div.leaf-top							 		 		{ text-transform: uppercase; padding: 0 0 2px 0; border-bottom: 1px solid #333; color: #333; margin: 0 0 5px 0; }                              
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 
#footer 								  				{ display: block; width: 100%; margin: 5px 0 0; padding: 10px 0; border-top: 1px solid #999; }                                                                     
div#footer * 							 		 		{ padding: 0; margin: 0; }                                                                                                                                       
div#footer .footer-left 				 		 		{ margin-left: 10px; float: left; }                                                                                                                              
div#footer .footer-right 				  				{ margin-right: 10px; float: right; }                                                                                                                            
div#footer a.no-underline				  				{ text-decoration: none; }                                                                                                                                       
div#footer .copyright					 		 		{ clear: both; text-align: center; margin: 25px 0 0; }                                                                                                           
div#footer                                                                                                                                                                                                       
a.no-underline:hover 					  				{ text-decoration: underline; }                                                                                                                                  
                                                                                                                                                                                                                 
.feed-entry-date						  				{ color: #888; }                                                                                                                                                 
                                                                                                                                                                                      
.featured-entry-date									{ color: #888; float: left; }                                                                                                                 
.featured-entry-content									{ clear: both; margin: 5px 0; float: left; }                                                                                                  
.featured-entry-title									{ font-size: 2em; }                                                                                                                           
.featured-entry-title a									{ text-decoration: none; }                                                                                                                    
.featured-entry-title                                                                                                                                                                 
a:hover													{ text-decoration: underline; }                                                                                                               
.featured-post											{ margin: 10px 0; }                                                                                                                           
.featured-entry-comments								{ float: right; }                                                                                                                             
.featured_prev											{ float: left; }                                                                                                                              
.featured_next											{ float: right; }                                                                                                                             
.featured_outside_prev,                                                                                                                                                               
.featured_outside_next									{ margin: 30px 0 0 0; z-index: 10001; position: relative; }                                                                                   
                                                                                                                                                                                      
                                                                                                                                                                                      
div.leaf-content div.rotator-images						{ border: 1px solid #ccc; display: block; }
                            
                            
.align-left												{ margin: 0 7px 0 0; }
.align-right											{ margin: 0 0 0 7px; }
                            
.about-image 											{ padding: 1px; border: 1px solid #ccc; }


div.nav-previous										{ float: left; margin: 10px 0; }
	div.nav-previous a,
	div.nav-next a										{ padding: 5px; font-size: 1.1em; color: #222;background: #ccc;  text-decoration: none;display:block;}
	div.nav-previous a:hover,
	div.nav-next a:hover								{ text-decoration: underline; }
div.nav-next				     						{ float: right; margin: 10px 0; }                            
                            
                            
ul.sidebar												{ margin: 0; padding: 0; }
ul.sidebar li											{ list-style: none; }
ul.sidebar li ul 										{ margin: 0 0 10px 10px; padding: 0; list-style: none; }
ul.sidebar li ul li										{ list-style: disc; margin: 0 0 7px; list-style: none; }
ul.sidebar li ul li ul 									{ padding: 0 0 0 25px; margin: 7px 0 7px; } 
li.widget_socialwidget									{ text-align: center; }
li.widget_socialwidget span.widget-title 				{ text-align: left; }
                            
                            
                            
.entry-title											{ clear:both; }
.entry-title a											{ text-decoration: none; }
.entry-title a:hover									{ color: #666; }

                            
.archives-title											{ color: #7a7a7a; }
.page-title 											{ margin: 0 0 20px; }
                            
.entry-meta												{ color: #7a7a7a; display: block; margin: 3px 0 0 0; clear: both; }
.entry-meta a											{ color: #7a7a7a; }
.entry-meta a:hover										{ text-decoration: none; }
.meta-above-title .left, .meta-above-title .right 		{ margin: 0 0 5px; }
                            

                            
.entry-content											{ clear: both; }


img.border												{ padding: 1px; border: 1px solid #ddd; }
img.no-border											{ padding: 0; border: none; }
                            
                            
a.more-link:link,
a.more-link:visited,
.entry-content a.more-link:link,
.entry-content a.more-link:visited						{ background: #ccc; padding: 2px 4px; text-decoration: none; margin: 10px 0 20px; float: left; color: #333; }
a.more-link:hover, .entry-content a.more-link:hover		{ text-decoration: underline; }

a.featured-more-link:link, a.featured-more-link:visited { padding: 6px 7px; }
                            
                            
div.post, div.small-post								{ margin: 0 0 20px; padding: 0 0 20px; border-bottom: 1px solid #ccc; }
div.feed-post 											{ margin: 5px 0; padding: 10px 0; }
body.single div.post									{ border-bottom: none; }
div.small-post h3										{ font-size: 1.5em; }



input.text, textarea.text 								{ border-top: 1px solid #aaa; border-right: 1px solid #e1e1e1; border-bottom: 1px solid #e1e1e1; border-left: 1px solid #aaa; background: #fff; font-size: 1.1em; padding: 3px; color: #4c4c4c; }
.text:focus												{ background: #f3f3f3; color: #111; }
input.text 												{ width: 50%; }
textarea.text 											{ width: 70%; line-height: 1.4em; }
input.submit											{ border-top: 1px solid #efefef; border-right: 1px solid #777; border-bottom: 1px solid #777; border-left: 1px solid #efefef; background: #eee; color: #444; font-size: 1.1em; padding: 3px 5px; }




h2.border-top, h3.border-top, h4.border-top, 
p.border-top 											{ padding-top: 10px; border-top: 1px solid #ddd; }
.entry-content .grey									{ color: #999; }


ol.commentlist, ol.pinglist								{ margin: 10px 0; padding: 0; border-bottom: 1px solid #ddd; }

ol.commentlist											{list-style: none; }
ol.commentlist li										{ border: 1px solid #ddd; border-width: 1px 0 0; list-style: none; padding: 10px; margin: 0; }
ol.commentlist li ul.children							{ border-bottom: 1px solid #ddd; margin-right: -10px; }
ol.commentlist li ul.children li						{ margin: 10px 0;}




li.thread-odd											{ background: #f7f7f7; }

img.avatar												{ float: right; margin: 0 0 2px 5px; padding: 1px; border: 1px solid #eee; }
span.comment-author										{ font-size: 1.2em; color: #222; }
span.comment-author a									{ color: #222; }
div.comment-date										{ color: #666; }




span.heading 											{ font-size: 1.6em; color: #444; }
p.nocomments											{ border-top: 1px solid #ddd; font-size: 1.2em; margin: 10px 0 0; padding: 10px 0; color: #666; }


.comment-info-box 										{ background: #f9f9f9; border: 1px solid #ddd; padding: 7px; width: 70%;  }

.comment-body p											{ line-height: 1.5em; color: #333; } 

div#trackback-box										{ float: left; }
div#trackback-box span#trackback						{ margin: 0; font-size: 1.2em; color: #333; float: left; }
div#trackback-box 
span#trackback-url										{ margin: 5px 0 0; font-size: 0.9em; color: #666; clear: left; float: left; }




ol.commentlist div#respond								{ margin: 10px -10px 0 15px; border: 1px solid #ddd; border-width: 1px 0; padding: 10px 0 0; }

div#respond label										{ font-size: 1.2em; color: #555;}




div#container .headway-welcome							{ padding: 5px; margin: 10px; background: #eee; }
div#container .headway-welcome .leaf-content			{ font-size: 1.1em; }


ul.subscribe											{ padding: 0 0 0 15px; }
ul.subscribe li.rss										{ background: url(../images/rss.gif) no-repeat; list-style: none; padding: 2px 0 2px 22px; }

input#s													{ width: 96.5%; background: #f6f6f6; border: 1px solid #ccc; color: #666; font-size: 1em; padding: 4px 5px; }
input#s:focus											{ background: #fff; border: 1px solid #888; color: #222; }


ul.twitter-updates, 
ul.sidebar li ul.twitter-updates						{ list-style: none; margin: 10px 0 0 10px; padding: 0; }
.box ul.twitter-updates 								{ margin-left: 0; }
ul.twitter-updates li,
ul.sidebar li ul.twitter-updates li						{ clear: both; margin: 0 0 5px; padding: 0 0 5px; border-bottom: 1px solid #ddd; list-style: none; }
ul.twitter-updates li span								{ color: #888; margin: 0 0 0 6px; }



.wp-caption 											{ padding: 5px; border: 1px solid #eee; background: #fcfcfc; margin-top: 15px; margin-bottom: 15px; }
.wp-caption img 										{border: 1px solid #ddd; margin: 0 auto; display: block; padding: 0; }
.wp-caption p 											{text-align: center; color: #555; margin: 5px 0 0; font-style: italic; }





div.small-excerpts-row              					{ border-bottom: 1px solid #ccc; margin:0 0 30px; padding:0 0 30px; }
div.small-excerpts-post 								{ width: 45%; font-size: 0.9em; float: left; border-bottom: none; margin: 0; padding: 0 2.5%; }
div.small-excerpts-post .entry-title 					{ font-size: 1.6em; }