<?php
include '../../../../../wp-blog-header.php';
headway_gzip();
header("Content-type: text/css");
?>


.arial 			   				{font-family: Arial, sans-serif;}                                            
.helvetica 		   				{font-family: Helvetica, sans-serif;}                                        
.tahoma 		   				{font-family: Tahoma, sans-serif;}                                           
.verdana 		   				{font-family: Verdana, sans-serif;}                                          
.gill-sans 		   				{font-family: "Gill Sans", sans-serif;}                                      
.arial-black 	   				{font-family: "Arial Black", sans-serif;}                                    
.lucida-grande 	   				{font-family: "Lucida Grande", sans-serif;}                                  
.courier-new 	   				{font-family: "Courier New", sans-serif;}                                    
.courier 		   				{font-family: "Courier", sans-serif;}                                        
                                                                                                         
.georgia 		   				{font-family: Georgia, serif;}                                               
.times 			   				{font-family: Times, serif;}                                                 
.times-new-roman   				{font-family: "Times New Roman", Times, serif;}                              
                                                                                                         
                                                                                                         
h1 				   				{font-size:2.6em;}                                                           
h2 				   				{font-size:2.3em;}                                                           
h3 				   				{font-size:1.75em;}                                                           
h4				   				{font-size:1.4em;}        


.entry-content h2, 
.entry-content h3, 
.entry-content h4				{ margin: 10px 0; }

.entry-content h1, 
.entry-content h2 				{ line-height: 120%; font-family: <?php echo font('post-h2')?>; font-size: <?php echo (font_size('post-h2')) ? font_size('post-h2') : '1.8' ?>em; }
.entry-content h3 				{ line-height: 120%; font-family: <?php echo font('post-h3')?>; font-size: <?php echo (font_size('post-h3')) ? font_size('post-h3') : '1.6' ?>em; }
.entry-content h4 				{ line-height: 120%; font-family: <?php echo font('post-h4')?>; font-size: <?php echo (font_size('post-h4')) ? font_size('post-h4') : '1.2' ?>em; }

div.entry-content 				{ font-size: <?php echo (font_size('content')) ? font_size('content') : '1.1' ?>em; }
                                                   
                                                                               
div#wrapper, 
div#navigation-container,
div#breadcrumbs-container 		{ font-size: 1.2em; } 


div.header-link-text			{ font-size: <?php echo (font_size('header')) ? font_size('header') : '3.4' ?>em; }
h1#tagline						{ font-size: <?php echo (font_size('header-tagline')) ? font_size('header-tagline') : '2' ?>em; }
ul.navigation					{ font-size: <?php echo (font_size('navigation')) ? font_size('navigation') : '1.1' ?>em; }
#breadcrumbs					{ font-size: <?php echo (font_size('breadcrumbs')) ? font_size('breadcrumbs') : '1' ?>em; }
ul.sidebar						{ font-size: <?php echo (font_size('sidebar')) ? font_size('sidebar') : '1' ?>em; }
span.widget-title				{ font-size: <?php echo (font_size('sidebar-widget-heading')) ? font_size('sidebar-widget-heading') : '1.4' ?>em; }
div.leaf-top					{ font-size: <?php echo (font_size('leaf-headings')) ? font_size('leaf-headings') : '1.3' ?>em; }
h1.page-title, h1.entry-title, h2.entry-title		{ font-size: <?php echo (font_size('titles')) ? font_size('titles') : '2.3' ?>em; }








ul								{ list-style: disc; padding: 0 0 0 35px; }
ul li ul						{ margin: 5px 0; }
ul li ul li						{ list-style: circle; }
ul li ul li ul li				{ list-style: square; }


ol								{ list-style: decimal; padding: 0 0 0 35px; }
ol li ol						{ margin: 5px 0; }
ol li ol li						{ list-style: upper-alpha; }
ol li ol li ol li				{ list-style: lower-roman; }




ol								{ list-style: decimal; padding: 0 0 0 35px; }
ul li							{ list-style: disc; margin: 0 0 5px; }
ol li							{ list-style: decimal; margin: 0 0 5px; }

blockquote						{ color: #666; font-style: italic; padding: 5px 0 5px 26px; background: url(../images/blockquote.jpg) no-repeat 0 15px; border: 1px dotted #999; border-width: 1px 0; margin: 10px 0; }
em, i							{ font-style: italic; }


.notice							{ background:#FFFFE0; border:1px solid #E6DB55; margin:10px 0; padding:10px; }

.drop-cap						{ font-size: 310%; line-height: 120%; margin-bottom:-0.25em; color: #888; float: left; padding: 0 6px 0 0; }

code 							{ background:#EAEAEA; font-family:Consolas,Monaco,Courier,monospace; font-size:0.9em; margin:0 1px; padding:1px 3px; }
.code							{ display: block; background: #eee; border: 1px solid #ddd; color: #555; font-family:Consolas,Monaco,Courier,monospace; padding: 10px; }


span.widget-title				{ text-transform: uppercase; letter-spacing: 0.1em; color: #888; }



.entry-content a				{ text-decoration: underline; }
.entry-content a:hover			{ text-decoration: none; }



div.entry-content, div.leaf-content p {
	line-height: <?php echo font('content-line-height')?>;
	margin: 10px 0;
}

div.entry-content ul, div.entry-content ol { margin: 20px 0; }
div.entry-content ul ul, 
div.entry-content ol ol 				   { margin: 5px 0; }



.required, .unapproved			{ color: #aa0000; }