<?
/*
Template Name: Custom
*/
?>
<?php get_header() ?>

	<div id="container" class="clearfix">
		
		<?php get_page_leafs($post->ID) ?>
		
	</div><!-- #container -->


<?php get_footer() ?>