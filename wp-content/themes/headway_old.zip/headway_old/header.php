<? headway_html_open() ?>
	
<title><?php headway_title(); ?></title>
<meta http-equiv="content-type" content="<?php bloginfo('html_type') ?>; charset=<?php bloginfo('charset') ?>" />

<?php headway_meta() ?>

<?php headway_stylesheets() ?>

<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php bloginfo('url'); ?>/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php bloginfo('url'); ?>/wp-includes/wlwmanifest.xml" /> 


<link rel="alternate" type="application/rss+xml" href="<?php echo headway_rss() ?>" title="<?php echo get_bloginfo('name')?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url') ?>" />


<?php wp_head() ?>

</head> <!-- End <head> -->


<?php headway_page_top() ?>