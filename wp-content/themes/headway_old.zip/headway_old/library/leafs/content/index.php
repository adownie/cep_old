<?php
$item_options = db_to_leaf($item_options); 
//////////////////////////////////////////
//////////////////////////////////////////

$javascript_replace = array('select[categories_select]', 'select[pages]');
$leaf_name = 'content';


if(function_exists('get_categories')):
	if($categories_select): //Fixes select for multiple featured boxes.  Without this it will compound the categories.
		$categories_select = '';
		$categories = '';
		$select_selected = array();
	endif;
	
		$categories = explode(' | ', $item_options['categories']);
		$categories_select_query = get_categories();
		foreach($categories_select_query as $category){ 
			if(in_array($category->term_id, $categories)) $select_selected[$category->term_id] = ' selected';
	
			$categories_select .= '<option value="'.$category->term_id.'"'.$select_selected[$category->term_id].'>'.$category->name.'</option>';
	
		}
endif;



if(function_exists('get_pages')):
	$pages = '<option value=""></option>';
	$page_select_query = get_pages();
	foreach($page_select_query as $page){ 
		if($page->ID == $item_options['other-page']) $selected[$page->ID] = ' selected';
		$pages .= '<option value="'.$page->ID.'"'.$selected[$page->ID].'>'.$page->post_title.'</option>';
	}
endif;





$display = array();
$selected = array();
$checked = array();



$display['posts-options'] = 'display: none;';
$display['page-options'] = '';





if($item_options['mode'] == 'page'): $checked['page'] = ' checked';  $display['posts-options'] = 'display: none;'; $display['page-options'] = ''; endif;
if($item_options['mode'] == 'posts'): $checked['posts'] = ' checked'; $display['posts-options'] = ''; $display['page-options'] = 'display: none;'; endif;

if($item_options['categories-mode'] == 'include') $checked['include'] = ' checked';
if($item_options['categories-mode'] == 'exclude') $checked['exclude'] = ' checked';

if($item_options['paginate']) $checked['paginate'] = ' checked';



$defaults = array(
	'checked' => array('page', 'include', 'paginate'),
	'input' => array('featured_posts' => '1', 'post_limit' => get_option('posts_per_page'))
);





//////////////////////////////////////////
//////////////////////////////////////////


if($javascript):
	$leaf = '{{leaf_id_replace}}';
	$js_replace = $javascript_replace;
endif;

$options = array(
	'id' => $leaf,
	'checked' => $checked,
	'selected' => $selected,
	'display' => $display,
	'item_options' => $item_options,
	'leaf_config' => $leaf_config,
	'javascript_replace' => $js_replace,
	'select' => array('categories_select' => $categories_select, 'pages' => $pages)
);


if($javascript):
	$register = registerLeaf($leaf_name, $options, $defaults);
else:
	$register = registerLeaf($leaf_name, $options);
endif;

$leaf_inner = $register[0];
?>