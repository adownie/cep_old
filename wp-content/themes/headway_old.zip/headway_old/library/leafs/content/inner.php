<form id="{!id!}_options_form">
	<fieldset>
			<h3>Options</h3>
			
				<label>Mode</label>
				{script}
					var posts_options_{!id!} = ".{!id!}_posts_options";
					var page_options_{!id!} = ".{!id!}_page_options";
				{/script}
				<input type="radio" name="mode" id="{!id!}_mode-page" class="radio"{!checked[page]!} value="page" onclick="$(posts_options_{!id!}).hide();$(page_options_{!id!}).show();"/><label for="{!id!}_mode-page" class="no-clear">Page/Default Behavior</label>
				<input type="radio" name="mode" id="{!id!}_mode-posts" class="radio"{!checked[posts]!} value="posts" onclick="$(posts_options_{!id!}).show();$(page_options_{!id!}).hide();" /><label for="{!id!}_mode-posts" class="no-clear">Posts</label>
				
		</fieldset>
		
	
		

		<fieldset class="clear-left {!id!}_page_options no-border-bottom" style="{!display[page-options]!}">
				<p class="box" style="clear: both; flaot: left; margin: 5px 0;">The content leaf is extremely versatile.  By default it will do what you expect it to do.  For example, if you add this on a page, it will display that pages content.  If you add it on the index system page, it will list the posts like a normal blog template and if you add this box on a category page, it will list posts of that category.  You can also add a content box and display the content from a completely separate page.  Choose the page below, otherwise leave the select box empty.</p>
				
				<label for="{!id!}-other-page">Fetch Content From Other Page</label>
				<select name="other-page" id="{!id!}-other-page">
					{!select[pages]!}
				</select>
		</fieldset>
		
		
		
		
		
		<fieldset class="align-left clear-left {!id!}_posts_options no-border-bottom border-right" style="{!display[posts-options]!}">
				<p class="box" style="clear: both; flaot: left; margin: 5px 0;">The categories select box has two modes. You can set it to include specific categories or you can exclude specific categories.  Leave it blank to include all categories.</p>
				
				<label>Categories Mode</label>

				<input type="radio" name="categories-mode" id="{!id!}_mode-include" class="radio"{!checked[include]!} value="include" /><label for="{!id!}_mode-include" class="no-clear">Include</label>
				<input type="radio" name="categories-mode" id="{!id!}_mode-exclude" class="radio"{!checked[exclude]!} value="exclude" /><label for="{!id!}_mode-exclude" class="no-clear">Exclude</label>
				
				<label for="{!id!}-categories">Categories</label>
				<select name="categories" id="{!id!}-categories" multiple size="5">
					{!select[categories_select]!}
				</select>
		</fieldset>
		
		
		
		<fieldset class="align-right {!id!}_posts_options no-border-bottom" style="{!display[posts-options]!}">
				<label>Post Limit:</label>
				<input type="text" name="post_limit" id="{!id!}_post-limit" value="{!input[post_limit]!}" />
				
				<label>Featured Posts:</label>
				<input type="text" name="featured_posts" id="{!id!}_featured-posts" value="{!input[featured_posts]!}" />
				
				
				<input type="checkbox" name="paginate" id="{!id!}_paginate" class="check"{!checked[paginate]!} /><label for="{!id!}_paginate" class="no-clear">Paginate Posts</label>
				
				<p class="box" style="clear: both; flaot: left; margin: 5px 0;">If you need to customize the way the posts look, go to the Headway Configuration page and look under the <code>Look &amp; Feel</code> tab.</p>
		</fieldset>
		
		
		
		
		<fieldset class="clear-both border-top">
			<h3>Miscellaneous</h3>			
			<label for="{!id!}-custom-css-class">Custom CSS Class(es)</label>
			<input type="text" value="{!input[custom-css-class]!}" name="custom-css-class" id="{!id!}-custom-css-class" />
		</fieldset>
</form>