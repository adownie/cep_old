<?php
	$limit = ($item_options['post_limit']) ? $item_options['post_limit'] : get_option('posts_per_page');
	$small_excerpts = get_option('small-excerpts'); 
	$small_excerpts_class = ($small_excerpts) ? 'small-excerpts-post' : NULL;
	$post_count = ($item_options['featured_posts']%2) ? $item_options['featured_posts']+1 : $item_options['featured_posts'];
	$small_excerpts_amount = $limit-$item_options['featured_posts'];
	$small_excerpts_amount = (get_query_var('paged') || is_archive()) ? $limit : $small_excerpts_amount;
	$smaller_excepts_container_count = 0;
	$single = false;

	

			if($item_options['other-page']) query_posts('page_id='.$item_options['other-page']);
			if($item_options['mode'] == 'page'):
			if(is_home()):
			
				
				while ( have_posts() ) : 
				the_post();
				
				$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
				$count++;
				if($count <= get_option('featured-posts') && $paged == 1): 
				?>
							<?php do_action('headway_above_post', $count, $single) ?>
							<div id="post-<?php the_ID() ?>" class="<?php echo font('content') ?> <?php blog_post_class() ?> clearfix">
								<?php headway_above_title($count, $single) ?>
								<h2 class="entry-title <?php echo font('titles')?>"><a href="<?php the_permalink() ?>" title="<?php printf(__('Permalink to %s', 'blog'), wp_specialchars(get_the_title(), 1)) ?>" rel="bookmark"><?php the_title() ?></a></h2>
								<?php headway_below_title($count, $single) ?>

								<div class="entry-content">

									<?php the_content('Read More &raquo;'); ?>

									

								</div>
								<?php headway_below_content($count, $single) ?>
							</div><!-- .post -->
							<?php do_action('headway_below_post', $count, $single) ?>

				<?php else: ?>
							
							
							
				
							
					<? 
					if($small_excerpts && !($post_count%2)){
						echo '<div class="small-excerpts-row clearfix">'; 
						$smaller_excepts_container_count++;
					}
					?>
							
							
							<?php do_action('headway_above_small_excerpt', $count) ?>
							<div id="post-<?php the_ID() ?>" class="<?php echo font('content') ?> <?php blog_post_class() ?> small-post clearfix <?php echo $small_excerpts_class ?>">
									<?php headway_above_title($count, $single, $small_excerpts) ?>
									<h2 class="entry-title <?php echo font('titles')?>"><a href="<?php the_permalink() ?>" title="<?php printf(__('Permalink to %s', 'blog'), wp_specialchars(get_the_title(), 1)) ?>" rel="bookmark"><?php the_title() ?></a></h2>
									<?php headway_below_title($count, $single, $small_excerpts) ?>	
									<div class="entry-content">
										<?php the_excerpt(); ?>

										<p><a href="<?php the_permalink() ?>" class="more-link">Read the full article &raquo;</a></p>
									</div>
									<?php headway_below_content($count, $single, $small_excerpts) ?>
								</div><!-- .post -->
							<?php do_action('headway_below_small_excerpt', $count) ?>
							
					<? 
					if(($small_excerpts && $post_count%2) || ($count == get_option('posts_per_page') && $small_excerpts_amount%2 && $small_excerpts)){
						echo '</div>';  
						$smaller_excepts_container_count++;
					}
					$post_count++;
					?>

				<?php endif; ?>
				
		
		<?php 
		endwhile; 
		if($smaller_excepts_container_count%2) echo '</div>';
		?>
		
		
			
			
			<div id="nav-below" class="navigation">
				<?php if(!function_exists('wp_pagenavi')) { ?>
				<div class="nav-previous"><?php next_posts_link('<span class="meta-nav">&laquo;</span> Older Posts') ?></div>
				<div class="nav-next"><?php previous_posts_link('Newer posts <span class="meta-nav">&raquo;</span>') ?></div>
				<? } else { 
					wp_pagenavi(); 
				}
				?>
			</div>
		
		
		<?php elseif(is_page()): ?>
			<?php the_post() ?>
			
			<?php do_action('headway_above_page') ?>
			<div id="post-<?php the_id()?>" class="<?php echo font('content') ?> <?php blog_post_class() ?> clearfix">
		
			<?php if(!get_post_meta(get_the_id(), '_hide_title', true)): ?>
			<h1 class="page-title <?php echo font('titles')?>"><?php if(get_write_box_value('custom-title')){ echo get_write_box_value('custom-title'); } else { the_title(); } ?></h1>
			<?php endif; ?>
			<? do_action('headway_below_page_title') ?>
			<div class="entry-content">
				<?php the_content() ?>
			</div>
			
			</div>
			<?php do_action('headway_below_page') ?>
			
			<?php if(!get_option('headway-disable-comments-pages')) comments_template('', true); ?>
						
			
			
		<?php elseif(is_single()): ?>
			<?php the_post() ?>
			<? $single = true; ?>
			<?php do_action('headway_above_post_single', $count) ?>
			<?php do_action('headway_above_post', $count, $single) ?>
				<div id="post-<?php the_ID() ?>" class="<?php echo font('content') ?> <?php blog_post_class() ?> clearfix">
				<?php headway_above_title($count, $single) ?>
				<h1 class="entry-title <?php echo font('titles')?>"><?php the_title() ?></h1>
				<?php headway_below_title($count, $single) ?>
				
			
				<div class="entry-content">
				
					<?php the_content('Read More &raquo;'); ?>
				
					
				
				</div>
				<?php headway_below_content($count, $single) ?>
				
			</div><!-- .post -->
			<?php do_action('headway_below_post', $count, $single) ?>
			<?php do_action('headway_below_post_single', $count) ?>
			
			
		<?php comments_template('', true); ?>
		
		<?php do_action('headway_below_comments', $count) ?>
			
			
			
			
			
		<?php elseif(is_category()): ?>

			<h2 class="page-title <?php echo font('titles')?> archives-title">Category Archives: <?php echo single_cat_title(); ?></span></h2>
			<?php if(category_description()): ?><div class="archive-meta"><?php echo category_description()?></div><?php endif; ?>
			
			<?php 
				while ( have_posts() ) : 
				the_post();
				$count++;
			?>
			
					<? 
					if($small_excerpts && !($post_count%2)){
						echo '<div class="small-excerpts-row clearfix">'; 
						$smaller_excepts_container_count++;
					}
					?>
							
							<?php do_action('headway_above_small_excerpt', $count) ?>
							<div id="post-<?php the_ID() ?>" class="<?php echo font('content') ?> <?php blog_post_class() ?> small-post clearfix <?php echo $small_excerpts_class ?>">
									<?php headway_above_title($count, $single, $small_excerpts) ?>
									<h2 class="entry-title <?php echo font('titles')?>"><a href="<?php the_permalink() ?>" title="<?php printf(__('Permalink to %s', 'blog'), wp_specialchars(get_the_title(), 1)) ?>" rel="bookmark"><?php the_title() ?></a></h2>
									<?php headway_below_title($count, $single, $small_excerpts) ?>	
									<div class="entry-content">
										<?php the_excerpt(); ?>

										<p><a href="<?php the_permalink() ?>" class="more-link">Read the full article &raquo;</a></p>
									</div>
									<?php headway_below_content($count, $single, $small_excerpts) ?>
								</div><!-- .post -->
							<?php do_action('headway_below_small_excerpt', $count) ?>
							
					<? 
					if(($small_excerpts && $post_count%2) || ($count == get_option('posts_per_page') && $small_excerpts_amount%2 && $small_excerpts)){
						echo '</div>';  
						$smaller_excepts_container_count++;
					}
					$post_count++;
					?>
			
			
			<?php 
			endwhile;
			if($smaller_excepts_container_count%2) echo '</div>'; 
			?>
			
			<div id="nav-below" class="navigation">
				<?php if(!function_exists('wp_pagenavi')) { ?>
				<div class="nav-previous"><?php next_posts_link('<span class="meta-nav">&laquo;</span> Older Posts') ?></div>
				<div class="nav-next"><?php previous_posts_link('Newer posts <span class="meta-nav">&raquo;</span>') ?></div>
				<? } else { 
					wp_pagenavi(); 
				}
				?>
			</div>
			
			
			
			
		<?php elseif(is_date()): ?>
			<?php if ( is_day() ) : ?>
						<h2 class="page-title <?php echo font('titles')?> archives-title">Daily Archives: <?php echo get_the_time(get_option('date_format')) ?></h2>
			<?php elseif ( is_month() ) : ?>
						<h2 class="page-title <?php echo font('titles')?> archives-title">Monthly Archives: <?php echo get_the_time('F Y') ?></h2>
			<?php elseif ( is_year() ) : ?>
						<h2 class="page-title <?php echo font('titles')?> archives-title">Yearly Archives: <?php echo get_the_time('Y')?></h2>
			<?php endif; ?>
			
			
			<?php 
				while ( have_posts() ) : 
				the_post();
				$count++;
			?>
			
			
					<? 
					if($small_excerpts && !($post_count%2)){
						echo '<div class="small-excerpts-row clearfix">'; 
						$smaller_excepts_container_count++;
					}
					?>
							
							
							<?php do_action('headway_above_small_excerpt', $count) ?>
							<div id="post-<?php the_ID() ?>" class="<?php echo font('content') ?> <?php blog_post_class() ?> small-post clearfix <?php echo $small_excerpts_class ?>">
									<?php headway_above_title($count, $single, $small_excerpts) ?>
									<h2 class="entry-title <?php echo font('titles')?>"><a href="<?php the_permalink() ?>" title="<?php printf(__('Permalink to %s', 'blog'), wp_specialchars(get_the_title(), 1)) ?>" rel="bookmark"><?php the_title() ?></a></h2>
									<?php headway_below_title($count, $single, $small_excerpts) ?>	
									<div class="entry-content">
										<?php the_excerpt(); ?>

										<p><a href="<?php the_permalink() ?>" class="more-link">Read the full article &raquo;</a></p>
									</div>
									<?php headway_below_content($count, $single, $small_excerpts) ?>
								</div><!-- .post -->
							<?php do_action('headway_below_small_excerpt', $count) ?>
							
					<? 
					if(($small_excerpts && $post_count%2) || ($count == get_option('posts_per_page') && $small_excerpts_amount%2 && $small_excerpts)){
						echo '</div>';  
						$smaller_excepts_container_count++;
					}
					$post_count++;
					?>
			
			
			<?php 
			endwhile;
			if($smaller_excepts_container_count%2) echo '</div>'; 
			?>
			
			
			<div id="nav-below" class="navigation">
				<?php if(!function_exists('wp_pagenavi')) { ?>
				<div class="nav-previous"><?php next_posts_link('<span class="meta-nav">&laquo;</span> Older Posts') ?></div>
				<div class="nav-next"><?php previous_posts_link('Newer posts <span class="meta-nav">&raquo;</span>') ?></div>
				<? } else { 
					wp_pagenavi(); 
				}
				?>
			</div>
			
			
			
		<?php elseif(is_tag()): ?>
			<h2 class="page-title <?php echo font('titles')?> archives-title">Tag Archive: <?php single_tag_title(); ?></h2>
			
			<?php 
				while ( have_posts() ) : 
				the_post();
				$count++;
			?>
			
			
				<? 
				if($small_excerpts && !($post_count%2)){
					echo '<div class="small-excerpts-row clearfix">'; 
					$smaller_excepts_container_count++;
				}
				?>
						
						
						<?php do_action('headway_above_small_excerpt', $count) ?>
						<div id="post-<?php the_ID() ?>" class="<?php echo font('content') ?> <?php blog_post_class() ?> small-post clearfix <?php echo $small_excerpts_class ?>">
								<?php headway_above_title($count, $single, $small_excerpts) ?>
								<h2 class="entry-title <?php echo font('titles')?>"><a href="<?php the_permalink() ?>" title="<?php printf(__('Permalink to %s', 'blog'), wp_specialchars(get_the_title(), 1)) ?>" rel="bookmark"><?php the_title() ?></a></h2>
								<?php headway_below_title($count, $single, $small_excerpts) ?>	
								<div class="entry-content">
									<?php the_excerpt(); ?>

									<p><a href="<?php the_permalink() ?>" class="more-link">Read the full article &raquo;</a></p>
								</div>
								<?php headway_below_content($count, $single, $small_excerpts) ?>
							</div><!-- .post -->
						<?php do_action('headway_below_small_excerpt', $count) ?>
						
				<? 
				if(($small_excerpts && $post_count%2) || ($count == get_option('posts_per_page') && $small_excerpts_amount%2 && $small_excerpts)){
					echo '</div>';  
					$smaller_excepts_container_count++;
				}
				$post_count++;
				?>
			
			
			
			<?php 
			endwhile;
			if($smaller_excepts_container_count%2) echo '</div>'; 
			?>
			
			<div id="nav-below" class="navigation">
				<?php if(!function_exists('wp_pagenavi')) { ?>
				<div class="nav-previous"><?php next_posts_link('<span class="meta-nav">&laquo;</span> Older Posts') ?></div>
				<div class="nav-next"><?php previous_posts_link('Newer posts <span class="meta-nav">&raquo;</span>') ?></div>
				<? } else { 
					wp_pagenavi(); 
				}
				?>
			</div>
			
			
			
		<?php elseif(is_author()): ?>
			<?php
			if(get_query_var('author_name')) :
				$authordata = get_userdatabylogin(get_query_var('author_name'));
			else :
				$authordata = get_userdata(get_query_var('author'));
			endif;
			?>
			<h2 class="page-title author archives-title">Author Archives: <?php echo $authordata->display_name?></h2>
			<?php if($authordata->user_description): ?><div class="archive-meta"><?php echo $authordata->user_description; ?></div><?php endif; ?>
		
			<?php 
				while ( have_posts() ) : 
				the_post();
				$count++;
			?>
			
				<? 
				if($small_excerpts && !($post_count%2)){
					echo '<div class="small-excerpts-row clearfix">'; 
					$smaller_excepts_container_count++;
				}
				?>
						
						
						<?php do_action('headway_above_small_excerpt', $count) ?>
						<div id="post-<?php the_ID() ?>" class="<?php echo font('content') ?> <?php blog_post_class() ?> small-post clearfix <?php echo $small_excerpts_class ?>">
								<?php headway_above_title($count, $single, $small_excerpts) ?>
								<h2 class="entry-title <?php echo font('titles')?>"><a href="<?php the_permalink() ?>" title="<?php printf(__('Permalink to %s', 'blog'), wp_specialchars(get_the_title(), 1)) ?>" rel="bookmark"><?php the_title() ?></a></h2>
								<?php headway_below_title($count, $single, $small_excerpts) ?>	
								<div class="entry-content">
									<?php the_excerpt(); ?>

									<p><a href="<?php the_permalink() ?>" class="more-link">Read the full article &raquo;</a></p>
								</div>
								<?php headway_below_content($count, $single, $small_excerpts) ?>
							</div><!-- .post -->
						<?php do_action('headway_below_small_excerpt', $count) ?>
						
				<? 
				if(($small_excerpts && $post_count%2) || ($count == get_option('posts_per_page') && $small_excerpts_amount%2 && $small_excerpts)){
					echo '</div>';  
					$smaller_excepts_container_count++;
				}
				$post_count++;
				?>
			
			<?php 
			endwhile;
			if($smaller_excepts_container_count%2) echo '</div>'; 
			?>
			
			<div id="nav-below" class="navigation">
				<?php if(!function_exists('wp_pagenavi')) { ?>
				<div class="nav-previous"><?php next_posts_link('<span class="meta-nav">&laquo;</span> Older Posts') ?></div>
				<div class="nav-next"><?php previous_posts_link('Newer posts <span class="meta-nav">&raquo;</span>') ?></div>
				<? } else { 
					wp_pagenavi(); 
				}
				?>
			</div>
			
			
			
		<?php elseif(is_search()): ?>
			<h2 class="page-title <?php echo font('titles')?> archives-title">Search Results for: <span id="search-terms"><?php the_search_query() ?></span></h2>
			
		
			<?php 
				while ( have_posts() ) : 
				the_post();
				$count++;
				global $post;
			?>
			
			<? if($post->post_type == 'post'): ?>
			
				
					<? 
					if($small_excerpts && !($post_count%2)){
						echo '<div class="small-excerpts-row clearfix">'; 
						$smaller_excepts_container_count++;
					}
					?>
							
							
							<?php do_action('headway_above_small_excerpt', $count) ?>
							<div id="post-<?php the_ID() ?>" class="<?php echo font('content') ?> <?php blog_post_class() ?> small-post clearfix <?php echo $small_excerpts_class ?>">
									<?php headway_above_title($count, $single, $small_excerpts) ?>
									<h2 class="entry-title <?php echo font('titles')?>"><a href="<?php the_permalink() ?>" title="<?php printf(__('Permalink to %s', 'blog'), wp_specialchars(get_the_title(), 1)) ?>" rel="bookmark"><?php the_title() ?></a></h2>
									<?php headway_below_title($count, $single, $small_excerpts) ?>	
									<div class="entry-content">
										<?php the_excerpt(); ?>

										<p><a href="<?php the_permalink() ?>" class="more-link">Read the full article &raquo;</a></p>
									</div>
									<?php headway_below_content($count, $single, $small_excerpts) ?>
								</div><!-- .post -->
							<?php do_action('headway_below_small_excerpt', $count) ?>
							
					<? 
					if(($small_excerpts && $post_count%2) || ($count == get_option('posts_per_page') && $small_excerpts_amount%2 && $small_excerpts)){
						echo '</div>';  
						$smaller_excepts_container_count++;
					}
					$post_count++;
					?>
				
			<? else: ?>
			
					
					<? 
					if($small_excerpts && !($post_count%2)){
						echo '<div class="small-excerpts-row clearfix">'; 
						$smaller_excepts_container_count++;
					}
					?>
							
							<?php do_action('headway_above_small_excerpt', $count) ?>
							<div id="post-<?php the_ID() ?>" class="<?php echo font('content') ?> <?php blog_post_class() ?> small-post clearfix <?php echo $small_excerpts_class ?>">
									<h2 class="entry-title <?php echo font('titles')?>"><a href="<?php the_permalink() ?>" title="<?php printf(__('Permalink to %s', 'blog'), wp_specialchars(get_the_title(), 1)) ?>" rel="bookmark"><?php the_title() ?></a></h2>
									<div class="entry-content">
										<?php the_excerpt(); ?>

										<p><a href="<?php the_permalink() ?>" class="more-link">Read the full page &raquo;</a></p>
									</div>
								</div><!-- .post -->
							<?php do_action('headway_below_small_excerpt', $count) ?>
							
					<? 
					if(($small_excerpts && $post_count%2) || ($count == get_option('posts_per_page') && $small_excerpts_amount%2 && $small_excerpts)){
						echo '</div>';  
						$smaller_excepts_container_count++;
					}
					$post_count++;
					?>
					
				
			<? endif;?>
			
			
			<?php 
			endwhile;
			if($smaller_excepts_container_count%2) echo '</div>'; 
			?>
			
			
			<div id="nav-below" class="navigation">
				<?php if(!function_exists('wp_pagenavi')) { ?>
				<div class="nav-previous"><?php next_posts_link('<span class="meta-nav">&laquo;</span> Older Posts') ?></div>
				<div class="nav-next"><?php previous_posts_link('Newer posts <span class="meta-nav">&raquo;</span>') ?></div>
				<? } else { 
					wp_pagenavi(); 
				}
				?>
			</div>
			
			
		<?php endif; ?>
		
			
		

		
		
		
		
		
		
		<?php elseif($item_options['mode'] == 'posts'): ?>
		
		
			<?php 
			global $more;
			$more = 0;
										
			$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
			
			$categories = explode(' | ', $item_options['categories']);
			
			$query_options = array(
				'post-type'  =>  'post'
			);
			
			if($item_options['paginate']) $query_options['paged'] = $paged;
			
			if($item_options['post_limit'] && $item_options['paginate']) $query_options['posts_per_page'] = $item_options['post_limit'];
			if($item_options['post_limit'] && !$item_options['paginate']) $query_options['showposts'] = $item_options['post_limit'];
			
			if($item_options['categories']){
				if($item_options['categories-mode'] == 'include') $query_options['category__in'] = $categories;
				if($item_options['categories-mode'] == 'exclude') $query_options['category__not_in'] = $categories;	
			} 
			
			
			$query[$leaf] = new WP_Query($query_options);
			
			while ( $query[$leaf]->have_posts() ) : 
			
			$query[$leaf]->the_post();

			$count++;
			if($count <= $item_options['featured_posts'] && $paged == 1): 
			?>
				
						<?php do_action('headway_above_post', $count, $single) ?>
							<div id="post-<?php the_ID() ?>" class="<?php echo font('content') ?> <?php blog_post_class() ?> clearfix">
							<?php headway_above_title($count, $single) ?>
							<h2 class="entry-title <?php echo font('titles')?>"><a href="<?php the_permalink() ?>" title="<?php printf(__('Permalink to %s', 'blog'), wp_specialchars(get_the_title(), 1)) ?>" rel="bookmark"><?php the_title() ?></a></h2>
							<?php headway_below_title($count, $single) ?>
							
							<div class="entry-content">
								
								<?php the_content('Read More &raquo;'); ?>
								
								
								
							</div>
							<?php headway_below_content($count, $single) ?>
						</div><!-- .post -->
							<?php do_action('headway_below_post', $count, $single) ?>

			<?php else: ?>
			
							<? 
							if($small_excerpts && !($post_count%2)){
								echo '<div class="small-excerpts-row clearfix">'; 
								$smaller_excepts_container_count++;
							}
							?>


									<?php do_action('headway_above_small_excerpt', $count) ?>
									<div id="post-<?php the_ID() ?>" class="<?php echo font('content') ?> <?php blog_post_class() ?> small-post clearfix <?php echo $small_excerpts_class ?>">
											<?php headway_above_title($count, $single, $small_excerpts) ?>
											<h2 class="entry-title <?php echo font('titles')?>"><a href="<?php the_permalink() ?>" title="<?php printf(__('Permalink to %s', 'blog'), wp_specialchars(get_the_title(), 1)) ?>" rel="bookmark"><?php the_title() ?></a></h2>
											<?php headway_below_title($count, $single, $small_excerpts) ?>	
											<div class="entry-content">
												<?php the_excerpt(); ?>

												<p><a href="<?php the_permalink() ?>" class="more-link">Read the full article &raquo;</a></p>
											</div>
											<?php headway_below_content($count, $single, $small_excerpts) ?>
										</div><!-- .post -->
									<?php do_action('headway_below_small_excerpt', $count) ?>

							<? 
							if(($small_excerpts && $post_count%2) || ($count == get_option('posts_per_page') && $small_excerpts_amount%2 && $small_excerpts)){
								echo '</div>';  
								$smaller_excepts_container_count++;
							}
							$post_count++;
							?>
			
			<?php endif; ?>


			<?php 
			endwhile; 
			if($smaller_excepts_container_count%2) echo '</div>';
			?>

			<?php if($item_options['paginate']): ?>
			
						<div id="nav-below" class="navigation">	
								<?php if(!function_exists('wp_pagenavi')) { ?>
									<div class="nav-previous"><?php next_posts_link('<span class="meta-nav">&laquo;</span> Older Posts', $query[$leaf]->max_num_pages) ?></div>
									<div class="nav-next"><?php previous_posts_link('Newer posts <span class="meta-nav">&raquo;</span>') ?></div>
								<? } else { 
									wp_pagenavi(); 
								}
								?>
						</div>
						
			<?php endif; ?>
			

			<?php endif; ?>