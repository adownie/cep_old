<?php
$item_options = db_to_leaf($item_options);
//////////////////////////////////////////
//////////////////////////////////////////


$javascript_replace = array('select[categories_select]');
$leaf_name = 'feed';


if(function_exists('get_categories')):
	if($categories_select): //Fixes select for multiple featured boxes.  Without this it will compound the categories.
		$categories_select = '';
		$categories = '';
		$select_selected = array();
	endif;
	
		$categories = explode(' | ', $item_options['categories']);
		$categories_select_query = get_categories();
		foreach($categories_select_query as $category){ 
			if(in_array($category->term_id, $categories)) $select_selected[$category->term_id] = ' selected';
	
			$categories_select .= '<option value="'.$category->term_id.'"'.$select_selected[$category->term_id].'>'.$category->name.'</option>';
	
		}
endif;



$selected = array();
$checked = array();
$display = array();


$display['rss-options'] = 'display: none;';

if($item_options['mode'] == 'posts'): $checked['posts'] = ' checked';  $display['posts-options'] = ''; $display['rss-options'] = 'display: none;'; endif;
if($item_options['mode'] == 'rss'): $checked['rss'] = ' checked'; $display['posts-options'] = 'display: none;'; $display['rss-options'] = ''; endif;

if($item_options['categories-mode'] == 'include') $checked['include'] = ' checked';
if($item_options['categories-mode'] == 'exclude') $checked['exclude'] = ' checked';

if($item_options['show-title']) $checked['show-title'] = ' checked';
if($item_options['nofollow']) $checked['nofollow'] = ' checked';
if($item_options['show-date-post']) $checked['show-date-post'] = ' checked';
if($item_options['show-date-rss']) $checked['show-date-rss'] = ' checked';



$defaults = array(
	'checked' => array('posts', 'include', 'paginate', 'show-date-post', 'show-date-rss', 'show-title'),
	'input' => array('post-limit' => '3', 'item-limit' => '3')
);








//////////////////////////////////////////
//////////////////////////////////////////

if($javascript):
	$leaf = '{{leaf_id_replace}}';
	$js_replace = $javascript_replace;
endif;

$options = array(
	'id' => $leaf,
	'checked' => $checked,
	'selected' => $selected,
	'display' => $display,
	'item_options' => $item_options,
	'leaf_config' => $leaf_config,
	'javascript_replace' => $js_replace,
	'select' => array('categories_select' => $categories_select)
);


if($javascript):
	$register = registerLeaf($leaf_name, $options, $defaults);
else:
	$register = registerLeaf($leaf_name, $options);
endif;

$leaf_inner = $register[0];
?>