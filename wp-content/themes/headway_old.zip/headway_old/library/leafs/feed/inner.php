<form id="{!id!}_options_form">

		<fieldset>
			<h3>Options</h3>
			
				<label>Mode</label>
				{script}
					var posts_options_{!id!} = ".{!id!}-posts-options";
					var rss_options_{!id!} = ".{!id!}-rss-options";
				{/script}
				<input type="radio" name="mode" id="{!id!}-mode-posts" class="radio"{!checked[posts]!} value="posts" onclick="$(posts_options_{!id!}).show();$(rss_options_{!id!}).hide();"/><label for="{!id!}-mode-posts" class="no-clear">Recent Posts</label>
				<input type="radio" name="mode" id="{!id!}-mode-feed" class="radio"{!checked[rss]!} value="rss" onclick="$(posts_options_{!id!}).hide();$(rss_options_{!id!}).show();" /><label for="{!id!}-mode-rss" class="no-clear">RSS Feed</label>
				
		</fieldset>
		
		
		

		<fieldset class="clear-left {!id!}-posts-options no-border-bottom" style="{!display[posts-options]!}">
				<p class="box" style="clear: both; flaot: left; margin: 5px 0;">The categories select box has two modes. You can set it to include specific categories or you can exclude specific categories.  Leave it blank to include all categories.</p>
				
				<label>Categories Mode</label>

				<input type="radio" name="categories-mode" id="{!id!}-mode-include" class="radio"{!checked[include]!} value="include" /><label for="{!id!}-mode-include" class="no-clear">Include</label>
				<input type="radio" name="categories-mode" id="{!id!}-mode-exclude" class="radio"{!checked[exclude]!} value="exclude" /><label for="{!id!}-mode-exclude" class="no-clear">Exclude</label>
				
				<label for="{!id!}-categories">Categories</label>
				<select name="categories" id="{!id!}-categories" multiple size="5">
					{!select[categories_select]!}
				</select>
			
				<label>Post Limit:</label>
				<input type="text" name="post-limit" id="{!id!}-post-limit" value="{!input[post-limit]!}" />
				
				<input type="checkbox" name="show-date-post" id="{!id!}-show-date-post" class="check"{!checked[show-date-post]!} /><label for="{!id!}-show-date-post" class="no-clear">Show Post Date</label>
		</fieldset>
		
		
		
		
		
		<fieldset class="clear-left {!id!}-rss-options no-border-bottom" style="{!display[rss-options]!}">
				<label>RSS Feed Location/URL:</label>
				<input type="text" name="rss-url" id="{!id!}-rss-url" value="{!input[rss-url]!}" />
			
				<label>Item Limit:</label>
				<input type="text" name="item-limit" id="{!id!}-item-limit" value="{!input[item-limit]!}" />
				
				<input type="checkbox" name="show-date-rss" id="{!id!}-show-date-rss" class="check"{!checked[show-date-rss]!} /><label for="{!id!}-show-date-rss" class="no-clear">Show Post Date</label>
				<input type="checkbox" name="nofollow" id="{!id!}-nofollow" class="check"{!checked[nofollow]!} /><label for="{!id!}-nofollow" class="no-clear"><code>nofollow</code> links to posts in feed</label>
		</fieldset>
		

		
		<fieldset class="clear-both border-top">
			<h3>Miscellaneous</h3>			
			<input type="checkbox" name="show-title" id="{!id!}_show-title" class="check"{!checked[show-title]!} /><label for="{!id!}_show-title" class="no-clear">Show Box Title</label>		
			
			<label for="{!id!}-leaf-title-link">Leaf Title Link</label>
			<input type="text" value="{!input[leaf-title-link]!}" name="leaf-title-link" id="{!id!}-leaf-title-link" />		
			
			
			<label for="{!id!}-custom-css-class">Custom CSS Class(es)</label>
			<input type="text" value="{!input[custom-css-class]!}" name="custom-css-class" id="{!id!}-custom-css-class" />	
		</fieldset>
		
		
	</form>