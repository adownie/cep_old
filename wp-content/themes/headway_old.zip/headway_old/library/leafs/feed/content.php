<?php do_action('headway_leaf_top') ?>
<?php do_action('headway_leaf_top_'.$leaf) ?>

<?php if($item_options['show-title']): ?>
	<?php $leaf_title = ($item_options['leaf-title-link']) ? '<a href="'.$item_options['leaf-title-link'].'" title="">'.stripslashes($leaf_config[1]).'</a>' : stripslashes($leaf_config[1]) ; ?>
	<div class="leaf-top <?php echo font('leaf-headings') ?>"><?php echo $leaf_title ?></div>
<?php endif; ?>


<div class="leaf-content">
	<?php do_action('headway_leaf_content_top') ?>
	<?php do_action('headway_leaf_content_top_'.$leaf) ?>


<?php if($item_options['mode'] == 'posts'): ?>
<?php
 $categories = explode(' | ', $item_options['categories']); 

	$query_options = array('what_to_show' => 'posts', 'post_status' => 'publish');
	if($item_options['categories']){
		if($item_options['categories-mode'] == 'include') $query_options['category__in'] = $categories;
		if($item_options['categories-mode'] == 'exclude') $query_options['category__not_in'] = $categories;	
	} 
	if($item_options['post-limit']) $query_options['showposts'] = $item_options['post-limit'];

	
	
	
	$leaf_query = new WP_Query($query_options);
		while ( $leaf_query->have_posts() ) : 
		$leaf_query->the_post();
?>


		<div id="post-<?php the_ID() ?>" class="<?php blog_post_class() ?> small-post feed-post">
			<h3 class="entry-title recent-entry-title <?php echo font('titles')?>"><a href="<?php the_permalink() ?>" title="<?php printf(__('Permalink to %s', 'blog'), wp_specialchars(get_the_title(), 1)) ?>" rel="bookmark"><?php the_title() ?></a></h3>
			<?php if($item_options['show-date-post']): ?>
			<div class="feed-entry-date"><?php the_time('F j, Y') ?></div>
			<?php endif; ?>
		</div><!-- .post .small-post -->
					

<?php endwhile; ?>
<?php elseif($item_options['mode'] == 'rss'): ?>

	<?php
		include_once(ABSPATH . WPINC . '/rss.php');
		$rss_query = fetch_rss($item_options['rss-url']);
		if($rss_query) $items = array_slice($rss_query->items, 0, $item_options['item-limit']);
		
		if($item_options['nofollow']) $nofollow = ' rel="nofollow"';
	?>

	<?php
	if (empty($items)) echo '<p>The feed entered is either invalid or does not contain any items.</p>';
	else foreach ( $items as $item ) : 
		$count++;
	?>
	
	
	<div id="post-<?php echo $count?>" class="post small-post feed-post">
		<h3 class="entry-title recent-entry-title <?php echo font('titles')?>"><a href="<?php echo $item['link']?>"<?php echo $nofollow?>><?php echo $item['title']?></a></h3>
		<?php if($item_options['show-date-rss']): ?>
		<div class="feed-entry-date"><?php echo date('F j, Y', strtotime($item['pubdate'])) ?></div>
		<?php endif; ?>
	</div><!-- .post .small-post -->
	
	
	<?php endforeach; ?>
	
	
<?php endif; ?>


	<?php do_action('headway_leaf_content_bottom') ?>
	<?php do_action('headway_leaf_content_bottom_'.$leaf) ?>
</div>