<?php do_action('headway_leaf_top') ?>
<?php do_action('headway_leaf_top_'.$leaf) ?>

<?php if($item_options['show-title']): ?>
	<?php $leaf_title = ($item_options['leaf-title-link']) ? '<a href="'.$item_options['leaf-title-link'].'" title="">'.stripslashes($leaf_config[1]).'</a>' : stripslashes($leaf_config[1]) ; ?>
	<div class="leaf-top <?php echo font('leaf-headings') ?>"><?php echo $leaf_title ?></div>
<?php endif; ?>


<div class="leaf-content">
	<?php do_action('headway_leaf_content_top') ?>
	<?php do_action('headway_leaf_content_top_'.$leaf) ?>

	
	<?php
	if($item_options['date_format'] == '1') $date_format = 'F j, Y - g:i A';
	if($item_options['date_format'] == '2') $date_format = 'm/d/y - g:i A';
	if($item_options['date_format'] == '3') $date_format = 'd/m/y - g:i A';
	if($item_options['date_format'] == '4') $date_format = 'g:i A - M j';
	if($item_options['date_format'] == '5') $date_format = 'g:i A - M j, Y';	
	?>
		
	<ul class="twitter-updates">
	<?php getTwitterUpdates($item_options['twitter-username'], $item_options['tweet-limit'], $date_format) ?>
	</ul>
	
	<?php do_action('headway_leaf_content_bottom') ?>
	<?php do_action('headway_leaf_content_bottom_'.$leaf) ?>
</div>