<?php 
$item_options = db_to_leaf($item_options); 
//////////////////////////////////////////
//////////////////////////////////////////


$leaf_name = 'twitter';

if($item_options['show-title']) $checked['show-title'] = ' checked';


if($item_options['date_format'] == '1') $selected['date_format']['1'] = ' selected';
if($item_options['date_format'] == '2') $selected['date_format']['2'] = ' selected';
if($item_options['date_format'] == '3') $selected['date_format']['3'] = ' selected';
if($item_options['date_format'] == '4') $selected['date_format']['4'] = ' selected';
if($item_options['date_format'] == '5') $selected['date_format']['5'] = ' selected';




$defaults = array(
	'checked' => array('show-title'),
	'input' => array('tweet-limit' => '5')
);


//////////////////////////////////////////
//////////////////////////////////////////
if($javascript) $leaf = '{{leaf_id_replace}}';
$options = array(
	'id' => $leaf,
	'checked' => $checked,
	'selected' => $selected,
	'display' => $display,
	'item_options' => $item_options,
	'leaf_config' => $leaf_config
);

if($javascript):
	$register = registerLeaf($leaf_name, $options, $defaults);
else:
	$register = registerLeaf($leaf_name, $options);
endif;

$leaf_inner = $register[0];
?>