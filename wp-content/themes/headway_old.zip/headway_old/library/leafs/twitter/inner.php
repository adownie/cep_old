<form id="{!id!}_options_form">
		<fieldset>
			<h3>Options</h3>
							
				<label for="{!id!}-twitter-username">Twitter Username</label>
				<input type="text" value="{!input[twitter-username]!}" name="twitter-username" id="{!id!}-twitter-username" />
				
				<label for="{!id!}-tweet-limit">Tweet Limit</label>
				<input type="text" value="{!input[tweet-limit]!}" name="tweet-limit" id="{!id!}-tweet-limit" />
				
				
				
				<label id="{!id!}_date_format">Date/Time Format</label>
				<select name="date_format" id="{!id!}_date_format">
					<option value="1"{!selected[date_format][1]!}>January 1, 2009 - 12:00 AM</option>
					<option value="2"{!selected[date_format][2]!}>MM/DD/YY - 12:00 AM</option>
					<option value="3"{!selected[date_format][3]!}>DD/MM/YY - 12:00 AM</option>
					<option value="4"{!selected[date_format][4]!}>12:00 AM - Jan 1</option>
					<option value="5"{!selected[date_format][5]!}>12:00 AM - Jan 1, 2009</option>
				</select>
				
				
				
		</fieldset>
		
		<fieldset class="clear-both border-top">
			<h3>Miscellaneous</h3>			
			<input type="checkbox" name="show-title" id="{!id!}_show-title" class="check"{!checked[show-title]!} /><label for="{!id!}_show-title" class="no-clear">Show Box Title</label>		
			
			<label for="{!id!}-leaf-title-link">Leaf Title Link</label>
			<input type="text" value="{!input[leaf-title-link]!}" name="leaf-title-link" id="{!id!}-leaf-title-link" />		
			
			
			<label for="{!id!}-custom-css-class">Custom CSS Class(es)</label>
			<input type="text" value="{!input[custom-css-class]!}" name="custom-css-class" id="{!id!}-custom-css-class" />	
		</fieldset>
</form>