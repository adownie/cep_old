<?php
$item_options = db_to_leaf($item_options); 
//////////////////////////////////////////
//////////////////////////////////////////

$leaf_name = 'sidebar';





$selected = array();
$checked = array();




if($item_options['duplicate']) $checked['duplicate'] = ' checked';
if($item_options['no-padding']) $checked['no-padding'] = ' checked';
if($item_options['horizontal-sidebar']) $checked['horizontal-sidebar'] = ' checked';



$defaults = array(
	'checked' => array(),
	'input' => array()
);

$javascript_replace = array('id_formatted');





//////////////////////////////////////////
//////////////////////////////////////////


if($javascript):
	$leaf = '{{leaf_id_replace}}';
	$js_replace = $javascript_replace;
endif;

$options = array(
	'id' => $leaf,
	'checked' => $checked,
	'selected' => $selected,
	'display' => $display,
	'item_options' => $item_options,
	'leaf_config' => $leaf_config,
	'javascript_replace' => $js_replace
);


if($javascript):
	$register = registerLeaf($leaf_name, $options, $defaults);
else:
	$register = registerLeaf($leaf_name, $options);
endif;

$leaf_inner = $register[0];
?>