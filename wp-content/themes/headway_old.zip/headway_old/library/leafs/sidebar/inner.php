<form id="{!id!}_options_form">

		<p class="box" style="margin: 7px 0;">The ID for this sidebar is {!id_formatted!}</p>

		<fieldset>
			<h3>Options</h3>
			
				<input type="checkbox" name="duplicate" id="{!id!}_duplicate" class="check"{!checked[duplicate]!} /><label for="{!id!}_duplicate" class="no-clear">This is a duplicate sidebar.</label>
				
				<label for="{!id!}-duplicate-id">If you set the sidebar to duplicate, enter the other sidebar ID here.  You can get the ID of the other sidebar by clicking edit on the sidebar you wish to duplicate and looking at the box at the top containing the ID.</label>
				<input type="text" value="{!input[duplicate-id]!}" name="duplicate-id" id="{!id!}-duplicate-id" />
				
		</fieldset>
		
		
		
		
		
		<fieldset class="clear-both border-top">
			<h3>Miscellaneous</h3>			
			<label for="{!id!}-custom-css-class">Custom CSS Class(es)</label>
			<input type="text" value="{!input[custom-css-class]!}" name="custom-css-class" id="{!id!}-custom-css-class" />
			
			<input type="checkbox" name="horizontal-sidebar" id="{!id!}_horizontal-sidebar" class="check"{!checked[horizontal-sidebar]!} /><label for="{!id!}_horizontal-sidebar" class="no-clear">Flip this sidebar horizontally.  Check this if you want a "widgetized" footer.</label>
			<input type="checkbox" name="no-padding" id="{!id!}_no-padding" class="check"{!checked[no-padding]!} /><label for="{!id!}_no-padding" class="no-clear">Disable padding for this sidebar.</label>
		</fieldset>
		
		
	</form>