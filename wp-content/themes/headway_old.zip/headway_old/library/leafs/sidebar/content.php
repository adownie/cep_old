<?php do_action('headway_sidebar_top') ?>
<?php do_action('headway_sidebar_top_'.$leaf) ?>
<ul class="sidebar <?=font('sidebar')?>">
<?php
$id = $leaf;
if($item_options['duplicate'] == 'on') $id = 'item_'.$item_options['duplicate-id'];
?>
<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('sidebar-'.$id) ) : // begin primary sidebar widgets ?>
<?php endif; ?>
</ul>
<?php do_action('headway_sidebar_bottom') ?>
<?php do_action('headway_sidebar_bottom_'.$leaf) ?>