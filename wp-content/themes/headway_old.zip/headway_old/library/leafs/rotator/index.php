<?php
$item_options = db_to_leaf($item_options);
//////////////////////////////////////////
//////////////////////////////////////////


$leaf_name = 'rotator';





$checked = array();
$selected = array();

if($item_options['animation_type'] == 'fade'): $selected['animation_type']['fade'] = ' selected ';
elseif($item_options['animation_type'] == 'scrollUp'): $selected['animation_type']['scrollUp'] = ' selected ';
elseif($item_options['animation_type'] == 'scrollDown'): $selected['animation_type']['scrollDown'] = ' selected ';
elseif($item_options['animation_type'] == 'scrollLeft'): $selected['animation_type']['scrollLeft'] = ' selected ';
elseif($item_options['animation_type'] == 'scrollRight'): $selected['animation_type']['scrollRight'] = ' selected '; endif;
if($item_options['show-title'] == 'on'): $checked['show-title'] = ' checked '; endif;




$defaults = array(
	'checked' 	=> array(), 
	'input'		=> array('animation_speed' => 1, 'animation_timeout' => 7)
);















//////////////////////////////////////////
//////////////////////////////////////////

if($javascript):
	$leaf = '{{leaf_id_replace}}';
	$js_replace = $javascript_replace;
endif;

$options = array(
	'id' => $leaf,
	'checked' => $checked,
	'selected' => $selected,
	'display' => $display,
	'item_options' => $item_options,
	'leaf_config' => $leaf_config,
	'javascript_replace' => $js_replace,
	'select' => array('about_pages' => $about_pages)
);


if($javascript):
	$register = registerLeaf($leaf_name, $options, $defaults);
else:
	$register = registerLeaf($leaf_name, $options);
endif;

$leaf_inner = $register[0];
?>