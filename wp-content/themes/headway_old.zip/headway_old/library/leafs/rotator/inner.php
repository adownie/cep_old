		<form id="{!id!}_options_form">
			<fieldset>
				<h3>Images</h3>
				
				{script}
					var rotator_images_{!id!} = "#rotator_images_{!id!}";
					var rotator_images_{!id!}_anchor = "#rotator_images_{!id!}_anchor";
				{/script}
				<a href="#" onclick="edit_toggle_options(rotator_images_{!id!}, rotator_images_{!id!}_anchor); return false;" id="rotator_images_{!id!}_anchor" class="options-toggle">[+] Show Options</a>

				<div id="rotator_images_{!id!}" style="display: none;">
					
					<p class="box clear">For the sake of your visitors loading time, you are limited to 4 images in the rotator.</p>
					
					
					<label>Enter the URLs of the images below:</label>
				
					<p class="small small-label">Image 1</p><input type="text" value="{!input[image_1]!}" name="image_1" />
					<p class="small small-label">Image 2</p><input type="text" value="{!input[image_2]!}" name="image_2" />
					<p class="small small-label">Image 3</p><input type="text" value="{!input[image_3]!}" name="image_3" />
					<p class="small small-label">Image 4</p><input type="text" value="{!input[image_4]!}" name="image_4" />
				
					<label>If you want to add hyperlinks to each image, enter them below.</label>
				
					<p class="small small-label">Image 1</p><input type="text" value="{!input[image_1_hyperlink]!}" name="image_1_hyperlink" />
					<p class="small small-label">Image 2</p><input type="text" value="{!input[image_2_hyperlink]!}" name="image_2_hyperlink" />
					<p class="small small-label">Image 3</p><input type="text" value="{!input[image_3_hyperlink]!}" name="image_3_hyperlink" />
					<p class="small small-label">Image 4</p><input type="text" value="{!input[image_4_hyperlink]!}" name="image_4_hyperlink" />
				
				</div>
				
			</fieldset>
			
			<fieldset>
				<h3>Animation</h3>
				
				{script}
					var rotator_animation_{!id!} = "#rotator_animation_{!id!}";
					var rotator_animation_{!id!}_anchor = "#rotator_animation_{!id!}_anchor";
				{/script}
				<a href="#" onclick="edit_toggle_options(rotator_animation_{!id!}, rotator_animation_{!id!}_anchor); return false;" id="rotator_animation_{!id!}_anchor" class="options-toggle">[+] Show Options</a>

				<div id="rotator_animation_{!id!}" style="display: none;">
					
					<label for="{!id!}_animation_type">Animation Type:</label>
					<select name="animation_type" id="{!id!}_animation_type">
						<option value="fade"{!selected[animation_type][fade]!}>Fade</option>
						<option value="scrollUp"{!selected[animation_type][scrollUp]!}>Scroll Up</option>
						<option value="scrollDown"{!selected[animation_type][scrollDown]!}>Scroll Down</option>
						<option value="scrollLeft"{!selected[animation_type][scrollLeft]!}>Scroll Left</option>
						<option value="scrollRight"{!selected[animation_type][scrollRight]!}>Scroll Right</option>
					</select>
					<label for="{!id!}_animation-speed">Animation Speed:</label>
					<input type="text" name="animation_speed" id="{!id!}_animation-speed" value="{!input[animation_speed]!}" /> <p class="small">Second(s)</p>
				
					<label for="{!id!}_animation-timeout">Timeout (Time Between Images):</label>
					<input type="text" name="animation_timeout" id="{!id!}_animation-timeout" value="{!input[animation_timeout]!}" /> <p class="small">Second(s)</p>
				
				</div>
				
			</fieldset>
			
			<fieldset class="clear-both">
				<h3>Miscellaneous</h3>		
				
				{script}
					var rotator_misc_{!id!} = "#rotator_misc_{!id!}";
					var rotator_misc_{!id!}_anchor = "#rotator_misc_{!id!}_anchor";
				{/script}
				<a href="#" onclick="edit_toggle_options(rotator_misc_{!id!}, rotator_misc_{!id!}_anchor); return false;" id="rotator_misc_{!id!}_anchor" class="options-toggle">[+] Show Options</a>

				<div id="rotator_misc_{!id!}" style="display: none;">
					
					<input type="checkbox" name="show-title" id="{!id!}_show-title" class="check"{!checked[show-title]!} /><label for="{!id!}_show-title" class="no-clear">Show Box Title</label>		

					<label for="{!id!}-leaf-title-link">Leaf Title Link</label>
					<input type="text" value="{!input[leaf-title-link]!}" name="leaf-title-link" id="{!id!}-leaf-title-link" />		


					<label for="{!id!}-custom-css-class">Custom CSS Class(es)</label>
					<input type="text" value="{!input[custom-css-class]!}" name="custom-css-class" id="{!id!}-custom-css-class" />	
				
				</div>
			</fieldset>
		</form>