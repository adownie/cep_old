<?php do_action('headway_leaf_top') ?>
<?php do_action('headway_leaf_top_'.$leaf) ?>

<?php if($item_options['show-title']): ?>
	<?php $leaf_title = ($item_options['leaf-title-link']) ? '<a href="'.$item_options['leaf-title-link'].'" title="">'.stripslashes($leaf_config[1]).'</a>' : stripslashes($leaf_config[1]) ; ?>
	<div class="leaf-top <?php echo font('leaf-headings') ?>"><?php echo $leaf_title ?></div>
<?php endif; ?>

<div class="leaf-content">
	<?php do_action('headway_leaf_content_top') ?>
	<?php do_action('headway_leaf_content_top_'.$leaf) ?>

<div class="rotator-images">
		<?php leaf_rotator_print_image($item_options['image_1'], $item_options['image_1_hyperlink']); ?>
		<?php leaf_rotator_print_image($item_options['image_2'], $item_options['image_2_hyperlink']); ?>
		<?php leaf_rotator_print_image($item_options['image_3'], $item_options['image_3_hyperlink']); ?>
		<?php leaf_rotator_print_image($item_options['image_4'], $item_options['image_4_hyperlink']); ?>
</div>


	<?php do_action('headway_leaf_content_bottom') ?>
	<?php do_action('headway_leaf_content_bottom_'.$leaf) ?>
</div>