<?php
$item_options = db_to_leaf($item_options);
//////////////////////////////////////////
//////////////////////////////////////////


$javascript_replace = array('select[categories_select]');
$leaf_name = 'featured';


if(function_exists('get_categories')):
	if($categories_select): //Fixes select for multiple featured boxes.  Without this it will compound the categories.
		$categories_select = '';
		$categories = '';
		$select_selected = array();
	endif;
	
		$categories = explode(' | ', $item_options['categories']);
		$categories_select_query = get_categories();
		foreach($categories_select_query as $category){ 
			if(in_array($category->term_id, $categories)) $select_selected[$category->term_id] = ' selected';
	
			$categories_select .= '<option value="'.$category->term_id.'"'.$select_selected[$category->term_id].'>'.$category->name.'</option>';
	
		}
endif;


$display['image-options'] = 'display: none;';

$selected = array();
$checked = array();

if($item_options['mode'] == 'text'): $checked['text'] = ' checked';  endif;
if($item_options['mode'] == 'images'): $checked['images'] = ' checked'; $display['image-options'] = ''; endif;
if($item_options['show-title']) $checked['show-title'] = ' checked';
if($item_options['rotate_posts']) $checked['rotate_posts'] = ' checked';
if($item_options['image_location'] == 'left') $selected['image-location']['left'] = ' selected';
if($item_options['image_location'] == 'right') $selected['image-location']['right'] = ' selected';
if($item_options['date_location'] == 'title-bottom') $selected['date_location']['title-bottom'] = ' selected';
if($item_options['date_location'] == 'title-top') $selected['date_location']['title-top'] = ' selected';
if($item_options['date_location'] == 'bottom') $selected['date_location']['bottom'] = ' selected';
if($item_options['date_location'] == 'hidden') $selected['date_location']['hidden'] = ' selected';
if($item_options['date_format'] == '1') $selected['date_format']['1'] = ' selected';
if($item_options['date_format'] == '2') $selected['date_format']['2'] = ' selected';
if($item_options['date_format'] == '3') $selected['date_format']['3'] = ' selected';
if($item_options['date_format'] == '4') $selected['date_format']['4'] = ' selected';
if($item_options['date_format'] == '5') $selected['date_format']['5'] = ' selected';
if($item_options['date_format'] == '6') $selected['date_format']['6'] = ' selected';
if($item_options['date_format'] == '7') $selected['date_format']['7'] = ' selected';
if($item_options['date_format'] == '8') $selected['date_format']['8'] = ' selected';
if($item_options['comment_location'] == 'title-bottom') $selected['comment_location']['title-bottom'] = ' selected';
if($item_options['comment_location'] == 'title-top') $selected['comment_location']['title-top'] = ' selected';
if($item_options['comment_location'] == 'bottom') $selected['comment_location']['bottom'] = ' selected';
if($item_options['comment_location'] == 'hidden') $selected['comment_location']['hidden'] = ' selected';
if($item_options['comment_format'] == '1') $selected['comment_format']['1'] = ' selected';
if($item_options['comment_format'] == '2') $selected['comment_format']['2'] = ' selected';
if($item_options['comment_format'] == '3') $selected['comment_format']['3'] = ' selected';
if($item_options['cutoff'] == 'read-more') $checked['read-more'] = ' checked';
if($item_options['cutoff'] == 'excerpt') $checked['excerpt'] = ' checked';


if($item_options['animation_type'] == 'fade'): $selected['animation_type']['fade'] = ' selected ';
elseif($item_options['animation_type'] == 'scrollHorz'): $selected['animation_type']['scrollHorz'] = ' selected ';
elseif($item_options['animation_type'] == 'scrollVert'): $selected['animation_type']['scrollVert'] = ' selected ';
endif;



if($item_options['rotate_nav_location'] == 'hidden') $selected['rotate_nav_location']['hidden'] = ' selected';
if($item_options['rotate_nav_location'] == 'inside') $selected['rotate_nav_location']['inside'] = ' selected';
if($item_options['rotate_nav_location'] == 'outside') $selected['rotate_nav_location']['outside'] = ' selected';





$defaults = array(
	'checked' => array('show-title', 'text', 'excerpt'),
	'input' => array(
		'rotate_limit' => '1', 
		'animation_speed' => '1', 
		'animation_timeout' => '5', 
		'read-more-language' => 'Read More',
		'featured-meta-title-above-left' => get_option('post-above-title-left'),
		'featured-meta-title-above-right' => get_option('post-above-title-right'),
		'featured-meta-title-below-left' => get_option('post-below-title-left'),
		'featured-meta-title-below-right' => get_option('post-below-title-right'),
		'featured-meta-content-below-left' => get_option('post-below-content-left'),
		'featured-meta-content-below-right' => get_option('post-below-content-right'),
	)
);








//////////////////////////////////////////
//////////////////////////////////////////

if($javascript):
	$leaf = '{{leaf_id_replace}}';
	$js_replace = $javascript_replace;
endif;

$options = array(
	'id' => $leaf,
	'checked' => $checked,
	'selected' => $selected,
	'display' => $display,
	'item_options' => $item_options,
	'leaf_config' => $leaf_config,
	'javascript_replace' => $js_replace,
	'select' => array('categories_select' => $categories_select)
);


if($javascript):
	$register = registerLeaf($leaf_name, $options, $defaults);
else:
	$register = registerLeaf($leaf_name, $options);
endif;

$leaf_inner = $register[0];
?>