<form id="{!id!}_options_form">

		<fieldset>
			<h3>Options</h3>
			{script}
				var featured_config_{!id!} = "#{!id!}_featured_config";
				var featured_config_anchor_{!id!} = "#{!id!}_featured_config_anchor";
			{/script}
			<a href="#" onclick="edit_toggle_options(featured_config_{!id!}, featured_config_anchor_{!id!}); return false;" id="{!id!}_featured_config_anchor" class="options-toggle">[+] Show Options</a>
			
			<div id="{!id!}_featured_config" style="display: none;">
			
				<label for="{!id!}_mode">Mode</label>
				{script}
					var item_options_{!id!} = ".{!id!}_image_options";
				{/script}
				<input type="radio" name="mode" id="{!id!}_mode-text-only" class="radio"{!checked[text]!} value="text" onclick="$(item_options_{!id!}).hide();"/><label for="{!id!}_mode-text-only" class="no-clear">Text Only</label>
				<input type="radio" name="mode" id="{!id!}_mode-image" class="radio"{!checked[images]!} value="images" onclick="$(item_options_{!id!}).show();" /><label for="{!id!}_mode-image" class="no-clear">Show Images</label>
			
			
			
				<p id="{!id!}_mode-image" class="{!id!}_image_options box" style="{!display[image-options]!}clear:both;margin: 5px 0 0;float:left;">Use <strong>{!id!}_featured_image</strong> as a custom field on each featured to display an image in this leaf.</p>
			
				<label for="{!id!}_image-width" class="{!id!}_image_options" style="{!display[image-options]!}">Image Width:</label>
				<input type="text" name="image_width" id="{!id!}_image-width" value="{!input[image_width]!}" class="{!id!}_image_options" style="{!display[image-options]!}" />
				<p class="{!id!}_image_options small" style="{!display[image-options]!}"><code>px</code></p>
			
				<label for="{!id!}_image-height" class="{!id!}_image_options" style="{!display[image-options]!}">Image Height:</label>
				<input type="text" name="image_height" id="{!id!}_image-height" value="{!input[image_height]!}" class="{!id!}_image_options" style="{!display[image-options]!}" />
				<p class="{!id!}_image_options small" style="{!display[image-options]!}"><code>px</code></p>
				
				<label for="{!id!}_image-location" class="{!id!}_image_options" style="{!display[image-options]!}">Image Location:</label>
				<select name="image_location" id="{!id!}_image-location" class="{!id!}_image_options" style="{!display[image-options]!}">
					<option value="left"{!selected[image_location][left]!}>Left</option>
					<option value="right"{!selected[image_location][right]!}>Right</option>
				</select>
		

				<label for="{!id!}-categories">Categories</label>
				<select name="categories" id="{!id!}-categories" multiple size="5">
					{!select[categories_select]!}
				</select>
			</div>
				
		
		</fieldset>
		
		<fieldset>
			<h3>Post Meta Customization</h3>
			{script}
				var featured_post_meta_{!id!} = "#{!id!}_featured_post_meta";
				var featured_post_meta_anchor_{!id!} = "#{!id!}_featured_post_meta_anchor";
			{/script}
			<a href="#" onclick="edit_toggle_options(featured_post_meta_{!id!}, featured_post_meta_anchor_{!id!}); return false;" id="{!id!}_featured_post_meta_anchor" class="options-toggle">[+] Show Options</a>

			<div id="{!id!}_featured_post_meta" style="display: none;">

		

				<label for="{!id!}-featured-meta-title-above-left">Above Title - Left</label>
				<input type="text" value="{!input[featured-meta-title-above-left]!}" name="featured-meta-title-above-left" id="{!id!}-featured-meta-title-above-left" />
				
				<label for="{!id!}-featured-meta-title-above-right">Above Title - Right</label>
				<input type="text" value="{!input[featured-meta-title-above-right]!}" name="featured-meta-title-above-right" id="{!id!}-featured-meta-title-above-right" />
				
				<label for="{!id!}-featured-meta-title-below-left">Below Title - Left</label>
				<input type="text" value="{!input[featured-meta-title-below-left]!}" name="featured-meta-title-below-left" id="{!id!}-featured-meta-title-below-left" />
				
				<label for="{!id!}-featured-meta-title-below-right">Below Title - Right</label>
				<input type="text" value="{!input[featured-meta-title-below-right]!}" name="featured-meta-title-below-right" id="{!id!}-featured-meta-title-below-right" />
				
				<label for="{!id!}-featured-meta-content-below-left">Below Content - Left</label>
				<input type="text" value="{!input[featured-meta-content-below-left]!}" name="featured-meta-content-below-left" id="{!id!}-featured-meta-content-below-left" />
				
				<label for="{!id!}-featured-meta-content-below-right">Below Content - Right</label>
				<input type="text" value="{!input[featured-meta-content-below-right]!}" name="featured-meta-content-below-right" id="{!id!}-featured-meta-content-below-right" />
				

			
			</div>
		</fieldset>
	

		<fieldset>
			<h3>Post Display</h3>
			{script}
				var post_options_{!id!} = "#{!id!}_post_options";
				var post_options_anchor_{!id!} = "#{!id!}_post_options_anchor";
			{/script}
			<a href="#" onclick="edit_toggle_options(post_options_{!id!}, post_options_anchor_{!id!}); return false;" id="{!id!}_post_options_anchor" class="options-toggle">[+] Show Options</a>
			
			
				
			<div id="{!id!}_post_options" style="display: none;">
					
				<label>Text Cutoff</label>
				<input type="radio" name="cutoff" id="{!id!}_cutoff_excerpt" class="radio"{!checked[excerpt]!} value="excerpt" /><label for="{!id!}_cutoff_excerpt" class="no-clear">Excerpt (Limits Characters)</label>
				<input type="radio" name="cutoff" id="{!id!}_cutoff_read_more" class="radio"{!checked[read-more]!} value="read-more" /><label for="{!id!}_cutoff_read_more" class="no-clear">Depend on Read More tag.</label>
			
			
				<label for="{!id!}-read-more-language">Read More Text</label>
				<input type="text" value="{!input[read-more-language]!}" name="read-more-language" id="{!id!}-read-more-language" />
			
			</div>
			
			
		</fieldset>
		
			<fieldset>
				<h3>Rotate</h3>
				{script}
					var rotate_options_{!id!} = "#{!id!}_rotate_options";
					var rotate_options_anchor_{!id!} = "#{!id!}_rotate_options_anchor";
				{/script}
				<a href="#" onclick="edit_toggle_options(rotate_options_{!id!}, rotate_options_anchor_{!id!}); return false;" id="{!id!}_rotate_options_anchor" class="options-toggle">[+] Show Options</a>
					<div id="{!id!}_rotate_options" style="display: none;">
						<input type="checkbox" name="rotate_posts" id="{!id!}_rotate_posts" class="check"{!checked[rotate_posts]!} /><label for="{!id!}_rotate_posts" class="no-clear">Rotate Posts</label>

						<label for="{!id!}_rotate_limit" class="{!id!}_rotate_options">Limit to how many posts?</label>
						<input type="text" name="rotate_limit" id="{!id!}_rotate_limit" value="{!input[rotate_limit]!}" class="{!id!}_rotate_options" />

							<label for="{!id!}_animation_type" class="{!id!}_rotate_options">Animation Type:</label>
							<select name="animation_type" id="{!id!}_animation_type" class="{!id!}_rotate_options">
								<option value="fade"{!selected[animation_type][fade]!}>Fade</option>
								<option value="scrollHorz"{!selected[animation_type][scrollHorz]!}>Scroll Horizontally</option>
								<option value="scrollVert"{!selected[animation_type][scrollVert]!}>Scroll Vertically</option>
							</select>
							<label for="{!id!}_animation-speed" class="{!id!}_rotate_options">Animation Speed:</label>
							<input type="text" name="animation_speed" id="{!id!}_animation-speed" value="{!input[animation_speed]!}" class="{!id!}_rotate_options" /> <p class="small {!id!}_rotate_options">Second(s)</p>

							<label for="{!id!}_animation-timeout" class="{!id!}_rotate_options">Timeout (Time Between Posts):</label>
							<input type="text" name="animation_timeout" id="{!id!}_animation-timeout" value="{!input[animation_timeout]!}" class="{!id!}_rotate_options" /> <p class="small {!id!}_rotate_options">Second(s)</p>


						<label for="{!id!}_rotate_posts_nav_location" class="{!id!}_rotate_options">Next/Previous Location</label>
						<select name="rotate_nav_location" id="{!id!}_nav_location" class="{!id!}_rotate_options">
							<option value="hidden"{!selected[rotate_nav_location][hidden]!}>Do Not Show</option>
							<option value="inside"{!selected[rotate_nav_location][inside]!}>Inside Post</option>
							<option value="outside"{!selected[rotate_nav_location][outside]!}>Outside Container</option>
						</select>
					</div>
			</fieldset>

		
		<fieldset>
			<h3>Miscellaneous</h3>			
			<input type="checkbox" name="show-title" id="{!id!}_show-title" class="check"{!checked[show-title]!} /><label for="{!id!}_show-title" class="no-clear">Show Box Title</label>		
			
			<label for="{!id!}-leaf-title-link">Leaf Title Link</label>
			<input type="text" value="{!input[leaf-title-link]!}" name="leaf-title-link" id="{!id!}-leaf-title-link" />		
			
			
			<label for="{!id!}-custom-css-class">Custom CSS Class(es)</label>
			<input type="text" value="{!input[custom-css-class]!}" name="custom-css-class" id="{!id!}-custom-css-class" />	
		</fieldset>
		
	</form>