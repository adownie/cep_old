<?php $categories = explode(' | ', $item_options['categories']); ?>



	<?php do_action('headway_leaf_top') ?>
	<?php do_action('headway_leaf_top_'.$leaf) ?>

	<?php if($item_options['show-title']): ?>
		<?php $leaf_title = ($item_options['leaf-title-link']) ? '<a href="'.$item_options['leaf-title-link'].'" title="">'.stripslashes($leaf_config[1]).'</a>' : stripslashes($leaf_config[1]) ; ?>
		<div class="leaf-top <?php echo font('leaf-headings') ?>"><?php echo $leaf_title ?></div>
	<?php endif; ?>
	
	
	<div class="leaf-content featured-leaf-content">
		<?php do_action('headway_leaf_content_top') ?>
		<?php do_action('headway_leaf_content_top_'.$leaf) ?>
		<?php
		if(!$item_options['rotate_limit']):
			$rotate_limit = 1;
		else:
			$rotate_limit = $item_options['rotate_limit'];
		endif;
		
		if($item_options['categories']):
			$featured_loop[$leaf] = new WP_Query(array('category__in' => $categories, 'showposts' => $rotate_limit));
		else:
			$featured_loop[$leaf] = new WP_Query(array('showposts' => $rotate_limit));
		endif;

		global $more;
		$more = 0;
		?>
		<?php while ( $featured_loop[$leaf]->have_posts() ) : $featured_loop[$leaf]->the_post() ?>
			<div class="featured-post" id="featured-post-<?php the_id() ?>">
				<?php
				if(get_post_meta(get_the_id(), $leaf.'_featured_image', true) && $item_options['mode'] == 'images'){
				
					if($item_options['image_width'] && $item_options['image_height']):
						$image[get_the_id()] = '<div class="featured-image featured-image-'.$item_options['image_location'].'" style="width:'.$item_options['image_width'].'px"><img src="'.get_bloginfo('template_directory').'/library/resources/thumbnail.php?src='.get_post_meta(get_the_id(), $leaf.'_featured_image', true).'&amp;w='.$item_options['image_width'].'&amp;h='.$item_options['image_height'].'" alt="'.get_the_title().'" /></div>';
					else:
						$image[get_the_id()] = '<div class="featured-image featured-image-'.$item_options['image_location'].'"><img src="'.get_post_meta(get_the_id(), $leaf.'_featured_image', true).'" alt="'.get_the_title().'" /></div>';
					endif;
					
					

					if($item_options['image_location'] == 'left') $post_left[get_the_id()] .= $image[get_the_id()];
					if($item_options['image_location'] == 'right') $post_right[get_the_id()] .= $image[get_the_id()];
				
				
					$count++;
					
					$container_width = $leaf_config[2]-$item_options['image_width']-10;
					$container_width = ' style="width:'.$container_width.'px"';
				
				} else {
					$container_width = '';
				}
				?>
			
				<?php echo $post_left[get_the_id()]?>
				
			      <?php do_action('headway_above_post') ?>
				  <div class="featured-post-container"<?php echo $container_width?>>
					<?php post_meta('title', 'above', true, $item_options['featured-meta-title-above-left'], $item_options['featured-meta-title-above-right']); ?>
					<h3 class="featured-entry-title entry-title <?php echo font('titles')?>"><a href="<?php the_permalink() ?>" title="<?php echo get_the_title();?>" rel="bookmark"><?php the_title() ?></a></h3>
					<?php post_meta('title', 'below', true, $item_options['featured-meta-title-below-left'], $item_options['featured-meta-title-below-right']); ?>
				
				
				
					<div class="featured-entry-content">
						<?php
							if($item_options['cutoff'] == 'read-more') the_content($item_options['read-more-language']);
							if($item_options['cutoff'] == 'excerpt'):
								the_excerpt();
								echo '<a href="'.get_permalink().'" title="'.get_the_title().'" class="more-link featured-more-link">'.$item_options['read-more-language'].'</a>';
							endif;
						?>
					</div>
				
					<?php post_meta('content', 'below', true, $item_options['featured-meta-content-below-left'], $item_options['featured-meta-content-below-right']); ?>
				  </div>
				
				
				
				<?php echo $post_right[get_the_id()]?>
				
				<?php if($item_options['rotate_nav_location'] == 'inside'): ?>
					<a href="#" class="<?php echo $leaf ?>_featured_prev featured_prev featured_inside_prev">Previous</a>
					<a href="#" class="<?php echo $leaf ?>_featured_next featured_next featured_inside_next">Next</a>
				<?php endif; ?>
			</div>
		<?php endwhile; ?>
		<?php do_action('headway_leaf_content_bottom') ?>
		<?php do_action('headway_leaf_content_bottom_'.$leaf) ?>
	</div>
	<?php if($item_options['rotate_nav_location'] == 'outside'): ?>
		<a href="#" id="<?php echo $leaf ?>_featured_prev" class="featured_prev featured_outside_prev">Previous</a>
		<a href="#" id="<?php echo $leaf ?>_featured_next" class="featured_next featured_outside_next">Next</a>
	<?php endif; ?>
