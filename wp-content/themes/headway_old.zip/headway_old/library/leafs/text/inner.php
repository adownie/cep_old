<form id="{!id!}_options_form">
		<fieldset>
			<label for="{!id!}_text-content">Content</label>
			<textarea id="{!id!}_text-content" name="content" class="text-content">{!text!}</textarea>
		</fieldset>
		
		<fieldset class="clear-both">
			<h3>Dynamic Content</h3>		
			<p class="box" style="clear: both; flaot: left; margin: 5px 0;">By enabling dynamic content you can add a text leaf to a single post and change what is in the box for each post.  This is useful if you want to put a YouTube video in the sidebar for a certain post.  The options are limitless.</p>	
			<input type="checkbox" name="dynamic-content" id="{!id!}_dynamic-content" class="check"{!checked[dynamic-content]!} /><label for="{!id!}_dynamic-content" class="no-clear">Enable Dynamic Content</label>
		</fieldset>
		
		<fieldset class="clear-both">
			<h3>Miscellaneous</h3>			
			<input type="checkbox" name="show-title" id="{!id!}_show-title" class="check"{!checked[show-title]!} /><label for="{!id!}_show-title" class="no-clear">Show Box Title</label>		
			
			<label for="{!id!}-leaf-title-link">Leaf Title Link</label>
			<input type="text" value="{!input[leaf-title-link]!}" name="leaf-title-link" id="{!id!}-leaf-title-link" />		
			
			
			<label for="{!id!}-custom-css-class">Custom CSS Class(es)</label>
			<input type="text" value="{!input[custom-css-class]!}" name="custom-css-class" id="{!id!}-custom-css-class" />	
		</fieldset>

</form>