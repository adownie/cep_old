<? 
$item_options = db_to_leaf($item_options); 
//////////////////////////////////////////
//////////////////////////////////////////

if($_POST['layout-page']) $text = base64_decode(get_post_meta($_POST['layout-page'], '_'.$leaf.'_text', true));
if($_POST['layout-system-page']) $text = base64_decode(get_option('system-page-'.$_POST['layout-system-page'].'-'.$leaf.'_text'));

$leaf_name = 'text';
 

if($item_options['show-title']) $checked['show-title'] = ' checked';
if($item_options['dynamic-content']) $checked['dynamic-content'] = ' checked';



$defaults = array('checked' => array('show-title'));


//////////////////////////////////////////
//////////////////////////////////////////
if($javascript) $leaf = '{{leaf_id_replace}}';
$options = array(
	'id' => $leaf,
	'checked' => $checked,
	'selected' => $selected,
	'display' => $display,
	'item_options' => $item_options,
	'leaf_config' => $leaf_config,
	'text' => $text
);

if($javascript):
	$register = registerLeaf($leaf_name, $options, $defaults);
else:
	$register = registerLeaf($leaf_name, $options);
endif;

$leaf_inner = $register[0];
?>