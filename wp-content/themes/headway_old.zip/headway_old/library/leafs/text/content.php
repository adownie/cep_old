<?php 
if($page_id) $text = base64_decode(get_post_meta($page_id, '_'.$leaf.'_text', true));
if($system_page_id) $text = base64_decode(get_option('system-page-'.$system_page_id.'-'.$leaf.'_text'));

if($text || get_write_box_value('dynamic-content')){ 

do_action('headway_leaf_top') ;
do_action('headway_leaf_top_'.$leaf);

if($item_options['show-title']): ?>
	<?php $leaf_title = ($item_options['leaf-title-link']) ? '<a href="'.$item_options['leaf-title-link'].'" title="">'.stripslashes($leaf_config[1]).'</a>' : stripslashes($leaf_config[1]) ; ?>
	<div class="leaf-top <?php echo font('leaf-headings') ?>"><?php echo $leaf_title ?></div>
<?php endif; ?>


<div class="leaf-content">
	<?php do_action('headway_leaf_content_top') ?>
	<?php do_action('headway_leaf_content_top_'.$leaf) ?>
		
	<?php 
	if($item_options['dynamic-content'] && get_write_box_value('dynamic-content')){
		echo parse_php(stripslashes(html_entity_decode(get_write_box_value('dynamic-content'))));
	} else {
		echo parse_php(stripslashes(html_entity_decode($text)));
	}
	?>
	
	<?php do_action('headway_leaf_content_bottom') ?>
	<?php do_action('headway_leaf_content_bottom_'.$leaf) ?>
</div>
<?php } ?>