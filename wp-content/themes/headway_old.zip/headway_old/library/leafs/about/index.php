<?php
$item_options = db_to_leaf($item_options);
//////////////////////////////////////////
//////////////////////////////////////////


$javascript_replace = array('select[about_pages]');
$leaf_name = 'about';




if(function_exists('get_pages')):
	$about_pages = '<option value=""></option>';
	$page_select_query = get_pages();
	foreach($page_select_query as $page){ 
		if($page->ID == $item_options['read-more-page']) $selected[$page->ID] = ' selected';
		$about_pages .= '<option value="'.$page->ID.'"'.$selected[$page->ID].'>'.$page->post_title.'</option>';
	}
endif;



if($item_options['image-align'] == 'right') $selected['right'] = ' selected';
if($item_options['show-read-more']) $checked['show-read-more'] = ' checked';
if($item_options['show-title']) $checked['show-title'] = ' checked';




$defaults = array(
	'checked' => array('show-title'), 
	'input' => array('read-more-language' => 'Read More &raquo;')
);















//////////////////////////////////////////
//////////////////////////////////////////

if($javascript):
	$leaf = '{{leaf_id_replace}}';
	$js_replace = $javascript_replace;
endif;

$options = array(
	'id' => $leaf,
	'checked' => $checked,
	'selected' => $selected,
	'display' => $display,
	'item_options' => $item_options,
	'leaf_config' => $leaf_config,
	'javascript_replace' => $js_replace,
	'select' => array('about_pages' => $about_pages)
);


if($javascript):
	$register = registerLeaf($leaf_name, $options, $defaults);
else:
	$register = registerLeaf($leaf_name, $options);
endif;

$leaf_inner = $register[0];
?>