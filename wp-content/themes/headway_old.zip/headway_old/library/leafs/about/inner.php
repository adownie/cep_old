<form id="{!id!}_options_form">
		<fieldset>
			<h3>Blurb</h3>
			
			{script}
				var about_blurb_{!id!} = "#about_blurb_{!id!}";
				var about_blurb_anchor{!id!} = "#about_blurb_anchor{!id!}";
			{/script}
			<a href="#" onclick="edit_toggle_options(about_blurb_{!id!}, about_blurb_anchor{!id!}); return false;" id="about_blurb_anchor{!id!}" class="options-toggle">[+] Show Options</a>
		
			<div id="about_blurb_{!id!}" style="display: none;">
				<label for="{!id!}-about-blurb">Blurb</label>
				<textarea id="{!id!}-about-blurb" name="blurb" class="big-textarea">{!input[blurb]!}</textarea>
			</div>
		</fieldset>
		
		<fieldset>
			<h3>Image/Portrait</h3>
			
			{script}
				var about_image_{!id!} = "#about_image_{!id!}";
				var about_image_anchor{!id!} = "#about_image_anchor{!id!}";
			{/script}
			<a href="#" onclick="edit_toggle_options(about_image_{!id!}, about_image_anchor{!id!}); return false;" id="about_image_anchor{!id!}" class="options-toggle">[+] Show Options</a>
		
			<div id="about_image_{!id!}" style="display: none;">
				<label for="{!id!}-about-image">Image</label>
				<input type="text" id="{!id!}-about-image" name="image" value="{!input[image]!}" />
				<p class="small">Image must be located locally for thumbnail resizing to work.</p>
			
				<label for="{!id!}-about-image-align">Image Align</label>
				<select id="{!id!}-about-image-align" name="image-align">
					<option value="left"{!selected[left]!}>Left</option>
					<option value="right"{!selected[right]!}>Right</option>
				</select>
			
				<label for="{!id!}-image-width">Image Width</label>
				<input type="text" id="{!id!}-image-width" name="image-width" value="{!input[image-width]!}" />
				<p class="small"><code>px</code></p>
			
				<label for="{!id!}-image-height">Image Height</label>
				<input type="text" id="{!id!}-image-height" name="image-height" value="{!input[image-height]!}" />
				<p class="small"><code>px</code></p>
			</div>
		</fieldset>

		
		<fieldset>
			<h3>[Read] More Link</h3>
			
			{script}
				var about_link_{!id!} = "#about_link_{!id!}";
				var about_link_anchor{!id!} = "#about_link_anchor{!id!}";
			{/script}
			<a href="#" onclick="edit_toggle_options(about_link_{!id!}, about_link_anchor{!id!}); return false;" id="about_link_anchor{!id!}" class="options-toggle">[+] Show Options</a>
		
			<div id="about_link_{!id!}" style="display: none;">		
				<input type="checkbox" name="show-read-more" id="{!id!}-show-read-more" class="check"{!checked[show-read-more]!} /><label for="{!id!}-show-read-more" class="no-clear">Show Read More Link</label>
			
				<label for="{!id!}-read-more-href">Read More Location</label>
				<input type="text" value="{!input[read-more-href]!}" name="read-more-href" id="{!id!}-read-more-href" />
				<label for="{!id!}-read-more-page">OR Link To Page</label>
			
				<select name="read-more-page" id="{!id!}-read-more-page">
					{!select[about_pages]!}
				</select>
			
			
				<label for="{!id!}-read-more-language">Read More Text</label>
				<input type="text" value="{!input[read-more-language]!}" name="read-more-language" id="{!id!}-read-more-language" />
			</div>
			
		</fieldset>
		
		
		<fieldset class="clear-both">
			<h3>Miscellaneous</h3>	
			{script}
				var about_misc_{!id!} = "#about_misc_{!id!}";
				var about_misc_anchor{!id!} = "#about_misc_anchor{!id!}";
			{/script}
			<a href="#" onclick="edit_toggle_options(about_misc_{!id!}, about_misc_anchor{!id!}); return false;" id="about_misc_anchor{!id!}" class="options-toggle">[+] Show Options</a>
		
			<div id="about_misc_{!id!}" style="display: none;">		
				<input type="checkbox" name="show-title" id="{!id!}_show-title" class="check"{!checked[show-title]!} /><label for="{!id!}_show-title" class="no-clear">Show Box Title</label>		
			
				<label for="{!id!}-leaf-title-link">Leaf Title Link</label>
				<input type="text" value="{!input[leaf-title-link]!}" name="leaf-title-link" id="{!id!}-leaf-title-link" />		
			
			
				<label for="{!id!}-custom-css-class">Custom CSS Class(es)</label>
				<input type="text" value="{!input[custom-css-class]!}" name="custom-css-class" id="{!id!}-custom-css-class" />	
			</div>
		</fieldset>
		
		
	</form>