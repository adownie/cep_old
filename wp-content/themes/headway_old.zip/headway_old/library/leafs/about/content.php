<?php do_action('headway_leaf_top') ?>
<?php do_action('headway_leaf_top_'.$leaf) ?>

<?php if($item_options['show-title']): ?>
	<?php $leaf_title = ($item_options['leaf-title-link']) ? '<a href="'.$item_options['leaf-title-link'].'" title="">'.stripslashes($leaf_config[1]).'</a>' : stripslashes($leaf_config[1]) ; ?>
	<div class="leaf-top <?php echo font('leaf-headings') ?>"><?php echo $leaf_title ?></div>
<?php endif; ?>

<div class="leaf-content">
	<?php do_action('headway_leaf_content_top') ?>
	<?php do_action('headway_leaf_content_top_'.$leaf) ?>
	
	<?php
	if(urldecode($item_options['image'])):
		
	if($item_options['image-width'] && $item_options['image-height']):
		echo '<img src="'.get_bloginfo('template_directory').'/library/resources/thumbnail.php?src='.urldecode($item_options['image']).'&amp;w='.$item_options['image-width'].'&amp;h='.$item_options['image-height'].'" alt="" class="about-image align-'.$item_options['image-align'].'" width="'.$item_options['image-width'].'px" height="'.$item_options['image-height'].'px" />';
	else:
		echo '<img src="'.urldecode($item_options['image']).'" alt="" class="about-image align-'.$item_options['image-align'].'" />';
	endif;
		
		
	endif;	
	?>
	<?php echo stripslashes(html_entity_decode($item_options['blurb']))?>
	
	<?php 
	if($item_options['show-read-more']):
		if($item_options['read-more-page']):
			$url = get_permalink($item_options['read-more-page']);
		else:
			$url = urldecode($item_options['read-more-href']);
		endif;
		
		echo '<a href="'.$url.'" class="about-read-more">'.html_entity_decode($item_options['read-more-language']).'</a>';
	endif;
	?>
	
	<?php do_action('headway_leaf_content_bottom') ?>
	<?php do_action('headway_leaf_content_bottom_'.$leaf) ?>
</div>