<?php
class SearchWidget extends WP_Widget {
    function SearchWidget() {
         $widget_ops = array('classname' => 'widget_headway_search', 'description' => __( 'Simple search form.  Use this Widget instead of the other search widget.') );
		 $this->WP_Widget('search', __('Headway Search'), $widget_ops);
    }

    function widget($args, $instance) {		
        extract( $args );
		$search_input_text = empty( $instance['title'] ) ? 'Type Here To Search, Then Press Enter' : $instance['title'];
        ?>
              <?php echo $before_widget ?>
				<form id="searchform" method="get" action="<?php bloginfo('home') ?>">
					<div>
						<input id="s" class="text-input" name="s" type="text" value="<?php echo (get_search_query() == NULL) ? $search_input_text : get_search_query(); ?>" onblur="if(this.value == '') {this.value = '<?php echo $search_input_text ?>';}" onclick="if(this.value == '<?php echo $search_input_text ?>') {this.value = '';}" accesskey="S" />
					</div>
				</form>
			<?php echo $after_widget ?>
        <?php
    }
    function update($new_instance, $old_instance) {				
        return $new_instance;
    }

    function form($instance) {		
	    $title = esc_attr($instance['title']); 
?>
			<p><label for="<?php echo $this->get_field_id('title'); ?>">Search Text: <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></label></p>
			
      
	
			


        <?php 
    }

}
add_action('widgets_init', create_function('', 'return register_widget("SearchWidget");'));
////////////////////
////////////////////
class SubscribeWidget extends WP_Widget {
    function SubscribeWidget() {
       	 $widget_ops = array('classname' => 'widget_headway_subscribe', 'description' => __( 'Displays a simple subscribe via RSS link.') );
		 $this->WP_Widget('subscribe', __('Subscribe'), $widget_ops);
    }

    function widget($args, $instance) {		
        extract( $args );
        ?>
              <?php echo $before_widget ?>
				<?php echo $before_title ?>Subscribe<?php echo $after_title ?>

				<ul class="subscribe">
					<li class="rss"><a href="<?php echo headway_rss() ?>">Subscribe via RSS</a></li>
				</ul>

			<?php echo $after_widget ?>
        <?php
    }

}
add_action('widgets_init', create_function('', 'return register_widget("SubscribeWidget");'));
///////////////////
///////////////////
class TwitterWidget extends WP_Widget {
    function TwitterWidget() {
        $widget_ops = array('classname' => 'widget_headway_twitter', 'description' => __( 'Displays any number of your Twitter updates') );
		$this->WP_Widget('twitter', __('Twitter'), $widget_ops);
    }

    function widget($args, $instance) {		
        extract( $args );
		$title = apply_filters('widget_title', empty( $instance['title'] ) ? 'Twitter' : $instance['title']);
        ?>
              <?php echo $before_widget; ?>
                  <?php echo $before_title
                      . $instance['title']
                      . $after_title; ?>

						<?php
						if($instance['format'] == '1') $instance['format'] = 'F j, Y - g:i A';
						if($instance['format'] == '2') $instance['format'] = 'm/d/y - g:i A';
						if($instance['format'] == '3') $instance['format'] = 'd/m/y - g:i A';
						if($instance['format'] == '4') $instance['format'] = 'g:i A - M j';
						if($instance['format'] == '5') $instance['format'] = 'g:i A - M j, Y';	
						?>

						<ul class="twitter-updates">
						<?php getTwitterUpdates($instance['username'], $instance['limit'], $instance['format']) ?>
						</ul>


              <?php echo $after_widget; ?>
        <?php
    }
    function update($new_instance, $old_instance) {				
        return $new_instance;
    }

    function form($instance) {				
        $title = esc_attr($instance['title']);
		$username = esc_attr($instance['username']);
		$limit = esc_attr($instance['limit']);
		        ?>
            <p><label for="<?php echo $this->get_field_id('title'); ?>">Title: <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></label></p>
	
			<p><label for="<?php echo $this->get_field_id('username'); ?>">Twitter Username: <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('username'); ?>" type="text" value="<?php echo $username; ?>" /></label></p>
			<p><label for="<?php echo $this->get_field_id('limit'); ?>">Tweet Limit: <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('limit'); ?>" type="text" value="<?php echo $limit; ?>" /></label></p>
			
			<p><label for="<?php echo $this->get_field_id('format'); ?>">Date/Time Format: 
			<select name="<?php echo $this->get_field_name('format'); ?>" id="<?php echo $this->get_field_id('format'); ?>">
				<option value="1"<?php selected( $instance['format'], '1' ); ?>>January 1, 2009 - 12:00 AM</option>
				<option value="2"<?php selected( $instance['format'], '2' ); ?>>MM/DD/YY - 12:00 AM</option>
				<option value="3"<?php selected( $instance['format'], '3' ); ?>>DD/MM/YY - 12:00 AM</option>
				<option value="4"<?php selected( $instance['format'], '4' ); ?>>12:00 AM - Jan 1</option>
				<option value="5"<?php selected( $instance['format'], '5' ); ?>>12:00 AM - Jan 1, 2009</option>
			</select>
			</label></p>
			


        <?php 
    }

}
add_action('widgets_init', create_function('', 'return register_widget("TwitterWidget");'));
///////////////////
///////////////////
class SocialWidget extends WP_Widget {
    function SocialWidget() {
        parent::WP_Widget(false, $name = 'Social Widget');	
    }

    function widget($args, $instance) {		
        extract( $args );
        ?>
              <?php echo $before_widget; ?>
                  <?php echo $before_title
                      . $instance['title']
                      . $after_title; ?>

						<?php if($instance['feed']): ?><a href="<?php echo $instance['feed'] ?>" title="Subscribe via RSS!"><img src="<?php bloginfo('template_directory') ?>/media/images/social/feed.jpg" alt="Subscribe via RSS!" /></a><?php endif; ?>

						<?php if($instance['twitter']): ?><a href="<?php echo $instance['twitter'] ?>" title="Follow Me On Twitter!"><img src="<?php bloginfo('template_directory') ?>/media/images/social/twitter.jpg" alt="Follow Me On Twitter!" /></a><?php endif; ?>

						<?php if($instance['facebook']): ?><a href="<?php echo $instance['facebook'] ?>" title="Be my friend on Facebook!"><img src="<?php bloginfo('template_directory') ?>/media/images/social/facebook.jpg" alt="Follow Me On Twitter!" /></a><?php endif; ?>

						<?php if($instance['linkedin']): ?><a href="<?php echo $instance['linkedin'] ?>" title="Find me on LinkedIn!"><img src="<?php bloginfo('template_directory') ?>/media/images/social/linkedin.jpg" alt="Follow Me On Twitter!" /></a><?php endif; ?>

						<?php if($instance['youtube']): ?><a href="<?php echo $instance['youtube'] ?>" title="Subscribe to my channel on YouTube!"><img src="<?php bloginfo('template_directory') ?>/media/images/social/youtube.jpg" alt="Follow Me On Twitter!" /></a><?php endif; ?>

						<?php if($instance['vimeo']): ?><a href="<?php echo $instance['vimeo'] ?>" title="Subscribe to my channel on Vimeo!"><img src="<?php bloginfo('template_directory') ?>/media/images/social/vimeo.jpg" alt="Follow Me On Twitter!" /></a><?php endif; ?>

						<?php if($instance['stumbleupon']): ?><a href="<?php echo $instance['stumbleupon'] ?>"><img src="<?php bloginfo('template_directory') ?>/media/images/social/stumbleupon.jpg" alt="" /></a><?php endif; ?>

						<?php if($instance['friendfeed']): ?><a href="<?php echo $instance['friendfeed'] ?>" title="Subscribe to my FriendFeed!"><img src="<?php bloginfo('template_directory') ?>/media/images/social/friendfeed.jpg" alt="Follow Me On Twitter!" /></a><?php endif; ?>


              <?php echo $after_widget; ?>
        <?php
    }
    function update($new_instance, $old_instance) {				
        return $new_instance;
    }

    function form($instance) {				
        $title = esc_attr($instance['title']);

		$feed = esc_attr($instance['feed']);
		$twitter = esc_attr($instance['twitter']);
		$facebook = esc_attr($instance['facebook']);
		$linkedin = esc_attr($instance['linkedin']);
		$youtube = esc_attr($instance['youtube']);
		$vimeo = esc_attr($instance['vimeo']);
		$stumbleupon = esc_attr($instance['stumbleupon']);
		$friendfeed = esc_attr($instance['friendfeed']);
		?>
            <p><label for="<?php echo $this->get_field_id('title'); ?>">Title: <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></label></p>
	
			<p><label for="<?php echo $this->get_field_id('feed'); ?>">Feed: <input class="widefat" id="<?php echo $this->get_field_id('feed'); ?>" name="<?php echo $this->get_field_name('feed'); ?>" type="text" value="<?php echo $feed; ?>" /></label></p>
			<p><label for="<?php echo $this->get_field_id('twitter'); ?>">Twitter: <input class="widefat" id="<?php echo $this->get_field_id('twitter'); ?>" name="<?php echo $this->get_field_name('twitter'); ?>" type="text" value="<?php echo $twitter; ?>" /></label></p>
			<p><label for="<?php echo $this->get_field_id('facebook'); ?>">Facebook: <input class="widefat" id="<?php echo $this->get_field_id('facebook'); ?>" name="<?php echo $this->get_field_name('facebook'); ?>" type="text" value="<?php echo $facebook; ?>" /></label></p>
			<p><label for="<?php echo $this->get_field_id('linkedin'); ?>">LinkedIn: <input class="widefat" id="<?php echo $this->get_field_id('linkedin'); ?>" name="<?php echo $this->get_field_name('linkedin'); ?>" type="text" value="<?php echo $linkedin; ?>" /></label></p>
			<p><label for="<?php echo $this->get_field_id('youtube'); ?>">YouTube: <input class="widefat" id="<?php echo $this->get_field_id('youtube'); ?>" name="<?php echo $this->get_field_name('youtube'); ?>" type="text" value="<?php echo $youtube; ?>" /></label></p>
			<p><label for="<?php echo $this->get_field_id('vimeo'); ?>">Vimeo: <input class="widefat" id="<?php echo $this->get_field_id('vimeo'); ?>" name="<?php echo $this->get_field_name('vimeo'); ?>" type="text" value="<?php echo $vimeo; ?>" /></label></p>
			<p><label for="<?php echo $this->get_field_id('stumbleupon'); ?>">StumbleUpon: <input class="widefat" id="<?php echo $this->get_field_id('stumbleupon'); ?>" name="<?php echo $this->get_field_name('stumbleupon'); ?>" type="text" value="<?php echo $stumbleupon; ?>" /></label></p>
			<p><label for="<?php echo $this->get_field_id('friendfeed'); ?>">FriendFeed: <input class="widefat" id="<?php echo $this->get_field_id('friendfeed'); ?>" name="<?php echo $this->get_field_name('friendfeed'); ?>" type="text" value="<?php echo $friendfeed; ?>" /></label></p>


        <?php 
    }

}
add_action('widgets_init', create_function('', 'return register_widget("SocialWidget");'));










function blog_widgets_init() {
	if ( !function_exists('register_sidebars') )
		return;


	
	
	
	
	
		$headway_sidebars = get_option('headway_sidebars');
		
	
		if($headway_sidebars){
			foreach($headway_sidebars as $id){
			
				$leaf_order = get_post_meta($id, '_leafs', true);						// Get Leaf Order



				if($leaf_order != NULL){												    // If the leaf order custom field is not empty.  If this is not here it'll throw some nasty errors.
					foreach($leaf_order as $leaf){										// Start foreach loop for every leaf/box.
						$leaf_config = get_post_meta($id, '_'.$leaf, true);
						$item_options = get_post_meta($id, '_'.$leaf.'_options', true);
						$item_options = db_to_leaf($item_options);
				
				
						if($leaf_config[0] == 'sidebar' && $item_options['duplicate'] != 'on'){
				
							$p = array(
								'name'			 =>   $leaf_config[1],
								'id' 			 =>   "sidebar-$leaf",
								'before_widget'  =>   '<li id="%1$s" class="widget %2$s">',
								'after_widget'   =>   '</li>'."\n",
								'before_title'   =>   '<span class="widget-title '.font('sidebar-widget-heading').'">',
								'after_title'    =>   "</span>\n",
							);

							register_sidebar( $p );
				
						}
				

					}
				}
	
			}
		}
	

	
	
	
		
		$headway_sidebars_system = get_option('headway_sidebars_system');
			
		if($headway_sidebars_system){
			foreach($headway_sidebars_system as $id){
			
				$leaf_order = get_option('system-page-'.$id.'-leafs');


				if($leaf_order != NULL){												    // If the leaf order custom field is not empty.  If this is not here it'll throw some nasty errors.
					foreach($leaf_order as $leaf){										// Start foreach loop for every leaf/box.
						$leaf_config = get_option('system-page-'.$id.'-'.$leaf);
						$item_options = get_option('system-page-'.$id.'-'.$leaf.'_options');
						$item_options = db_to_leaf($item_options);
				
				
						if($leaf_config[0] == 'sidebar' && $item_options['duplicate'] != 'on'){
				
							$p = array(
								'name'			 =>   $leaf_config[1],
								'id' 			 =>   "sidebar-$leaf",
								'before_widget'  =>   '<li id="%1$s" class="widget %2$s">',
								'after_widget'   =>   '</li>'."\n",
								'before_title'   =>   '<span class="widget-title '.font('sidebar-widget-heading').'">',
								'after_title'    =>   "</span>\n",
							);

							register_sidebar( $p );
				
						}
				

					}
				}
	
			}
		}
	
	
	
	
	
}

load_theme_textdomain('blog');

add_action( 'init', 'blog_widgets_init' );