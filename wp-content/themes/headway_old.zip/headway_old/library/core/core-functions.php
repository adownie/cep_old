<?
function get_id_by_name($page_name)
{
	global $wpdb;
	$id = $wpdb->get_var("SELECT ID FROM $wpdb->posts WHERE post_name = '".$page_name."'");
	return $id;
}


function flattenArray($array){
	$ret_array = array();
	foreach(new RecursiveIteratorIterator(new RecursiveArrayIterator($array)) as $value)
   	{
   		$ret_array[] = $value;
    }
	return $ret_array;
}
function recursive_array_search($needle,$haystack, $unserialize = false) {
    foreach($haystack as $key=>$value) {
		if($unserialize) $value = unserialize($value);
        $current_key=$key;
        if($needle===$value OR (is_array($value) && recursive_array_search($needle,$value))) {
            return $current_key;
        }
    }
    return false;
}


function variableArray($arr,$str) {
	preg_match_all('/\[([^]]*)]/',$str,$matches);

	$return = $arr;
	foreach ($matches[1] as $index)
	$return = $return[$index];

	return $return;
}

function parseVarsCallback($matches) {
	global $$matches[1];
	return variableArray($$matches[1],$matches[2]);
}

function parseVars($str, $open = '{!', $close = '!}') {
	return preg_replace_callback('/'.$open.'(\w+)((?:\[[^]]+])*)'.$close.'/','parseVarsCallback',$str);
}




function serialToArray($serial){
	$fields = explode("&",$serial);

	$keys = array();
	$values = array();

	foreach($fields as $field){
		$field_key_value = explode("=",$field);
		$key = urldecode($field_key_value[0]);
		array_push($keys, $field_key_value[0]);
		$value = urldecode($field_key_value[1]);
		array_push($values, $field_key_value[1]);
	}

	$array = array_combine($keys, $values);
	
	return $array;
}
function jsonArrayFix($arrays){
	if($arrays):
		$fixArray = array();
		foreach($arrays as $array){
			if(!array_key_exists($array['name'], $fixArray)):     //Adds Support For Multi-selects, etc.
				$fixArray[$array['name']] = $array['value'];
			else:
				$fixArray[$array['name']] .= ' | '.$array['value'];
			endif;
			
		}
		return $fixArray;
	endif;
}








function array_interlace() {
    $args = func_get_args();
    $total = count($args);

    if($total < 2) {
        return FALSE;
    }
   
    $i = 0;
    $j = 0;
    $arr = array();
   
    foreach($args as $arg) {
        foreach($arg as $v) {
            $arr[$j] = $v;
            $j += $total;
        }
       
        $i++;
        $j = $i;
    }
   
    ksort($arr);
    return array_values($arr);
}






function headway_rss(){
	if(get_option('feed-url')) return get_option('feed-url');
	return get_bloginfo('rss2_url');
}


function headway_gzip(){
	if(get_option('gzip') == 1) if ( extension_loaded('zlib') ) ob_start('ob_gzhandler');
}



function is_ie($version = false){
	if(strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') && !$version) return true;
	if(strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE 6.0') && $version == 6) return true;
	if(strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE 7.0') && $version == 7) return true;
	
	return false;
}


function parse_php($content){
	ob_start();
	eval("?>$content<?php ");
	$parsed = ob_get_contents();
	ob_end_clean();
	return $parsed;
}

function headway_directory($print = true, $absolute = false){
	if($print):
		echo ($absolute) ? HEADWAYROOT : get_bloginfo('template_directory');
	else:
		return ($absolute) ? HEADWAYROOT : get_bloginfo('template_directory');
	endif;
}




function headway_login(){
	if(get_option('show-admin-link')){
		if ( is_user_logged_in() ) {
		    echo '<a href="'.get_bloginfo('url').'/wp-admin" class="footer-right">Administration Panel</a>';
		} else {
		    echo '<a href="'.get_bloginfo('url').'/wp-admin" class="footer-right">Administrator Login</a>';
		}
	}
}
function headway_edit(){
	if(is_page() && !is_front_page()) edit_post_link('Edit This Page', '<span class="edit-link footer-right">', '</span>');
	if(is_front_page()) echo '<a href="'.get_edit_post_link(get_option('page_on_front')).'" class="footer-right">Edit This Page</a>';
	if(is_single()) edit_post_link('Edit This Post', '<span class="edit-link footer-right">', '</span>');
}

function headway_link($text = 'Headway'){
	if(strstr(html_entity_decode(get_option('affiliate_link')), 'http://www.headwaythemes.com/affiliates/idevaffiliate.php')){
		$location = get_option('affiliate_link');
	}
	else
	{
		$location = 'http://www.wicked-wordpress-themes.com';	
	}
	$return = apply_filters('headway_link', '<p class="footer-left">Powered By <a href="'.$location.'" title="Headway Premium WordPress Theme">Premium Wordpress Themes</a></p>');
	
	echo $return;
}



function headway_copyright(){
	$return = apply_filters('headway_copyright', '<p class="copyright">Copyright &copy; '.the_date('Y', false, false, false).' '.get_bloginfo('name').'</p>');
	
	echo $return;
}


function headway_go_to_top(){
	$return = apply_filters('headway_go_to_top', '<a href="#top" class="footer-right">Go To Top</a>');
	
	echo $return;
}