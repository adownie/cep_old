<?php
/*
Written by Clay Griffiths.  You can ninja this code and use it in your own themes if you wish.  Please leave this license and header.
MIT License: http://www.opensource.org/licenses/mit-license.php
*/
class MetaBox
{
		
	var $id;
	var $name;
	var $options;
	var $defaults;
	var $info = NULL;
	var $type = 'both';


	function MetaBox($id, $name, $options, $defaults, $info, $type){
		
		$this->id = $id;
		$this->name = $name;
	    $this->options = $options;
		$this->defaults = $defaults;
		if(isset($info)) $this->info = $info;
		if(isset($type)) $this->type = $type;
		
		
		add_action('admin_menu', array(&$this, 'BuildBox'));
		add_action('save_post', array(&$this, 'SaveData'), 10, 2);	
		add_action('publish_post', array(&$this, 'SaveData'), 10, 2);	
		
	}
	
	
	
	function BuildBox(){		
		if($this->type == 'post') add_meta_box( $this->id, $this->name, array($this, 'BoxContent'), 'post', 'advanced', 'low' );
		if($this->type == 'page') add_meta_box( $this->id, $this->name, array($this, 'BoxContent'), 'page', 'advanced', 'low' );
		
		if($this->type == 'both'):
			add_meta_box( $this->id, $this->name, array($this, 'BoxContent'), 'post', 'advanced', 'low' );
			add_meta_box( $this->id, $this->name, array($this, 'BoxContent'), 'page', 'advanced', 'low' );
		endif;	
	}
	
	
	
	
	function BoxContent(){
		
		
		global $post;
		
		
		
		echo '<input type="hidden" name="'.$this->id.'_nonce" id="'.$this->id.'_nonce" value="' . wp_create_nonce( base64_encode(md5($this->id)) ) . '" />';


		foreach($this->options as $option):
		
			if(get_post_meta($post->ID, '_'.$option['id'], true) || get_post_meta($post->ID, '_'.$option['id'], true) == '0'):
				$value = get_post_meta($post->ID, '_'.$option['id'], true);
			else:
				$value = $this->defaults[$option['id']];
			endif;
		
			
			
			
			if($value == '1') $data[$option['id']] = ' checked="checked" ';
			elseif($value != '1') $data[$option['id']] = $value;
		endforeach;


		if($this->info) echo '<p>'.$this->info.'</p>';
		
		
		foreach($this->options as $key => $value):
		
			$input_options['id'] = $value['id'];
			$input_options['name'] = $value['name'];
			$input_options['type'] = $value['type'];
			$input_options['defaults'] = $value['defaults'];
			$input_options['options'] = $value['options'];
			
			$id = $input_options['id'];
			
			
			$options .= '<tr class="form-field">';
			
				
			
				if($input_options['type'] == 'text'):

					$options .= '<th valign="top" scope="row"><label for="'.$this->id.'_'.$input_options['id'].'">'.$input_options['name'].'</label></th>
								 <td><input type="text" style="width: 95%;" value="'.$data[$id].'" size="50" id="'.$this->id.'_'.$input_options['id'].'" name="'.$this->id.'['.$input_options['id'].']"/></td>';

				elseif($input_options['type'] == 'textarea'):
				
					$options .= '<th valign="top" scope="row"><label for="'.$this->id.'_'.$input_options['id'].'">'.$input_options['name'].'</label></th>
								<td><textarea style="width: 95%;" rows="6" cols="50" id="'.$this->id.'_'.$input_options['id'].'" name="'.$this->id.'['.$input_options['id'].']">'.$data[$id].'</textarea></td>';
				
				elseif($input_options['type'] == 'checkbox'):
					$value = ($normal_data[$id] == 1) ? 1 : 0;
					
					$options .= '<input type="hidden" name="'.$this->id.'['.$input_options['id'].'_unchecked]" value="0" /> ';
					$options .= '<td colspan="2"><label class="selectit" for="'.$this->id.'_'.$input_options['id'].'"> <input type="checkbox" id="'.$this->id.'_'.$input_options['id'].'" value="1" name="'.$this->id.'['.$input_options['id'].']" class="check" '.$data[$id].'/> '.$input_options['name'].'</label></td>';
					
				elseif($input_options['type'] == 'page-select'):
					
					$options .= '<th valign="top" scope="row"><label for="'.$this->id.'_'.$input_options['id'].'">'.$input_options['name'].'</label></th>
								 <td>'.wp_dropdown_pages(array('selected' => $data[$id], 'name' => $this->id.'['.$input_options['id'].']', 'show_option_none' => '   ', 'sort_column'=> 'menu_order, post_title', 'echo' => false)).'</td>';
				
				 
				
				endif;
			
			
			
			$options .= '</tr>';
			

		endforeach;
		

		  echo '<table cellspacing="2" cellpadding="5" style="width: 100%;" class="form-table">
			<tbody>
			'.$options.'
		  </tbody></table>';
		
		
	}
	
	
	
	function SaveData( $post_ID, $post ){
		if ($post->post_type == 'revision') return;
			
			
		$post_ID = $post->ID;
		
		
		$encrypt = base64_encode(md5($this->id));
		if ( !wp_verify_nonce( $_POST[$this->id.'_nonce'], $encrypt )) {
		  return;
		}
		
		
		

		if ( 'page' == $_POST['post_type'] ) {
		  if ( !current_user_can( 'edit_page', $post_ID ))
		    return $post_ID;
		} else {
		  if ( !current_user_can( 'edit_post', $post_ID ))
		    return $post_ID;
		}

		
		foreach($_POST[$this->id] as $key => $value):		
		
			if($value == '' || $value == '0'){
				
				
				if(strpos($key, '_unchecked')){
					$key = str_replace('_unchecked', '', $key);
					if(!$_POST[$this->id][$key]) update_post_meta($post_ID, '_'.$key, '0');
				    
				}else{
					delete_post_meta($post_ID, '_'.$key);
				}
				
				
				
				
				
				


			}elseif($value != get_post_meta($post_ID, '_'.$key, true)){
				update_post_meta($post_ID, '_'.$key, $value);  

			}
			elseif(!get_post_meta($post_ID, '_'.$key, true) && $value != NULL){
				add_post_meta($post_ID, '_'.$key, $value);

			}
		endforeach;
	
		
		
	}
   

}