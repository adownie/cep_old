<?php
function get_skins(){
	$path = HEADWAYSKINS;
	$dir_handle = @opendir($path) or die("Unable to open $path");

	while ($file = readdir($dir_handle)) {
		$file = rawurlencode($file);
		$skin_dir[] = $file;
	}
	$remove_these = array('index.php', '.', '..', '.svn');
	$skins = array_diff($skin_dir, $remove_these);

	closedir($dir_handle);
	return $skins;
}
function set_style($style, $disable_colors = true, $disable_skin_selector = true){
	update_option('site-style', $style);
	if($disable_skin_selector):
		update_option('headway_skin_disabled', array('site-style' => ' disabled'));
	else:
		update_option('headway_skin_disabled', array_diff(get_option('headway_skin_disabled'), array('site-style' => ' disabled')));
	endif;
	
	if($disable_colors):
		update_option('headway_colors_disabled', array('colors' => ' disabled'));
		update_option('disable-color-stylesheet', 1);
	else:
		update_option('headway_colors_disabled', array_diff(get_option('headway_colors_disabled'), array('colors' => ' disabled')));
		update_option('disable-color-stylesheet', 0);
	endif;
}
