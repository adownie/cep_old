<?php
function get_write_box_value($name, $echo = false, $id = false){
	if(!$id):
	 global $post;
	 $id = $post->ID;
	endif;
	
	if($echo):
		echo get_post_meta($id, '_'.$name, true);
	else:
		return get_post_meta($id, '_'.$name, true);
	endif;
	
}

function font($id){
	return get_option('fonts-'.$id);
}
function font_size($id){
	return get_option('fonts-'.$id.'-size');
}

function color($id){
	return get_option('color-'.$id);
}