<?php
function leaf_to_db($options) {

	$text = base64_decode($options);
	
	$text = str_replace('\r', '\n', $text);
    $text = str_replace('\r\n', '\n', $text);
    $text = str_replace('\n', "<newlineescape>", $text);
	
	
    return $text;
}

function db_to_leaf($options, $br = false){
	if($options):
		$options = jsonArrayFix(json_decode($options, true));
		$options = str_replace('<newlineescape>', "\n", $options);
		if($br){
			$options = str_replace("\n", "<br />", $options);
		}
		if($options):
			foreach($options as $key => $value){
				$options[$key] = stripslashes($value);
			}
		endif;
		return $options;
	endif;
}





function parseFile($file){
      ob_start();
      include($file);
      $content=ob_get_contents();
      ob_end_clean();
      return $content;
}


function registerLeaf($leaf_type, $options, $defaults = NULL){
	global $input;
	global $id;
	global $id_formatted;
	global $leaf_config;
	global $javascript_replace;
	global $select;
	global $selected;
	global $checked;
	global $text;
	global $display;
	
	
	if($select) extract($select, EXTR_PREFIX_ALL, 'select');

	
	extract($options);

	
	$input = $item_options;
	
	
	
	
	if($defaults):
		extract($defaults, EXTR_PREFIX_ALL, 'defaults');
	
		
		if($defaults_checked):
			foreach($defaults_checked as $default_checked):
				$checked[$default_checked] = ' checked';
			endforeach;
		endif;
		
		
		if($defaults_selected):
			foreach($defaults_selected as $default_selected):
				$selected[$default_selected] = ' selected';
			endforeach;
		endif;	
		
		
		if($defaults_input):
			foreach($defaults_input as $default_input => $value):
				$input[$default_input] = $value;
			endforeach;
		endif;

	endif;
	
	
	$id_formatted = str_replace('item_', '', $id);



	$inner = parseFile(TEMPLATEPATH.'/library/leafs/'.$leaf_type.'/inner.php');


	if($javascript_replace):
		foreach($javascript_replace as $replace)
			$inner = str_replace('{!'.$replace.'!}', '{{'.$replace.'}}', $inner);
	endif;
	
	$inner = str_replace('{script}', '<script type="text/javascript">', $inner);
	$inner = str_replace('{/script}', '</script>', $inner);


	
	$leaf_inner = stripslashes(parseVars($inner));
		
	
	$register = array($leaf_inner, $leaf_content);
	
	return $register;
}








function get_page_leafs(){
	$post->ID = get_the_id();
	$page_id = get_write_box_value('leaf_template', false, $post->ID) ? get_write_box_value('leaf_template', false, $post->ID)  : $post->ID;
	
	
	$leaf_order = get_post_meta($page_id, '_leafs', true);						// Get Leaf Order
	
	if($leaf_order != NULL){												    // If the leaf order custom field is not empty.  If this is not here it'll throw some nasty errors.
		foreach($leaf_order as $leaf){ 											// Start foreach loop for every leaf/box.
			$leaf_config = get_post_meta($page_id, '_'.$leaf, true);
			$item_options = get_post_meta($page_id, '_'.$leaf.'_options', true);
			
			$item_custom = db_to_leaf($item_options);
			$item_custom_class[$leaf] = $item_custom['custom-css-class'];
			

				$box_classes[$leaf] = array(); //Make empty array.
				array_push($box_classes[$leaf], $leaf_config[0]);

				if($item_custom_class[$leaf]){
					$custom_classes[$leaf] = explode(' ', $item_custom_class[$leaf]);  //Get custom classes from DB and put into array.
					array_push($box_classes[$leaf], $custom_classes[$leaf]);
				}

				if(!$item_custom['show-title']){
					$title_class[$leaf] = 'box-no-title';
					array_push($box_classes[$leaf], $title_class[$leaf]);
				}

				if($leaf_config[4] == 1){
					$alignment_class[$leaf] = 'box-right';
					array_push($box_classes[$leaf], $alignment_class[$leaf]);
				}
					
				if($leaf_config[5] == 1){
					$fluid_class[$leaf] = 'fluid-height';
					array_push($box_classes[$leaf], $fluid_class[$leaf]);
				}
					
				$item_options = db_to_leaf($item_options);
				
				if($item_options['horizontal-sidebar']) {
					$horizontal_sidebar_class[$leaf] = 'horizontal-sidebar';
					array_push($box_classes[$leaf], $horizontal_sidebar_class[$leaf]);
				}
				
				$box_classes[$leaf] = flattenArray($box_classes[$leaf]);  //Flatten array and prep for implode.
				$box_classes[$leaf] = implode(' ', $box_classes[$leaf]); //Implodes array separating each class with a space so when echoed it doesn't print "Array"
			
									
			echo '<div class="'.$box_classes[$leaf].' box" id="'.$leaf.'">';
			
?>		
	<?php
					
					
					if(file_exists(TEMPLATEPATH.'/library/leafs/'.$leaf_config[0].'/content.php')):
						include TEMPLATEPATH.'/library/leafs/'.$leaf_config[0].'/content.php';
					endif;
					rewind_posts();
					
			echo '</div>';
		}
	}
}




function get_system_page_leafs($system_page_id){
		$leaf_order = get_option('system-page-'.$system_page_id.'-leafs');						// Get Leaf Order

		if($leaf_order != NULL){												    // If the leaf order custom field is not empty.  If this is not here it'll throw some nasty errors.
			foreach($leaf_order as $leaf){ 											// Start foreach loop for every leaf/box.
				$leaf_config = get_option('system-page-'.$system_page_id.'-'.$leaf);
				$item_options = get_option('system-page-'.$system_page_id.'-'.$leaf.'_options');

				$item_custom = db_to_leaf($item_options);
				$item_custom_class[$leaf] = $item_custom['custom-css-class'];


					$box_classes[$leaf] = array(); //Make empty array.
					
					array_push($box_classes[$leaf], $leaf_config[0]);

					if($item_custom_class[$leaf]){
						$custom_classes[$leaf] = explode(' ', $item_custom_class[$leaf]);  //Get custom classes from DB and put into array.
						array_push($box_classes[$leaf], $custom_classes[$leaf]);
					}

					if(!$item_custom['show-title']){
						$title_class[$leaf] = 'box-no-title';
						array_push($box_classes[$leaf], $title_class[$leaf]);
					}

					if($leaf_config[4] == 1){
						$alignment_class[$leaf] = 'box-right';
						array_push($box_classes[$leaf], $alignment_class[$leaf]);
					}
						
					if($leaf_config[5] == 1){
						$fluid_class[$leaf] = 'fluid-height';
						array_push($box_classes[$leaf], $fluid_class[$leaf]);
					}
						
					$item_options = db_to_leaf($item_options);
					
					if($item_options['horizontal-sidebar']) {
						$horizontal_sidebar_class[$leaf] = 'horizontal-sidebar';
						array_push($box_classes[$leaf], $horizontal_sidebar_class[$leaf]);
					}

					
					$box_classes[$leaf] = flattenArray($box_classes[$leaf]);  //Flatten array and prep for implode.
					$box_classes[$leaf] = implode(' ', $box_classes[$leaf]); //Implodes array separating each class with a space so when echoed it doesn't print "Array"
					

				echo '<div class="'.$box_classes[$leaf].' box" id="'.$leaf.'">';

	?>		
		<?php
		
						if(file_exists(TEMPLATEPATH.'/library/leafs/'.$leaf_config[0].'/content.php')):
							include TEMPLATEPATH.'/library/leafs/'.$leaf_config[0].'/content.php';
						endif;
						rewind_posts();

				echo '</div>';
			}
		}
}


















function get_leaf($leaf_id, $page_id, $page_type = 'normal'){
		
	if($page_type == 'normal'):	
		$leaf_config = get_post_meta($page_id, '_'.$leaf_id, true);
		$item_options = get_post_meta($page_id, '_'.$leaf_id.'_options', true);
	else:
		$leaf_config = get_option('system-page-'.$page_id.'-'.$leaf_id);
		$item_options = get_option('system-page-'.$page_id.'-'.$leaf_id.'_options');
	endif;


	$item_custom = db_to_leaf($item_options);
	$item_custom_class = $item_custom['custom-css-class'];


		$box_classes[$leaf] = array(); //Make empty array.

		if($item_custom_class[$leaf])
			$custom_classes[$leaf] = explode(' ', $item_custom_class[$leaf]);  //Get custom classes from DB and put into array.

		if(!$item_custom['show-title'])
			$title_class[$leaf] = 'box-no-title';

		if($leaf_config[4] == 1) 
			$alignment_class[$leaf] = 'box-right';
			
		if($leaf_config[5] == 1) 
			$fluid_class[$leaf] = 'fluid-height';
			
		$item_options = db_to_leaf($item_options);
		
		if($item_options['horizontal-sidebar']) 
			$horizontal_sidebar_class[$leaf] = 'horizontal-sidebar';


		array_push($box_classes[$leaf], $leaf_config[0], $custom_classes[$leaf], $title_class[$leaf], $alignment_class[$leaf], $fluid_class[$leaf], $horizontal_sidebar_class[$leaf]);  //Push the leaf class, custom classes, and no-title class if necessary to the empty array.
	
	
		$box_classes[$leaf] = flattenArray($box_classes);  //Flatten array and prep for implode.
		$box_classes[$leaf] = implode(' ', $box_classes[$leaf]); //Implodes array separating each class with a space so when echoed it doesn't print "Array"


	echo '<div class="'.$box_classes[$leaf].' box" id="'.$leaf.'">';

			$item_options = db_to_leaf($item_options);

			if(file_exists(TEMPLATEPATH.'/library/leafs/'.$leaf_config[0].'/content.php')):
				include TEMPLATEPATH.'/library/leafs/'.$leaf_config[0].'/content.php';
			endif;
			rewind_posts();

		
	echo '</div>';

}









function leaf_rotator_print_image($image_url, $hyperlink = false){
	if($hyperlink) echo '<a href="'.$hyperlink.'">';
	if($image_url) echo '<img src="'.urldecode($image_url).'" alt="" />';
	if($hyperlink) echo '</a>';
}