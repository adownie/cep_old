<?php
function buildCheckbox($id, $reverse = false, $disabled = false){
?>
	<?php if(get_option($id) == 1) $checked[$id] = ' checked="checked"'; ?>
	<? if($reverse): ?>
		<input type="checkbox" value="1" id="<?php echo $id?>" name="<?php echo $id?>"<?php echo $checked[$id]?><?php echo $disabled?> />
		<input type="hidden" value="0" id="<?php echo $id?>-hidden" name="<?php echo $id?>_unchecked"<?php echo $disabled?> />
	<? else: ?>
		<input type="hidden" value="0" id="<?php echo $id?>-hidden" name="<?php echo $id?>_unchecked"<?php echo $disabled?> />
		<input type="checkbox" value="1" id="<?php echo $id?>" name="<?php echo $id?>"<?php echo $checked[$id]?><?php echo $disabled?> />
	<? endif; ?>
<?php
}