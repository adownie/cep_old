<?
function headway_title( $sep = '&raquo;', $print = true ){
	

	$tagline = get_option('blogdescription');
	$blogname = get_option('blogname');
	$page = get_the_title();
	$category_description = category_description();
	$category = single_cat_title('', false);
	$tag = single_tag_title('', false);
	
	if ( is_day() ) :
		$archive = get_the_time(get_option('date_format'));
 	elseif ( is_month() ) :
		$archive = get_the_time('F Y');
	elseif ( is_year() ) : 
		$archive = get_the_time('Y');
    endif; 

	$postname = get_the_title();
	$search = get_search_query();
	
	
	if(get_query_var('author_name')) :
		$authordata = get_userdatabylogin(get_query_var('author_name'));
	else :
		$authordata = get_userdata(get_query_var('author'));
	endif;
	$author_name = $authordata->display_name;
	$author_description = $authordata->user_description;
	
	
	
	
	if(is_home() && get_option('page_for_posts') != get_option('page_on_front')):
		$title = get_option('title-posts-page');
		
	elseif(is_front_page() && get_option('page_for_posts') != get_option('page_on_front')):
		$title = get_option('title-home');
		
	elseif(is_home() || is_front_page()):
		$title = get_option('title-home');
		
	elseif(is_single()):
		if(get_write_box_value('title')){
			$title = stripslashes(get_write_box_value('title'));
		}
		else
		{	
			$title = get_option('title-single');
			$title = str_replace('%postname%', $postname, $title);
		}
		
		
	elseif(is_page()):
		if(get_write_box_value('title')){
			$title = stripslashes(get_write_box_value('title'));
		}
		else
		{	
			$title = get_option('title-page');
			$title = str_replace('%page%', $page, $title);
		}
		
		
	elseif(is_category()):
		$title = get_option('title-category');
		$title = str_replace('%category_description%', $category_description, $title);
		$title = str_replace('%category%', $category, $title);
		
	elseif(is_404()):
		$title = get_option('title-404');
		
	elseif(is_date()):
		$title = get_option('title-archives');
		$title = str_replace('%archive%', $archive, $title);
		
	elseif(is_tag()):
		$title = get_option('title-tag');
		$title = str_replace('%tag%', $tag, $title);
		
	elseif(is_search()):
		$title = get_option('title-search');
		$title = str_replace('%search%', $search, $title);
		
	elseif(is_author()):
		$title = get_option('title-author-archives');
		$title = str_replace('%author_name%', $author_name, $title);
		$title = str_replace('%author_description%', $author_description, $title);
	endif;
	
	
	
	$title = str_replace('%tagline%', $tagline, $title);
	$title = str_replace('%blogname%', $blogname, $title);
	
	
	
	
	
	
	
	
	

	if(!$print):
		return $title;
	else: 
		echo $title;
	endif;

}


function headway_meta($print = true){
	global $post;
	
	if(is_home() && get_option('home-keywords') || is_front_page() && get_option('home-keywords')):
		$meta = "\n".'<meta name="keywords" content="'.get_option('home-keywords').'" />';
	else:
		if(get_write_box_value('keywords')):
			$keywords = explode(',', get_write_box_value('keywords'));
		else:
			$keywords = array();
		endif;
		
		if(get_post_meta($post->ID, 'thesis_keywords', true)){
			global $post;
			array_push($keywords, explode(',', get_post_meta($post->ID, 'thesis_keywords', true)));
		}
		
		
		if(get_option('categories-meta') == 1):
			$categories = (!is_page()) ? get_the_category($post->ID) : NULL;
			
			if($categories){
				foreach($categories as $category) { 
				    array_push($keywords, $category->cat_name);
				} 
			}
			
		endif;
		
		if(get_option('tags-meta') == 1):
			if(get_the_tags($post->ID)):
				$tags = get_the_tags($post->ID);
			
				foreach($tags as $tag) { 
				    array_push($keywords, $tag->name);
				} 
			endif;
		endif;
		
		$keywords = implode(', ', $keywords);
		$meta = (!is_home() && !is_front_page() && $keywords) ? "\n".'<meta name="keywords" content="'.$keywords.'" />' : NULL;
	endif;
	
	
	if(is_home() && get_option('home-description') || is_front_page() && get_option('home-description')):
		$meta .= "\n".'<meta name="description" content="'.stripslashes(get_option('home-description')).'" />';
	elseif(get_write_box_value('description') != ''):
		$meta .= "\n".'<meta name="description" content="'.stripslashes(get_write_box_value('description')).'" />';
	elseif(get_post_meta($post->ID, 'thesis_description', true)):
		$meta .= "\n".'<meta name="description" content="'.stripslashes(get_post_meta($post->ID, 'thesis_description', true)).'" />';
	endif;
	
	
	if(get_option('canonical') == 1 && is_page() || is_single()):
		$meta .= "\n".'<meta name="canonical" content="'.get_permalink().'" />';
	endif;
	
	
	
	if(is_category() && get_option('noindex-category-archives')) $meta .= "\n".'<meta name="robots" content="noindex" />';
	if(is_date() && get_option('noindex-archives')) $meta .= "\n".'<meta name="robots" content="noindex" />';
	if(is_tag() && get_option('noindex-tag-archives')) $meta .= "\n".'<meta name="robots" content="noindex" />';
	if(is_author() && get_option('noindex-author-archives')) $meta .= "\n".'<meta name="robots" content="noindex" />';
	if(get_write_box_value('noindex') && is_single()) $meta .= "\n".'<meta name="robots" content="noindex" />';
	
	
	
	
	
	if($print){
		echo "\n".$meta;
	}
	else {
		return "\n".$meta;
	}
}


function insert_scripts(){
	is_home()    		? $systemPageID = 'index'		 : NULL;
	if(get_option('show_on_front') == 'posts') 
	is_front_page()   	? $systemPageID = 'index'		 : NULL;
	is_single()    		? $systemPageID = 'single'		 : NULL;
	is_date()   		? $systemPageID = 'archives' 	 : NULL;
	is_tag()   			? $systemPageID = 'tag' 		 : NULL;
	is_category()  		? $systemPageID = 'category'     : NULL;
	is_author()    		? $systemPageID = 'author' 		 : NULL;
	is_search()    		? $systemPageID = 'search' 	 	 : NULL;
	is_404()    		? $systemPageID = 'four04' 		 : NULL;
	
	global $post;
	$pageID = get_write_box_value('leaf_template', false, $post->ID) ? get_write_box_value('leaf_template', false, $post->ID) : $post->ID;
	$pageID = ($pageID && !$systemPageID) ? $pageID : $systemPageID;
	
	
	$leaf_order = get_post_meta($pageID, '_leafs', true);
	if(!$leaf_order) $leaf_order = get_option('system-page-'.$pageID.'-leafs');

	if($leaf_order != NULL){												    // If the leaf order custom field is not empty.  If this is not here it'll throw some nasty errors.
	
		if(!get_post_meta($pageID, '_leaf_count', true) && !$systemPageID){
			update_post_meta($pageID, '_leafs', array('item_1'));
			update_post_meta($pageID, '_leaf_count', 1);
			update_post_meta($pageID, '_item_1', array('content', 'Content', get_option('wrapper-width')-30, 115, 0, 1));
			update_post_meta($pageID, '_item_1_options', '[{"name": "mode", "value": "page"}, {"name": "other-page", "value": ""}, {"name": "categories-mode", "value": "include"}, {"name": "post_limit", "value": "'.get_option('posts_per_page').'"}, {"name": "featured_posts", "value": "1"}, {"name": "paginate", "value": "on"}, {"name": "custom-css-class", "value": ""}]');


			$leaf_order = array('item_1');
		}
	
	
		foreach($leaf_order as $leaf){										// Start foreach loop for every leaf/box.
			$leaf_config = get_post_meta($pageID, '_'.$leaf, true);

			if(!$leaf_config) $leaf_config = get_option('system-page-'.$pageID.'-'.$leaf);
			
			
			if($leaf_config[0] == 'featured') $featured_check = true;
			if($leaf_config[0] == 'rotator') $rotator_check = true;
			if($leaf_config[0] == 'content-slider') $content_slider_check = true;
		}
	}


	if($rotator_check || $featured_check):
	
		wp_enqueue_script('headway_jquery', '/wp-content/themes/'.HEADWAYFOLDER.'/media/js/jquery.js');
		wp_enqueue_script('headway_jquery_cycle', '/wp-content/themes/'.HEADWAYFOLDER.'/media/js/jquery.cycle.js');
		wp_enqueue_script('headway_custom', '/wp-content/themes/'.HEADWAYFOLDER.'/media/js/headway.php?id='.$pageID);

	endif;
	
	if($content_slider_check):
	
		wp_enqueue_script('headway_jquery', '/wp-content/themes/'.HEADWAYFOLDER.'/media/js/jquery.js');
		wp_enqueue_script('headway_jquery_flow', '/wp-content/themes/'.HEADWAYFOLDER.'/media/js/jquery.flow.js');
		wp_enqueue_script('headway_custom', '/wp-content/themes/'.HEADWAYFOLDER.'/media/js/headway.php?id='.$pageID);
	
	endif;
	
	
	if(is_ie(6)):
	
		wp_enqueue_script('headway_suckerfish', '/wp-content/themes/'.HEADWAYFOLDER.'/media/js/suckerfish.js');
	
	endif;

	
	if ( is_singular() ) wp_enqueue_script( 'comment-reply' );
	
	
	
}
add_action('wp_print_scripts', 'insert_scripts');









function headway_stylesheets(){
	is_home()    		? $systemPageID = 'index'	  : NULL;
	if(get_option('show_on_front') == 'posts')      
	is_front_page()   	? $systemPageID = 'index'	  : NULL;
	is_single()    		? $systemPageID = 'single'	  : NULL;
	is_date()   		? $systemPageID = 'archives'  : NULL;
	is_tag()   			? $systemPageID = 'tag' 	  : NULL;
	is_category()  		? $systemPageID = 'category'  : NULL;
	is_author()    		? $systemPageID = 'author' 	  : NULL;
	is_search()    		? $systemPageID = 'search' 	  : NULL;
	is_404()    		? $systemPageID = 'four04'       : NULL;
	                                                 
	global $post;
	$pageID = get_write_box_value('leaf_template', false, $post->ID) ? get_write_box_value('leaf_template', false, $post->ID) : $post->ID;
	$pageID = ($pageID && !$systemPageID) ? $pageID : $systemPageID;
	
	if(get_option('site-style') != 'no-css'):
		echo '<link rel="stylesheet" type="text/css" href="'.get_bloginfo('stylesheet_url').'" media="screen, projection" />'."\n";
		echo '<link rel="stylesheet" type="text/css" href="'.get_bloginfo('template_directory').'/media/css/box-classes.php?id='.$pageID.'" media="screen, projection" />'."\n";
		
		if(get_option('site-style') == 'headway'){
			echo '<link rel="stylesheet" type="text/css" href="'.get_bloginfo('template_directory').'/media/css/default.php" media="screen, projection" />'."\n";
			echo (get_option('disable-color-stylesheet') != 1) ? '<link rel="stylesheet" type="text/css" href="'.get_bloginfo('template_directory').'/media/css/colors.php" media="screen, projection" />'."\n" : NULL;
		}
		
		echo (is_ie()) ? '<link rel="stylesheet" type="text/css" href="'.get_bloginfo('template_directory').'/media/css/ie.css" media="screen, projection" />'."\n" : NULL;
	endif;



	if(get_option('skin')):
		echo '<link rel="stylesheet" type="text/css" href="'.get_bloginfo('template_directory').'/skins/'.get_option('skin').'/style.css" media="screen, projection" />'."\n";
	endif;
	
	if(get_option('custom-stylesheet') == 1) echo '<link rel="stylesheet" type="text/css" href="'.get_bloginfo('template_directory').'/custom.css" media="screen, projection" />'."\n";
	if(get_option('additional-stylesheet')) echo '<link rel="stylesheet" type="text/css" href="'.get_option('additional-stylesheet').'" media="screen, projection" />'."\n";

	echo '<link rel="stylesheet" type="text/css" href="'.get_bloginfo('template_directory').'/media/css/print.css" media="print" />'."\n";
	
	
}


function headway_favicon(){
	echo '<link rel="shortcut icon" type="image/ico" href="'.get_option('favicon').'" />';
}
add_action('wp_head', 'headway_favicon');





function forward(){
	if(get_write_box_value('navigation_url')) header('Location: '.get_write_box_value('navigation_url'));
}
add_action('wp', 'forward');