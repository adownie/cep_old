<?php
function comment_author_rel($url) {
	if(get_option('nofollow-comment-author')) return $url;
	
	$url = str_replace("rel='external nofollow'","rel='external'", $url);
	return $url;
}

add_filter('get_comment_author_link', 'comment_author_rel');




function list_pings($comment, $args, $depth) {
       $GLOBALS['comment'] = $comment;
	   if(get_comment_ID()-1 & 1){
		 $class_ping = ' class="alt"';
	   }
	   
?>
        <li id="comment-<?php comment_ID(); ?>"<?php echo $class_ping?>><?php comment_author_link(); ?>
<?php 
} 
function list_comments($comment, $args, $depth) {
       $GLOBALS['comment'] = $comment;
?>
        <li <?php comment_class() ?> id="comment-<?php comment_ID() ?>">
				<div id="div-comment-<?php comment_ID() ?>">
					<div class="comment-meta">
						<span class="comment-author"><?php echo get_comment_author_link()?></span>
						<div class="comment-date"><?php printf('%1$s | %2$s', get_comment_date('F j, Y'),  get_comment_time()) ?><?php edit_comment_link('Edit', '&nbsp;&nbsp;<span class="comment-edit">', '</span>') ?></div>
						
						<?php 
							$size = (get_option('avatar-size')) ? str_replace('px', '', strtolower(get_option('avatar-size'))) : '48';
							$avatar = (get_option('default-avatar')) ? get_avatar( get_comment_author_email(), $size, get_option('default-avatar') ) :  get_avatar( get_comment_author_email(), $size );
					 		echo (get_option('show-avatars')) ? $avatar : NULL; 
						?>
						
					</div> 
					<div class="comment-body">
					
							<?php if ($comment->comment_approved == '0') : ?>
									<p class="unapproved">Your comment is awaiting moderation.</p>
							<?php endif; ?>    


						<?php comment_text() ?>
				
						

						<div class="reply">
							<?php comment_reply_link(array_merge( $args, array('add_below' => 'div-comment', 'depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
						</div>
					</div>   
					<div class="clear"></div>
				</div> 
				
<?php 
} 
