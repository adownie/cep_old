<?php
function headway_install(){
	if(get_option('headway_installed') != 1):
	
		update_option('gzip', 1);
		update_option('site-style', 'headway');
		update_option('header-position', 'inside');
		update_option('navigation-position', 'below');
		update_option('show_tagline', 1);
		update_option('header-image-margin', '15px 15px 15px 15px');
		update_option('header-position', 'inside');
		update_option('breadcrumbs-position', 'below-header-navigation');
		update_option('wrapper-width', 950);
		update_option('wrapper-margin', 30);
		update_option('post-date-format', 1);
		update_option('post-comment-format-0', '%num% Comments');
		update_option('post-comment-format-1', '%num% Comment');
		update_option('post-comment-format', '%num% Comments');
		update_option('post-respond-format', 'Leave a comment!');
		update_option('post-below-title-left', 'Written on %date% by %author% in %categories%');
		update_option('post-below-title-right', '%comments% - %respond%');
		update_option('post-below-content-left', '%tags%');
		update_option('post-below-content-right', '%edit%');
		update_option('featured-posts', 1);
		update_option('show-avatars', 1);
		update_option('avatar-size', 48);
		
	
		update_option('fonts-body', 'georgia');
		update_option('fonts-header', 'georgia');
		update_option('fonts-header-tagline', 'georgia');
		update_option('fonts-navigation', 'georgia');
		update_option('fonts-breadcrumbs', 'georgia');
		update_option('fonts-sidebar', 'georgia');
		update_option('fonts-sidebar-widget-heading', 'georgia');
		update_option('fonts-leaf-headings', 'georgia');
		update_option('fonts-content', 'georgia');
		update_option('fonts-titles', 'georgia');
		update_option('fonts-post-h2', 'georgia');
		update_option('fonts-post-h3', 'georgia');
		update_option('fonts-post-h4', 'georgia');
		
		update_option('fonts-content-line-height', '1.75em');
		
		update_option('show-admin-link', 1);

		update_option('show-subpages', 1);
		

		update_option('title-home', '%tagline% | %blogname%');
		update_option('title-page', '%page% | %blogname%');
		update_option('title-posts-page', 'Blog | %blogname%');
		update_option('title-single', '%postname% | %blogname%');
		update_option('title-404', 'Whoops! 404 Error | %blogname%');
		update_option('title-category', '%category% | %blogname%');
		update_option('title-tag', '%tag% | %blogname%');
		update_option('title-archives', '%archive% | %blogname%');
		update_option('title-search', 'Search For: %search% | %blogname%');
		update_option('title-author-archives', '%author_name% | %blogname%');
	
		update_option('categories-meta', 1);
		update_option('tags-meta', 1);
		update_option('canonical', 1);
		update_option('nofollow-comment-author', 1);
		update_option('nofollow-home', 1);
		update_option('canonical', 1);
		update_option('noindex-category-archives', 0);
		update_option('noindex-archives', 0);
		update_option('noindex-tag-archives', 0);
		update_option('noindex-author-archives', 0);
	
		update_option('tweet-format', 'New at %blogname%: %postname% %url%');


			
	
		update_option('system-page-index-leafs', array('item_2', 'item_3', 'item_1'));		
		update_option('system-page-index-leaf_count', 3);
	


		update_option('system-page-index-item_3', array('text', 'Welcome to Headway!', 640, 190, 0, 1));
		update_option('system-page-index-item_3_options', '[{"name": "show-title", "value": "on"}, {"name": "custom-css-class", "value": "headway-welcome"}]');
		update_option('system-page-index-item_3_text', base64_encode('&lt;p&gt;Whoa!  Look at this spiffy blog.  Welcome to the Headway community.&lt;/p&gt;'."\n".'&lt;p&gt;&lt;strong&gt;Here are some things you should do now:&lt;/strong&gt;&lt;/p&gt;'."\n".'&lt;ul&gt;'."\n".'&lt;li&gt;Go to your Headway Configuration panel under Appearance and customize the settings to your likings.&lt;/li&gt;'."\n".'&lt;li&gt;Set up some page layouts in the Headway Layout Editor under Appearance.&lt;/li&gt;'."\n".'&lt;li&gt;Customize your sidebar(s) in the widgets panel under appearance.&lt;/li&gt;'."\n".'&lt;li&gt;Give your website a facelift using the Headway Design panel.&lt;/li&gt;'."\n".'&lt;li&gt;Delete this leaf in the Headway Layout Editor by choosing Blog Index under the System Pages.  Then click the edit link on the Welcome leaf to bring up the option to delete the leaf.&lt;/li&gt;'."\n".'&lt;li&gt;Finally, become an active member in the Headway Community!  Oh, and read the documentation :-) &lt;/li&gt;'."\n".'&lt;/ul&gt;'."\n"));
	

		update_option('system-page-index-item_1', array('content', 'Content', 640, 115, 0, 1));
		update_option('system-page-index-item_1_options', '[{"name": "mode", "value": "page"}, {"name": "other-page", "value": ""}, {"name": "categories-mode", "value": "include"}, {"name": "post_limit", "value": ""}, {"name": "featured_posts", "value": "1"}, {"name": "paginate", "value": "on"}, {"name": "custom-css-class", "value": ""}]');
	

		update_option('system-page-index-item_2', array('sidebar', ' Primary Sidebar', 250, 115, 1, 1));
		update_option('system-page-index-item_2_options', '[{"name": "duplicate-id", "value": ""}, {"name": "custom-css-class", "value": ""}]');



		 $page_404 = array();
		 $page_404['post_title'] = 'Whoops! 404 Error!';
		 $page_404['post_content'] = 'Well, it appears as if you entered in an invalid URL.  Please fix the URL you entered or try using the search functionality on our website.';
		 $page_404['post_status'] = 'publish';
		 $page_404['post_author'] = 1;
		 $page_404['post_type'] = 'page';
	

		 $page_404_id = wp_insert_post( $page_404 );
	
		 add_post_meta($page_404_id, '_show_navigation', '0');
		
		
		$update_navigation = new WP_Query('post_type=page&showposts=100');
		while ($update_navigation->have_posts()) : $update_navigation->the_post();
			if(!get_post_meta($update_navigation->post->ID, '_show_navigation', true)) add_post_meta($update_navigation->post->ID, '_show_navigation', 1);
			
			add_post_meta($update_navigation->post->ID, '_leafs', array('item_1'));
			add_post_meta($update_navigation->post->ID, '_leaf_count', 1);
			add_post_meta($update_navigation->post->ID, '_item_1', array('content', 'Content', 920, 115, 0, 1));
			add_post_meta($update_navigation->post->ID, '_item_1_options', '[{"name": "mode", "value": "page"}, {"name": "other-page", "value": ""}, {"name": "categories-mode", "value": "include"}, {"name": "post_limit", "value": ""}, {"name": "featured_posts", "value": "1"}, {"name": "paginate", "value": "on"}, {"name": "custom-css-class", "value": ""}]');
		endwhile;
		
		
		
		
		
		
		update_option('system-page-four04-leafs', array('item_3', 'item_4'));
		update_option('system-page-four04-leaf_count', 2);
		update_option('system-page-four04-item_3', array('content', 'Content', 640, 115, 0, 1));
		update_option('system-page-four04-item_3_options', '[{"name": "mode", "value": "page"}, {"name": "other-page", "value": "'.$page_404_id.'"}, {"name": "categories-mode", "value": "include"}, {"name": "post_limit", "value": ""}, {"name": "featured_posts", "value": "1"}, {"name": "paginate", "value": "on"}, {"name": "custom-css-class", "value": ""}]');
		update_option('system-page-four04-item_4', array('sidebar', 'Primary Sidebar', 250, 115, 0, 1));
		update_option('system-page-four04-item_4_options', '[{"name": "duplicate", "value": "on"}, {"name": "duplicate-id", "value": "2"}, {"name": "custom-css-class", "value": ""}]');


		
		update_option('system-page-archives-leafs', array('item_5', 'item_6'));
		update_option('system-page-archives-leaf_count', 2);
		update_option('system-page-archives-item_5', array('content', 'Content', 640, 115, 0, 1));
		update_option('system-page-archives-item_5_options', '[{"name": "mode", "value": "page"}, {"name": "other-page", "value": ""}, {"name": "categories-mode", "value": "include"}, {"name": "post_limit", "value": ""}, {"name": "featured_posts", "value": "1"}, {"name": "paginate", "value": "on"}, {"name": "custom-css-class", "value": ""}]');
		update_option('system-page-archives-item_6', array('sidebar', 'Primary Sidebar', 250, 115, 0, 1));
		update_option('system-page-archives-item_6_options', '[{"name": "duplicate", "value": "on"}, {"name": "duplicate-id", "value": "2"}, {"name": "custom-css-class", "value": ""}]');
		
		
		
		update_option('system-page-author-leafs', array('item_7', 'item_8'));
		update_option('system-page-author-leaf_count', 2);
		update_option('system-page-author-item_7', array('content', 'Content', 640, 115, 0, 1));
		update_option('system-page-author-item_7_options', '[{"name": "mode", "value": "page"}, {"name": "other-page", "value": ""}, {"name": "categories-mode", "value": "include"}, {"name": "post_limit", "value": ""}, {"name": "featured_posts", "value": "1"}, {"name": "paginate", "value": "on"}, {"name": "custom-css-class", "value": ""}]');
		update_option('system-page-author-item_8', array('sidebar', 'Primary Sidebar', 250, 115, 0, 1));
		update_option('system-page-author-item_8_options', '[{"name": "duplicate", "value": "on"}, {"name": "duplicate-id", "value": "2"}, {"name": "custom-css-class", "value": ""}]');
		
		
		update_option('system-page-search-leafs', array('item_9', 'item_10'));
		update_option('system-page-search-leaf_count', 2);
		update_option('system-page-search-item_9', array('content', 'Content', 640, 115, 0, 1));
		update_option('system-page-search-item_9_options', '[{"name": "mode", "value": "page"}, {"name": "other-page", "value": ""}, {"name": "categories-mode", "value": "include"}, {"name": "post_limit", "value": ""}, {"name": "featured_posts", "value": "1"}, {"name": "paginate", "value": "on"}, {"name": "custom-css-class", "value": ""}]');
		update_option('system-page-search-item_10', array('sidebar', 'Primary Sidebar', 250, 115, 0, 1));
		update_option('system-page-search-item_10_options', '[{"name": "duplicate", "value": "on"}, {"name": "duplicate-id", "value": "2"}, {"name": "custom-css-class", "value": ""}]');
		
		
		update_option('system-page-category-leafs', array('item_11', 'item_12'));
		update_option('system-page-category-leaf_count', 2);
		update_option('system-page-category-item_11', array('content', 'Content', 640, 115, 0, 1));
		update_option('system-page-category-item_11_options', '[{"name": "mode", "value": "page"}, {"name": "other-page", "value": ""}, {"name": "categories-mode", "value": "include"}, {"name": "post_limit", "value": ""}, {"name": "featured_posts", "value": "1"}, {"name": "paginate", "value": "on"}, {"name": "custom-css-class", "value": ""}]');
		update_option('system-page-category-item_12', array('sidebar', 'Primary Sidebar', 250, 115, 0, 1));
		update_option('system-page-category-item_12_options', '[{"name": "duplicate", "value": "on"}, {"name": "duplicate-id", "value": "2"}, {"name": "custom-css-class", "value": ""}]');
		
		
		
		update_option('system-page-single-leafs', array('item_13', 'item_14'));
		update_option('system-page-single-leaf_count', 2);
		update_option('system-page-single-item_13', array('content', 'Content', 640, 115, 0, 1));
		update_option('system-page-single-item_13_options', '[{"name": "mode", "value": "page"}, {"name": "other-page", "value": ""}, {"name": "categories-mode", "value": "include"}, {"name": "post_limit", "value": ""}, {"name": "featured_posts", "value": "1"}, {"name": "paginate", "value": "on"}, {"name": "custom-css-class", "value": ""}]');
		update_option('system-page-single-item_14', array('sidebar', 'Primary Sidebar', 250, 115, 0, 1));
		update_option('system-page-single-item_14_options', '[{"name": "duplicate", "value": "on"}, {"name": "duplicate-id", "value": "2"}, {"name": "custom-css-class", "value": ""}]');
		
		
		update_option('system-page-tag-leafs', array('item_15', 'item_16'));
		update_option('system-page-tag-leaf_count', 2);
		update_option('system-page-tag-item_15', array('content', 'Content', 640, 115, 0, 1));
		update_option('system-page-tag-item_15_options', '[{"name": "mode", "value": "page"}, {"name": "other-page", "value": ""}, {"name": "categories-mode", "value": "include"}, {"name": "post_limit", "value": ""}, {"name": "featured_posts", "value": "1"}, {"name": "paginate", "value": "on"}, {"name": "custom-css-class", "value": ""}]');
		update_option('system-page-tag-item_16', array('sidebar', 'Primary Sidebar', 250, 115, 0, 1));
		update_option('system-page-tag-item_16_options', '[{"name": "duplicate", "value": "on"}, {"name": "duplicate-id", "value": "2"}, {"name": "custom-css-class", "value": ""}]');

	


		update_option('headway_sidebars_system', array('index'));
	
	
		update_option('sidebars_widgets', array('sidebar-item_2' => array('subscribe-2', 'archives-2', 'links-2')));
		
		
		
		
		update_option('widget_archives', array('count' => 0, 'dropdown' => 0, 'title' => ''));
		update_option('widget_categories', array('453716521' => array('title' => '', 'count' => 0, 'hierarchical' => 0, 'dropdown' => 0)));
		update_option('widget_tag_cloud', array('title' => ''));

			

	
	
	
	
		$scheme['default'] = array(	
			'background' 							=> 'ffffff', 
			'default-hyperlink' 					=> '444444', 

			'wrapper-border' 						=> 'ffffff',

			'header-background' 					=> 'ffffff',
			'header-link'							=> '336699', 
			'header-link-underline'					=> 'ffffff', 	
			'header-tagline'						=> 'aaaaaa', 
			'header-bottom-border'					=> 'eeeeee',

			'navigation-background'					=> 'ffffff',
			'navigation-link-color'					=> '555555',
			'navigation-link-color-active'			=> '336699',
			'navigation-link-background-active'		=> 'ffffff',
			'navigation-link-border'				=> 'eeeeee',
			'navigation-bottom-border'				=> 'eeeeee',

			'breadcrumbs-background'				=> 'ffffff',
			'breadcrumbs-bottom-border'				=> 'eeeeee',
			'breadcrumbs-color'						=> '666666',
			'breadcrumbs-hyperlink-color'			=> '336699',


			'post-title'							=> '336699', 
			'post-title-hover'						=> '5b8dbf', 
			'post-content'							=> '444444', 
			'post-hyperlink'						=> '336699',
			'post-meta'								=> '888888', 
			'post-meta-hyperlink'					=> '888888', 
			'post-content-h2'						=> '666666',
			'post-content-h3'						=> '666666',
			'post-content-h4'						=> '336699',
			'post-bottom-border'					=> 'eeeeee',

			'leaf-title'							=> '555555', 
			'leaf-title-hyperlink'	 				=> '555555', 
			'leaf-title-underline'	 				=> '555555', 
			'leaf-content'	 						=> '333333', 

			'sidebar-bg'							=> 'ffffff',
			'widget-title'							=> '999999', 		
			'sidebar-hyperlinks'					=> '555555',

			'footer-text'							=> '444444',
			'footer-hyperlinks'						=> '444444',
			'footer-bg'								=> 'ffffff',
			'footer-top-border'						=> 'dddddd');
		
		foreach($scheme['default'] as $key => $value){
			update_option('color-'.$key, $value);
		}
		
	
	
	
	
	
	
	
	
	
	
	
		update_option('headway_installed', 1);
	endif;
	
	if(!get_option('fonts-header-size')){
		update_option('fonts-header-size', '3.4');
		update_option('fonts-header-tagline-size', '2');
		update_option('fonts-navigation-size', '1.1');
		update_option('fonts-breadcrumbs-size', '1');
		update_option('fonts-sidebar-size', '1');
		update_option('fonts-sidebar-widget-heading-size', '1.4');
		update_option('fonts-leaf-headings-size', '1.3');
		update_option('fonts-content-size', '1.1');
		update_option('fonts-titles-size', '2.2');
		update_option('fonts-post-h2-size', '1.8');
		update_option('fonts-post-h3-size', '1.6');
		update_option('fonts-post-h4-size', '1.2');
	}
	
	return true;
}

add_action('init', 'headway_install');