<?php
if(get_option('custom-stylesheet') == 1) require HEADWAYCUSTOM.'/custom_functions.php';
if(get_option('skin')) require HEADWAYSKINS.'/'.get_option('skin').'/functions.php';