<?php
function headway_above_title($count = 1, $single = false, $small_excerpts = false) {
	if(!$small_excerpts) do_action('headway_above_title', $count, $single);

	post_meta('title', 'above', false, false, false, $small_excerpts);
}
function headway_below_title($count = 1, $single = false, $small_excerpts = false) {	
	post_meta('title', 'below', false, false, false, $small_excerpts);
	
	if(!$small_excerpts) do_action('headway_below_title', $count, $single);    
}
function headway_below_content($count = 1, $single = false, $small_excerpts = false) {
	post_meta('content', 'below', false, false, false, $small_excerpts);
	
    if(!$small_excerpts) do_action('headway_below_content', $count, $single);
}






function easy_hook_before_everything(){
	echo stripslashes(get_option('easy-hooks-before-everything'));
}
add_action('headway_before_everything', 'easy_hook_before_everything');
function easy_hook_after_navigation(){
	echo stripslashes(get_option('easy-hooks-after-navigation'));
}
add_action('headway_after_navigation', 'easy_hook_after_navigation');
function easy_hook_after_breadcrumbs(){
	echo stripslashes(get_option('easy-hooks-after-breadcrumbs'));
}
add_action('headway_after_breadcrumbs', 'easy_hook_after_breadcrumbs');
function easy_hook_before_header_link(){
	echo stripslashes(get_option('easy-hooks-before-header-link'));
}
add_action('headway_before_header_link', 'easy_hook_before_header_link');
function easy_hook_after_header_link(){
	echo stripslashes(get_option('easy-hooks-after-header-link'));
}
add_action('headway_after_header_link', 'easy_hook_after_header_link');
function easy_hook_after_tagline(){
	echo stripslashes(get_option('easy-hooks-after-tagline'));
}
add_action('headway_after_tagline', 'easy_hook_after_tagline');
function easy_hook_leaf_top(){
	echo stripslashes(get_option('easy-hooks-leaf-top'));
}
add_action('headway_leaf_top', 'easy_hook_leaf_top');
function easy_hook_leaf_content_top(){
	echo stripslashes(get_option('easy-hooks-leaf-content-top'));
}
add_action('headway_leaf_content_top', 'easy_hook_leaf_content_top');
function easy_hook_leaf_content_bottom(){
	echo stripslashes(get_option('easy-hooks-leaf-content-bottom'));
}
add_action('headway_leaf_content_bottom', 'easy_hook_leaf_content_bottom');
function easy_hook_above_post(){
	echo stripslashes(get_option('easy-hooks-above-post'));
}
add_action('headway_above_post', 'easy_hook_above_post');
function easy_hook_above_title(){
	echo stripslashes(get_option('easy-hooks-above-title'));
}
add_action('headway_above_title', 'easy_hook_above_title');
function easy_hook_below_title(){
	echo stripslashes(get_option('easy-hooks-below-title'));
}
add_action('headway_below_title', 'easy_hook_below_title');
function easy_hook_below_content(){
	echo stripslashes(get_option('easy-hooks-below-post-content'));
}
add_action('headway_below_content', 'easy_hook_below_content');
function easy_hook_below_post(){
	echo stripslashes(get_option('easy-hooks-below-post'));
}
add_action('headway_below_post', 'easy_hook_below_post');

function easy_hook_above_page(){
	echo stripslashes(get_option('easy-hooks-above-page'));
}
add_action('headway_above_page', 'easy_hook_above_page');
function easy_hook_below_page_title(){
	echo stripslashes(get_option('easy-hooks-below-page-title'));
}
add_action('headway_below_page_title', 'easy_hook_below_page_title');
function easy_hook_below_page(){
	echo stripslashes(get_option('easy-hooks-below-page'));
}
add_action('headway_below_page', 'easy_hook_below_page');
function easy_hook_sidebar_top(){
	echo stripslashes(get_option('easy-hooks-sidebar-top'));
}
add_action('headway_sidebar_top', 'easy_hook_sidebar_top');
function easy_hook_sidebar_bottom(){
	echo stripslashes(get_option('easy-hooks-sidebar-bottom'));
}
add_action('headway_sidebar_bottom', 'easy_hook_sidebar_bottom');
function easy_hook_after_everything(){
	echo stripslashes(get_option('easy-hooks-after-everything'));
}
add_action('headway_after_everything', 'easy_hook_after_everything');