<?php 
function headway_navigation($echo = false){
	global $wpdb;
	
	
    $navigation_pages_query = "SELECT $wpdb->posts.* FROM $wpdb->posts INNER JOIN $wpdb->postmeta on $wpdb->posts.ID = $wpdb->postmeta.post_id WHERE $wpdb->posts.ID = $wpdb->postmeta.post_id AND $wpdb->posts.post_type = 'page' AND $wpdb->posts.post_status = 'publish' AND $wpdb->posts.post_parent = 0 AND $wpdb->postmeta.meta_key = '_navigation_position' AND $wpdb->posts.ID NOT IN (SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_show_navigation' AND meta_value='0') ORDER BY $wpdb->postmeta.meta_value ASC";

	$navigation_pages_query = $wpdb->get_results($navigation_pages_query, ARRAY_A);  //Gets all pages that have the navigation_position meta key set.

	$navigation_pages_query_no_meta = "SELECT $wpdb->posts.* FROM $wpdb->posts WHERE $wpdb->posts.post_type = 'page' AND $wpdb->posts.post_status = 'publish' AND $wpdb->posts.post_parent = 0 AND $wpdb->posts.ID NOT IN (SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_show_navigation' AND meta_value='0') AND $wpdb->posts.ID NOT IN (SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_navigation_position') ORDER BY $wpdb->posts.ID ASC";  //Gets all pages that DON'T have the navigation_position meta key set.

	$navigation_pages_query_no_meta = $wpdb->get_results($navigation_pages_query_no_meta, ARRAY_A);


	if($navigation_pages_query_no_meta && $navigation_pages_query) $navigation_pages_query = array_merge($navigation_pages_query_no_meta, $navigation_pages_query);
	if($navigation_pages_query_no_meta && !$navigation_pages_query) $navigation_pages_query = $navigation_pages_query_no_meta;
    

    if ($navigation_pages_query):
	    foreach ($navigation_pages_query as $page):
	
		
			$children_pages_query[$page['ID']] = "SELECT $wpdb->posts.* FROM $wpdb->posts INNER JOIN $wpdb->postmeta on $wpdb->posts.ID = $wpdb->postmeta.post_id WHERE $wpdb->posts.ID = $wpdb->postmeta.post_id AND $wpdb->posts.post_type = 'page' AND $wpdb->posts.post_status = 'publish' AND $wpdb->posts.post_parent = $page[ID] AND $wpdb->postmeta.meta_key = '_navigation_position' AND $wpdb->posts.ID NOT IN (SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_show_navigation' AND meta_value='0') ORDER BY $wpdb->postmeta.meta_value ASC";
			
			
			
			
		    $children_pages_query[$page['ID']] = $wpdb->get_results($children_pages_query[$page['ID']], ARRAY_A);
		
		    $children_pages_query_no_meta[$page['ID']] = "SELECT $wpdb->posts.* FROM $wpdb->posts WHERE $wpdb->posts.post_type = 'page' AND $wpdb->posts.post_status = 'publish' AND $wpdb->posts.post_parent = $page[ID] AND $wpdb->posts.ID NOT IN (SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_show_navigation' AND meta_value='0') AND $wpdb->posts.ID NOT IN (SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_navigation_position') ORDER BY $wpdb->posts.ID ASC";
				
				
			$children_pages_query_no_meta[$page['ID']] = $wpdb->get_results($children_pages_query_no_meta[$page['ID']], ARRAY_A);
			
		
			if($children_pages_query_no_meta[$page['ID']] && $children_pages_query[$page['ID']]) $children_pages_query[$page['ID']] = array_merge($children_pages_query_no_meta[$page['ID']], $children_pages_query[$page['ID']]);
			if($children_pages_query_no_meta[$page['ID']] && !$children_pages_query[$page['ID']]) $children_pages_query[$page['ID']] = $children_pages_query_no_meta[$page['ID']];
		
		
		
		
			if ($children_pages_query[$page['ID']] && get_option('show-subpages')):
			
				$children_pages[$page['ID']] .= '<ul>';
				
			    foreach ($children_pages_query[$page['ID']] as $child_page):
			
					$navigation_name = get_post_meta($child_page['ID'], '_navigation_name', true);
					$child_page['post_title'] = ($navigation_name) ? $navigation_name : $child_page['post_title'];
				
					if($child_page['ID'] == get_the_id()): 
						$current[$child_page['ID']] = ' current-page-item';
						$current_page_parent = $child_page['post_parent'];
					endif;
					$class = ' page-'.str_replace(' ', '-', strtolower($child_page['post_title']));
					
					
					
					if(get_write_box_value('nofollow_page', false, $child_page['ID']) == 1) $nofollow[$child_page['ID']] = ' rel="nofollow" '; 
				
					
					$link[$child_page['ID']] = (get_write_box_value('navigation_url', false, $child_page['ID'])) ? get_write_box_value('navigation_url', false, $child_page['ID']) : get_permalink($child_page['ID']);
					
				
					$children_pages[$page['ID']] .= "\n".'<li class="page-'.$child_page['ID'].$class.$current[$child_page['ID']].'"><a href="'.$link[$child_page['ID']].'"'.$nofollow[$child_page['ID']].'>'.$child_page['post_title'].'</a></li>'."\n";	
				
				endforeach;
				
				$children_pages[$page['ID']] .= '</ul>';
				
			endif;
				
		
			$navigation_name = get_post_meta($page['ID'], '_navigation_name', true);
			$page['post_title'] = ($navigation_name) ? $navigation_name : $page['post_title']; 
			
			
			if(is_home() || is_single() || is_search() || is_category() || is_date() || is_tag() || is_author()) $posts_page = get_option('page_for_posts');
			if(is_front_page()) $front_page = get_option('page_on_front');
			
			
			if($page['ID'] == get_the_id() || $page['ID'] == $front_page  && get_option('show_on_front') == 'page' || $page['ID'] == $posts_page && get_option('show_on_front') == 'page') $current[$page['ID']] = ' current-page-item';
			if($page['ID'] == $current_page_parent) $current[$page['ID']] = ' current-page-parent';
			
			if($page['ID'] == $front_page && get_option('nofollow-home')) $nofollow[$page['ID']] = ' rel="nofollow" ';
			
			
			$class = ' page-'.str_replace(' ', '-', strtolower($page['post_title']));
			
			$children[$page['ID']] = wp_list_pages('title_li=&child_of='.$page['ID'].'&echo=0');
			
			if($children[$page['ID']]) $parent_class[$page['ID']] = ' page-parent';
			
			
			if(get_write_box_value('nofollow_page', false, $page['ID']) == 1) $nofollow[$page['ID']] = ' rel="nofollow" '; 
			
			
			$link[$page['ID']] = (get_write_box_value('navigation_url', false, $page['ID'])) ? get_write_box_value('navigation_url', false, $page['ID']) : get_permalink($page['ID']);
			
			
			
			$navigation_pages .= "\n".'<li class="page-'.$page['ID'].$class.$current[$page['ID']].$parent_class[$page['ID']].'"><a href="'.$link[$page['ID']].'"'.$nofollow[$page['ID']].'>'.$page['post_title'].'</a>'.$children_pages[$page['ID']].'</li>'."\n";
		?>		
	    <?php 
		endforeach;
    endif;



	if(headway_breadcrumbs(true, false)) $breadcrumb_class = ' breadcrumb-active';
	
	

	
	$return = "\n".'<ul class="navigation'.$breadcrumb_class.'" id="header-navigation">'."\n";

		$return .= apply_filters( 'headway_navigation_beginning', '' );
	
	
	if(get_option('show_on_front') == 'posts'):
		if(get_option('nofollow-home')) $nofollow['home'] = ' rel="nofollow" ';
		if(is_home() || is_front_page()) $current['home'] = ' current-page-item';
		$home_text = (get_option('home-link-text')) ? get_option('home-link-text') : 'Home';
		if(!get_option('hide-home-link')) $return .= '<li class="page-item-1'.$current['home'].'"><a href="'.get_option('home').'"'.$nofollow['home'].'>'.$home_text.'</a></li>';
	endif;
	
	$return .= $navigation_pages;
	$return .= apply_filters( 'headway_navigation_end', '' );
	$return .= "\n".'</ul>'."\n";
	
	if($echo) echo $return;	
	if(!$echo) return $return;
	
	
}