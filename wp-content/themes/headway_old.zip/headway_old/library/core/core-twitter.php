<?php
function shortenURL($url){
	if(function_exists('curl_init')):
	
		$query = 'http://is.gd/api.php?longurl='.$url;
	
		$init = curl_init();
		curl_setopt($init, CURLOPT_URL, $query);
		curl_setopt($init, CURLOPT_RETURNTRANSFER, 1);
		$shortenedURL = curl_exec($init);
		curl_close($init);
	
		return $shortenedURL;

	else:
		return 'We\'re sorry, but your web host does not support cURL.  We suggest you get a new web host :-)';
	endif;
}



function getTwitterUpdates($twitter_username, $limit = 10, $date_format = "F j, Y \&\m\d\a\s\h\; g:i a"){

	$timeline = "http://twitter.com/statuses/user_timeline/$twitter_username.rss";
	$timeline_rss = @file_get_contents($timeline);

	if($timeline_rss)
	{
		$tweets = @simplexml_load_string($timeline_rss);
		if($tweets)
		{
			if($tweets->channel->item){
				foreach($tweets->channel->item as $tweet)
				{
					if ($i++ >= $limit) { break; } 
					echo '<li>'.substr($tweet->description, strlen($twitter_username)+2);
					echo '<span>'.date($date_format, strtotime($tweet->pubDate)).'</span></li>';
				}
			}
			else
			{
				'Eek! There was an error fetching the Twitter feed.';
			}
		}
		else
		{
			echo "Error!  RSS file is invalid.";
		}
	}
	else
	{
		echo "Error.  Twitter stream not found. Make sure you entered a valid username.";
	}

}