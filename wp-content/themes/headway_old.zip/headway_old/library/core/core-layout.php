<?
function headway_page_top(){
	if(get_option('custom-stylesheet') == 1) $custom = ' custom';
	if(get_option('site-style')) $skin = ' skin-'.strtolower(str_replace(' ', '-', get_option('site-style')));
	
	echo '<body class="'.blog_body_class(false).$custom.' '.font('body').' header-'.get_option('header-position').$skin.'">';

	do_action('headway_before_everything');
	
	
	if(get_option('header-position') == 'inside'):
		$header_open = '<div id="header" class="'.font('header').'">'."\n";
		$header_close = '</div><!-- #header -->'."\n";
		$wrapper_inside = '<div id="wrapper">'."\n";
		$position = 'inside';
	elseif(get_option('header-position') == 'outside'):
		$header_open = '<div id="header-container" class="'.font('header').'">'."\n".'<div id="header">'."\n";
		$header_close = '</div><!-- #header -->'."\n".'</div><!-- #header-container -->'."\n";
		$wrapper_outside = "\n".'<div id="wrapper">'."\n";
		$position = 'outside';
	endif;
	
	if($position == 'outside') $navigation  = '<div id="navigation-container">'."\n";
							   $navigation .= '<div id="navigation" class="'.font('navigation').'">'."\n";
							   $navigation .= headway_navigation();
		 					   $navigation .= "\n".'</div>'."\n";
	if($position == 'outside') $navigation .= '</div>'."\n";

	if(headway_breadcrumbs(true)):
		if($position == 'outside') $breadcrumbs  = '<div id="breadcrumbs-container">'."\n";
		 						   $breadcrumbs .= headway_breadcrumbs(false);
		if($position == 'outside') $breadcrumbs .= '</div><!-- #breadcrumbs-container -->'."\n";
	endif;
	
	
	echo $wrapper_inside;
	
		
		if(get_option('breadcrumbs-position') == 'above-header-navigation'): echo $breadcrumbs; do_action('headway_after_breadcrumbs'); endif;
		if(get_option('navigation-position') == 'above'): echo $navigation; do_action('headway_after_navigation'); endif;
		if(get_option('breadcrumbs-position') == 'above-header'): echo $breadcrumbs; do_action('headway_after_breadcrumbs'); endif;
	
		echo $header_open;
	
	
			$header_link_content = (get_option('header-image')) ? '<img src="'.get_option('header-image').'" alt="'.get_bloginfo('name').'" />'."\n" : get_bloginfo('name');
			$header_link_class = (get_option('header-image')) ? 'header-link-image' : 'header-link-text';
			$header_link_class_inside = (get_option('header-image')) ? 'header-link-image-inside' : 'header-link-text-inside';
			
			do_action('headway_before_header_link');
			
			if(get_option('nofollow-home')) $nofollow['home'] = ' nofollow';
	
			echo '<div id="top" class="'.$header_link_class.' header-link-top clearfix"><a href="'.get_option('home').'" title="'.get_bloginfo('name').'" rel="home'.$nofollow['home'].'" class="'.$header_link_class_inside.'">'.$header_link_content.'</a>';
			do_action('headway_after_header_link');
			echo '</div>'."\n";
			
	
	
			echo (get_option('show_tagline') == '1') ? '<h1 id="tagline" class="'.font('header-tagline').'">'.get_bloginfo('description').'</h1>'."\n" : '<h1 id="tagline" class="'.font('header-tagline').' hidden">'.get_bloginfo('description').'</h1>'."\n";
	
			do_action('headway_after_tagline');
	
	
		echo $header_close;
	
	
		if(get_option('breadcrumbs-position') == 'below-header'): echo $breadcrumbs; do_action('headway_after_breadcrumbs'); endif;
		if(get_option('navigation-position') == 'below'): echo $navigation; do_action('headway_after_navigation'); endif;
		if(get_option('breadcrumbs-position') == 'below-header-navigation'): echo $breadcrumbs; do_action('headway_after_breadcrumbs'); endif;
			
	
		
	echo $wrapper_outside;
	
	do_action('headway_page_start');
}



function headway_breadcrumbs($test = false, $echo = false, $force_display = false){
	if((!is_front_page() && get_option('show_breadcrumbs') == '1') || $force_display){
		if(get_post_meta(get_the_id(), '_hide_breadcrumbs', true) != '1'){ //If statement was being mean to me so I had to nest it :-(
			$breadcrumbs_enabled = true;
			if($test) return $breadcrumbs_enabled;  //Allows this function to be called upon to test if breadcrumbs are enabled
		} else {
			$breadcrumbs_enabled = false;
			if($test) return $breadcrumbs_enabled;
		}
	} else {
		$breadcrumbs_enabled = false;
		if($test) return $breadcrumbs_enabled;
	}
		
			
	
	if($breadcrumbs_enabled){
		
	
		$return = '<div id="breadcrumbs" class="'.font('breadcrumbs').'"><p>You Are Here: &nbsp; <a href="'.get_bloginfo('url').'">Home</a>';
			if(get_option('page_for_posts') != get_option('page_on_front') && get_option('show_on_front') == 'page'):
				if(is_home()) $return .= ' &raquo; '.get_the_title(get_option('page_for_posts'));
				$blog = ' &raquo; <a href="'.get_page_link(get_option('page_for_posts')).'">'.get_the_title(get_option('page_for_posts')).'</a>';
			endif;
			if(is_page()){
				global $post;
				$current_page = array($post);
				$parent = $post;
				while ( $parent->post_parent ){
					$parent = get_post( $parent->post_parent );
					array_unshift( $current_page, $parent );
				}
				foreach ( $current_page as $page){
					if($page->ID != get_the_id()):
						$link_open[$page->ID] = '<a href="' . get_page_link( $page->ID ) . '">';
						$link_close[$page->ID] = '</a>';
					endif;
					$return .= ' &raquo; '.$link_open[$page->ID].$page->post_title.$link_close[$page->ID].$separator;
				}
						
				
			}		 
			elseif(is_category()){$return .= $blog.' &raquo; '.single_cat_title('', false);}
			elseif(is_single()){$return .= $blog.' &raquo; '.get_the_category_list(', ').' &raquo; '.get_the_title();}
			elseif(is_search()){$return .= $blog.' &raquo; Search Results For: '.get_search_query();}
			elseif(is_author()){
				if(get_query_var('author_name')) :
					$authordata = get_userdatabylogin(get_query_var('author_name'));
				else :
					$authordata = get_userdata(get_query_var('author'));
				endif;
				$return .= $blog.' &raquo; Author Archives: '.$authordata->display_name;
			}
			elseif(is_404()){$return .= ' &raquo; 404 Error!';}
			elseif(is_tag()){$return .= $blog.' &raquo; Tag Archives: '.single_tag_title('', false);}
			elseif(is_date()){$return .= $blog.' &raquo; Archives: '.get_the_time('F Y'); }
		$return .= '</p></div>';
		
		
		if($echo) echo $return;
		if(!$echo) return $return;
		
	
	}
	
}






function headway_header(){
	echo parse_php(stripslashes(html_entity_decode(get_option('header-scripts'))));
}

function headway_footer(){
	echo parse_php(stripslashes(html_entity_decode(get_option('footer-scripts'))));
}



function headway_html_open(){
	headway_gzip();
	echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US">
	<head profile="http://gmpg.org/xfn/11">';
}


function headway_html_close(){
	wp_footer();

	do_action('headway_after_everything');
	
	echo '</body>';
	echo '</html>';
}


add_action('wp_head', 'headway_header');
add_action('wp_footer', 'headway_footer');