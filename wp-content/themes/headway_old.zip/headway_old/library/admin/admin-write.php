<?php
require_once HEADWAYCORE.'/core-meta-box-class.php';

$SEO_Box['id'] = 'seo';
$SEO_Box['name'] = 'Search Engine Optimization (SEO)';
$SEO_Box['options'] = array(
	array(
		'id' => 'title',
		'name' => 'Title',
		'type' => 'text'
	),
	array(
		'id' => 'description',
		'name' => 'Description',
		'type' => 'textarea'
	),
	array(
		'id' => 'keywords',
		'name' => 'Keywords',
		'type' => 'textarea'
	),
	array(
		'id' => 'noindex',
		'name' => '<code>noindex</code> this post.',
		'type' => 'checkbox'
	),
	array(
		'id' => 'nofollow_links',
		'name' => '<code>nofollow</code> links in this post.',
		'type' => 'checkbox'
	),
);
$SEO_Box['defaults'] = array(
);
$SEO_Box['info'] = '<strong>Confused on what this is or how it works?  Head on over to the <a href="">Headway Write Screen</a> video.</strong>';
$SEO_Box['type'] = 'post';
$SEO_Box = new MetaBox($SEO_Box['id'], $SEO_Box['name'], $SEO_Box['options'], $SEO_Box['defaults'], $SEO_Box['info'], $SEO_Box['type']);




$SEO_Box_Page['id'] = 'seo';
$SEO_Box_Page['name'] = 'Search Engine Optimization (SEO)';
$SEO_Box_Page['options'] = array(
	array(
		'id' => 'title',
		'name' => 'Title',
		'type' => 'text'
	),
	array(
		'id' => 'description',
		'name' => 'Description',
		'type' => 'textarea'
	),
	array(
		'id' => 'keywords',
		'name' => 'Keywords',
		'type' => 'textarea'
	),
	array(
		'id' => 'noindex',
		'name' => '<code>noindex</code> this page.',
		'type' => 'checkbox'
	),
	array(
		'id' => 'nofollow_links',
		'name' => '<code>nofollow</code> links in this page.',
		'type' => 'checkbox'
	),
	array(
		'id' => 'nofollow_page',
		'name' => '<code>nofollow</code> navigation link to this page.',
		'type' => 'checkbox'
	)
);
$SEO_Box_Page['defaults'] = array(
);
$SEO_Box_Page['info'] = '<strong>Confused on what this is or how it works?  Head on over to the <a href="">Headway Write Screen</a> video.</strong>';
$SEO_Box_Page['type'] = 'page';
$SEO_Box_Page = new MetaBox($SEO_Box_Page['id'], $SEO_Box_Page['name'], $SEO_Box_Page['options'], $SEO_Box_Page['defaults'], $SEO_Box_Page['info'], $SEO_Box_Page['type']);




$Dynamic_Content_Box['id'] = 'display';
$Dynamic_Content_Box['name'] = 'Display';
$Dynamic_Content_Box['options'] = array(
	array(
		'id' => 'dynamic-content',
		'name' => 'Dynamic Content',
		'type' => 'textarea'
	)
);
$Dynamic_Content_Box['defaults'] = array('');
$Dynamic_Content_Box['type'] = 'post';
$Dynamic_Content_Box = new MetaBox($Dynamic_Content_Box['id'], $Dynamic_Content_Box['name'], $Dynamic_Content_Box['options'], $Dynamic_Content_Box['defaults'], $Dynamic_Content_Box['info'], $Dynamic_Content_Box['type']);





$Display_Box_Page['id'] = 'misc';
$Display_Box_Page['name'] = 'Miscellaneous';
$Display_Box_Page['options'] = array(
	array(
		'id' => 'custom-title',
		'name' => 'Alternate Page Title',
		'type' => 'text'
	),
	array(
		'id' => 'show_navigation',
		'name' => 'Show In Navigation Bar',
		'type' => 'checkbox'
	),
	array(
		'id' => 'navigation_url',
		'name' => 'Navigation Forward URL',
		'type' => 'text'
	),
	array(
		'id' => 'hide_breadcrumbs',
		'name' => 'Hide Breadcrumbs',
		'type' => 'checkbox'
	),
	array(
		'id' => 'hide_title',
		'name' => 'Hide Page Title',
		'type' => 'checkbox'
	)
);
$Display_Box_Page['defaults'] = array(
		'hide_breadcrumbs' => '0',
		'show_navigation' => '1'
);
$Display_Box_Page['type'] = 'page';
$Display_Box_Page = new MetaBox($Display_Box_Page['id'], $Display_Box_Page['name'], $Display_Box_Page['options'], $Display_Box_Page['defaults'], $Display_Box_Page['info'], $Display_Box_Page['type']);



$Misc_Box['id'] = 'misc';
$Misc_Box['name'] = 'Miscellaneous';
$Misc_Box['options'] = array(
	array(
		'id' => 'post_to_twitter',
		'name' => 'Post To Twitter',
		'type' => 'checkbox'
	),
	array(
		'id' => 'hide_breadcrumbs',
		'name' => 'Hide Breadcrumbs',
		'type' => 'checkbox'
	)
);
if(get_option('headway-post-to-twitter')){
	$Misc_Box['defaults'] = array(
		'hide_breadcrumbs' => '0',
		'post_to_twitter' => '1'
	);
} else {
	$Misc_Box['defaults'] = array(
		'hide_breadcrumbs' => '0'
	);
}
$Misc_Box['type'] = 'post';

$Misc_Box = new MetaBox($Misc_Box['id'], $Misc_Box['name'], $Misc_Box['options'], $Misc_Box['defaults'], $Misc_Box['info'], $Misc_Box['type']);





$Template_Box['id'] = 'template_box';
$Template_Box['name'] = 'Leaf Template';
$Template_Box['options'] = array(
	array(
		'id' => 'leaf_template',
		'name' => 'Leaf Template',
		'type' => 'page-select'
	)
);
$Template_Box['defaults'] = array();
$Template_Box['type'] = 'page';
$Template_Box['info'] = '<strong>By selecting a page below you can make this page copy the leafs (NOT THE PAGE CONTENT) to this page.</strong>';

$Template_Box = new MetaBox($Template_Box['id'], $Template_Box['name'], $Template_Box['options'], $Template_Box['defaults'], $Template_Box['info'], $Template_Box['type']);








require HEADWAYCORE.'/core-twitter.class.php';


function PostToTwitter($post_ID, $post){
	if(get_option('twitter-username') && get_option('twitter-password') && get_option('tweet-format')):
		$twitter = new twitter(get_option('twitter-username'), get_option('twitter-password'));
	
	
		$url = shortenURL(get_permalink($post_ID));
		$postname = get_the_title($post_ID);
		$blogname = get_bloginfo('name');
		
		
		
		$format = get_option('tweet-format');
		$format = str_replace('%url%', $url, $format);
		$format = str_replace('%postname%', $postname, $format);
		$format = str_replace('%blogname%', $blogname, $format);
		
		
	
		if(get_write_box_value('post_to_twitter', false, $post_ID) == '1' || get_option('headway-post-to-twitter')):
			if(get_write_box_value('post_to_twitter', false, $post_ID) != '0'){
		    	$twitter->setStatus($format);
			}
		endif;
	endif;
}
add_action('publish_post', 'PostToTwitter', 10, 2);












function AddDefaultLeaf($post_ID, $post){
	add_post_meta($post_ID, '_leafs', array('item_1'));
	add_post_meta($post_ID, '_leaf_count', 1);
	add_post_meta($post_ID, '_item_1', array('content', 'Content', get_option('wrapper-width')-30, 115, 0, 1));
	add_post_meta($post_ID, '_item_1_options', '[{"name": "mode", "value": "page"}, {"name": "other-page", "value": ""}, {"name": "categories-mode", "value": "include"}, {"name": "post_limit", "value": "'.get_option('posts_per_page').'"}, {"name": "featured_posts", "value": "1"}, {"name": "paginate", "value": "on"}, {"name": "custom-css-class", "value": ""}]');	
}


add_action('publish_page', 'AddDefaultLeaf', 10, 2);




