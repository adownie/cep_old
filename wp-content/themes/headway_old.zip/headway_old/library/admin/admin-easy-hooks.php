<h2>Headway Easy Hooks</h2>

<p>Headway Easy Hooks provides you a simple way to add content to your site that would otherwise be impossible (without hacking, of course).  You can use HTML in the following boxes.  If you need to use PHP, please refer to the documentation on how to use actual hooks.</p>

<?php
 	if($_POST): 

	foreach($_POST as $key => $value):
		update_option($key, $value);
	endforeach;
?>
<div class="success"><span>Hooks Updated!</span> <a href="<?php echo get_bloginfo('url')?>">View Site &raquo;</a></div>
<?php endif; ?>

<form method="post">

		<p class="submit">
		<input type="submit" value="Save Changes" class="button-primary" name="Submit"/>
		</p>
			
			<table class="form-table">
			<tbody>

				<tr valign="top">
					<th scope="row"><label for="before-everything">Before Everything</label></th>
					<td><textarea rows="15" cols="55" class="regular-text" id="before-everything" name="easy-hooks-before-everything"><?php echo stripslashes(get_option('easy-hooks-before-everything'))?></textarea>
					<span class="setting-description">Will be placed right after the <code>&lt;body&gt;</code> tag is opened.</span></td>
				</tr>
				<tr valign="top">
					<th scope="row"><label for="after-navigation">After Navigation</label></th>
					<td><textarea rows="15" cols="55" class="regular-text" id="after-navigation" name="easy-hooks-after-navigation"><?php echo stripslashes(get_option('easy-hooks-after-navigation'))?></textarea>
					<span class="setting-description">Will be displayed after the navigation in the header.</span></td>
				</tr>
				
				<tr valign="top">
					<th scope="row"><label for="after-breadcrumbs">After Breadcrumbs</label></th>
					<td><textarea rows="15" cols="55" class="regular-text" id="after-breadcrumbs" name="easy-hooks-after-breadcrumbs"><?php echo stripslashes(get_option('easy-hooks-after-breadcrumbs'))?></textarea>
					<span class="setting-description">After the breadcrumbs.</span></td>
				</tr>
				
								
				<tr valign="top">
					<th scope="row"><label for="after-header-link">Before Header Link</label></th>
					<td><textarea rows="15" cols="55" class="regular-text" id="before-header-link" name="easy-hooks-before-header-link"><?php echo stripslashes(get_option('easy-hooks-before-header-link'))?></textarea>
					<span class="setting-description">Before the header link.</span></td>
				</tr>
				
				
				
				<tr valign="top">
					<th scope="row"><label for="after-header-link">After Header Link</label></th>
					<td><textarea rows="15" cols="55" class="regular-text" id="after-header-link" name="easy-hooks-after-header-link"><?php echo stripslashes(get_option('easy-hooks-after-header-link'))?></textarea>
					<span class="setting-description">After the header link.  This is either the name of the site or the logo you place there.</span></td>
				</tr>
				
				<tr valign="top">
					<th scope="row"><label for="after-tagline">After Tagline</label></th>
					<td><textarea rows="15" cols="55" class="regular-text" id="after-tagline" name="easy-hooks-after-tagline"><?php echo stripslashes(get_option('easy-hooks-after-tagline'))?></textarea>
					<span class="setting-description">After the tagline.  This is generally the slogan that will show up in your header.</span></td>
				</tr>
				
				<tr valign="top">
					<th scope="row"><label for="leaf-top">Leaf Top</label></th>
					<td><textarea rows="15" cols="55" class="regular-text" id="leaf-top" name="easy-hooks-leaf-top"><?php echo stripslashes(get_option('easy-hooks-leaf-top'))?></textarea>
					<span class="setting-description">This will be placed at the top of all leafs.</span></td>
				</tr>
				
				<tr valign="top">
					<th scope="row"><label for="leaf-content-top">Leaf Content Top</label></th>
					<td><textarea rows="15" cols="55" class="regular-text" id="leaf-content-top" name="easy-hooks-leaf-content-top"><?php echo stripslashes(get_option('easy-hooks-leaf-content-top'))?></textarea>
					<span class="setting-description">This will be placed at the top of all the leafs, but generally under the title.</span></td>
				</tr>
				
				<tr valign="top">
					<th scope="row"><label for="leaf-content-bottom">Leaf Content Bottom</label></th>
					<td><textarea rows="15" cols="55" class="regular-text" id="leaf-content-bottom" name="easy-hooks-leaf-content-bottom"><?php echo stripslashes(get_option('easy-hooks-leaf-content-bottom'))?></textarea>
					<span class="setting-description">Will be placed at the bottom of each leaf.</span></td>
				</tr>
				
				<tr valign="top">
					<th scope="row"><label for="above-post">Above Post</label></th>
					<td><textarea rows="15" cols="55" class="regular-text" id="above-post" name="easy-hooks-above-post"><?php echo stripslashes(get_option('easy-hooks-above-post'))?></textarea>
					<span class="setting-description">Goes before each post.</span></td>
				</tr>
				
				<tr valign="top">
					<th scope="row"><label for="above-post-title">Above Post Title</label></th>
					<td><textarea rows="15" cols="55" class="regular-text" id="above-post-title" name="easy-hooks-above-post-title"><?php echo stripslashes(get_option('easy-hooks-above-post-title'))?></textarea>
					<span class="setting-description">Goes above the post title, and above the meta if you choose to place any up there.</span></td>
				</tr>
				
				<tr valign="top">
					<th scope="row"><label for="below-post-title">Below Post Title</label></th>
					<td><textarea rows="15" cols="55" class="regular-text" id="below-post-title" name="easy-hooks-below-post-title"><?php echo stripslashes(get_option('easy-hooks-below-post-title'))?></textarea>
					<span class="setting-description">Goes below the meta below the title and the title.</span></td>
				</tr>
				
				<tr valign="top">
					<th scope="row"><label for="below-post-content">Below Post Content</label></th>
					<td><textarea rows="15" cols="55" class="regular-text" id="below-post-content" name="easy-hooks-below-post-content"><?php echo stripslashes(get_option('easy-hooks-below-post-content'))?></textarea>
					<span class="setting-description">Goes below the main text of the post.</span></td>
				</tr>
				
				<tr valign="top">
					<th scope="row"><label for="below-post">Below Post</label></th>
					<td><textarea rows="15" cols="55" class="regular-text" id="below-post" name="easy-hooks-below-post"><?php echo stripslashes(get_option('easy-hooks-below-post'))?></textarea>
					<span class="setting-description">Goes at the complete bottom of each post.</span></td>
				</tr>
				
				<tr valign="top">
					<th scope="row"><label for="above-page">Above Page</label></th>
					<td><textarea rows="15" cols="55" class="regular-text" id="above-page" name="easy-hooks-above-page"><?php echo stripslashes(get_option('easy-hooks-above-page'))?></textarea>
					<span class="setting-description">Goes at the top of each page.</span></td>
				</tr>

				<tr valign="top">
					<th scope="row"><label for="below-page-title">Below Page Title</label></th>
					<td><textarea rows="15" cols="55" class="regular-text" id="below-page-title" name="easy-hooks-below-page-title"><?php echo stripslashes(get_option('easy-hooks-below-page-title'))?></textarea>
					<span class="setting-description">Goes below the page titles.</span></td>
				</tr>
				
				<tr valign="top">
					<th scope="row"><label for="below-page">Below Page</label></th>
					<td><textarea rows="15" cols="55" class="regular-text" id="below-page" name="easy-hooks-below-page"><?php echo stripslashes(get_option('easy-hooks-below-page'))?></textarea>
					<span class="setting-description">Goes at the complete bottom of each page.</span></td>
				</tr>
				
				<tr valign="top">
					<th scope="row"><label for="sidebar-top">Sidebar Top</label></th>
					<td><textarea rows="15" cols="55" class="regular-text" id="sidebar-top" name="easy-hooks-sidebar-top"><?php echo stripslashes(get_option('easy-hooks-sidebar-top'))?></textarea>
					<span class="setting-description">Will be placed at the top of all sidebar leafs.</span></td>
				</tr>
				
				<tr valign="top">
					<th scope="row"><label for="sidebar-bottom">Sidebar Bottom</label></th>
					<td><textarea rows="15" cols="55" class="regular-text" id="sidebar-bottom" name="easy-hooks-sidebar-bottom"><?php echo stripslashes(get_option('easy-hooks-sidebar-bottom'))?></textarea>
					<span class="setting-description">Will be placed at the bottom of all sidebar leafs.</span></td>
				</tr>
				<tr valign="top">
					<th scope="row"><label for="after-everything">After Everything</label></th>
					<td><textarea rows="15" cols="55" class="regular-text" id="after-everything" name="easy-hooks-after-everything"><?php echo stripslashes(get_option('easy-hooks-after-everything'))?></textarea>
					<span class="setting-description">Will be placed right before the <code>&lt;body&gt;</code> tag is closed.</span></td>
				</tr>

				
			
			</tbody>
			</table>
			
		
					
		
	</div>

	<p class="submit">
	<input type="submit" value="Save Changes" class="button-primary" name="Submit"/>
	</p>
</form>