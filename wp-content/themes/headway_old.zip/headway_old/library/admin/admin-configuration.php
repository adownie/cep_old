<h2>Headway Configuration</h2>

<?php
 	if($_POST): 
	$noTouchy = array('navigation-page-order', 'navigation-children');

	foreach($_POST as $key => $value):
	
		if(strpos($key, '_unchecked')):
			$key = str_replace('_unchecked', '', $key);
			if($_POST[$key] == NULL) $value = 0;
		endif;
		
		if($key == 'featured-posts') $value = ($value > get_option('posts_per_page')) ? get_option('posts_per_page') : $value;
		
		if(!in_array($key, $noTouchy)) update_option($key, $value);
	endforeach;

	$disabled = (get_option('skin')) ? get_option('headway_skin_disabled') : NULL;
?>
<div class="success"><span>Configuration Updated!</span> <a href="<?php echo get_bloginfo('url')?>">View Site &raquo;</a></div>
<?php endif; ?>

<form method="post">
	<div id="tabs">
		<ul>
			<li><a href="#general">General</a></li>
			<li><a href="#navigation">Navigation</a></li>
			<li><a href="#seo">Search Engine Optimization (SEO)</a></li>
			<li><a href="#social-networking">Social Networking</a></li>
		</ul>
		
		
		<div id="general">
			<h3>General Options</h3>
			<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row"><label for="feed-url">Feed URL</label></th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(get_option('feed-url')) ?>" id="feed-url" name="feed-url"/>
					<span class="description">If you use any service like <a href="http://feedburner.google.com" target="_blank">FeedBurner</a>, type the feed URL here.</span></td>
				</tr>
				
		
		
		
				<tr valign="top">
					<th scope="row"><label for="header-scripts">Header Scripts</label></th>
					<td><textarea rows="10" cols="55" class="regular-text" id="" name="header-scripts"><?php echo stripslashes(get_option('header-scripts')) ?></textarea>
					<span class="description">Anything here will go in the <code>&lt;head&gt;</code> of the website.</span></td>
				</tr>

		
				<tr valign="top">
					<th scope="row"><label for="footer-scripts">Footer Scripts</label></th>
					<td><textarea rows="10" cols="55" class="regular-text" id="" name="footer-scripts"><?php echo stripslashes(get_option('footer-scripts')) ?></textarea>
					<span class="description">Anything here will be inserted before the <code>&lt;/body&gt;</code> tag of the website.  If you have any stats scripts such as <a href="http://www.google.com/analytics" target="_blank">Google Analytics</a>, paste them here. </span></td>
				</tr>
		
		
		
			
				<tr valign="top">
					<th scope="row"><abbr title="gzip is a software application used for file compression. gzip is short for GNU zip; the program is a free software replacement for the compress program used in early Unix systems, intended for use by the GNU Project.">gzip</abbr> Compression</th>
					<td> 
						<fieldset>
							<legend class="hidden">gzip Compression</legend>
							<label for="gzip">
								<?php buildCheckbox('gzip') ?>
								Enable <abbr title="gzip is a software application used for file compression. gzip is short for GNU zip; the program is a free software replacement for the compress program used in early Unix systems, intended for use by the GNU Project.">gzip</abbr> Compression
							</label>
						</fieldset>
					<span class="description"><abbr title="gzip is a software application used for file compression. gzip is short for GNU zip; the program is a free software replacement for the compress program used in early Unix systems, intended for use by the GNU Project.">gzip</abbr> compression allows your pages to load faster and make it easier on your visitors.  Compression is recommended, but some web hosts may not support gzip compression.</span></td>
				</tr>
				
				
				
				<tr valign="top">
					<th scope="row"><label for="favicon">Favicon Location</label></th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(get_option('favicon')) ?>" id="favicon" name="favicon"/>
					<span class="description">A favicon is the little image that sits next to your address in the favorites menu and on tabs.  If you do not know how to save an image as an icon you can go to <a href="http://www.favicon.cc/" target="_blank">favicon.cc</a> and draw or import an image.</span></td>
				</tr>
				
				
				<tr valign="top">
					<th scope="row"><label for="affiliate_link">Affiliate Link</label></th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(get_option('affiliate_link')) ?>" id="affiliate_link" name="affiliate_link"/>
					<span class="description">If you're a member of the Headway Affiliate program (if not, you should definitely <a href="http://www.headwaythemes.com/affiliates/" target="_blank">sign up now!</a>), you can paste your affiliate link (found at the top of the affiliate panel) and earn money when purchase Headway after people have been sent from your affiliate link.</span></td>
				</tr>

		
		
			</tbody>
			</table>
		</div>
		
		
		<div id="navigation">
			<h3>Navigation</h3>
			
			
			<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row">Sub-pages</th>
					<td> 
						<fieldset>
							<legend class="hidden">Show Sub-pages</legend>
							<label for="show-home-link">
								<?php buildCheckbox('show-subpages') ?>
								Show Sub-pages
							</label>
						</fieldset>
					</td>
				</tr>
				
				<? if((get_option('show_on_front') == 'posts')){ ?>
				
				<tr valign="top">
					<th scope="row">Home Link</th>
					<td> 
						<fieldset>
							<legend class="hidden">Hide Home Link</legend>
							<label for="hide-home-link">
								<?php buildCheckbox('hide-home-link') ?>
								Hide Home Link
							</label>
						</fieldset>
					</td>
				</tr>
				
				
				
				
				<tr valign="top">
					<th scope="row"><label for="home-link-text">Home Link Text</label></th>
					<td><input type="text" class="regular-text" value="<?php echo (get_option('home-link-text')) ? stripslashes(get_option('home-link-text')) : 'Home' ?>" id="home-link-text" name="home-link-text"/>
					<span class="description">By default, Headway will show 'Home' in the navigation bar.  You can change what this says.</td>
				</tr>
				<? } ?>
			</tbody>
			</table>
			
			
			
			<? 
			$pages = explode('&page[]=', str_replace('navigation-control[]=input&page[]=', '', $_POST['navigation-page-order']));
			foreach($pages as $position => $page):
				update_post_meta($page, '_navigation_position', $position);
			endforeach;

			if($_POST['navigation-children']):
				foreach($_POST['navigation-children'] as $key => $child):
			
					$child = explode('&page[]=', str_replace('navigation-'.$key.'-children[]=input&page[]=', '', $child));
					
					foreach($child as $position => $page):
						update_post_meta($page, '_navigation_position', $position);
					endforeach;
			
				endforeach;
			endif;
			
			
			if($_POST['page-input']):
				foreach($_POST['page-input'] as $key => $value):
					update_post_meta($key, '_navigation_name', $value);
				endforeach;
			endif;
			?>
			
			<ul id="navigation-control">
				<?php 
					
					global $wpdb;
					

					
					$navigation_pages_query = "SELECT $wpdb->posts.* FROM $wpdb->posts INNER JOIN $wpdb->postmeta on $wpdb->posts.ID = $wpdb->postmeta.post_id WHERE $wpdb->posts.ID = $wpdb->postmeta.post_id AND $wpdb->posts.post_type = 'page' AND $wpdb->posts.post_status = 'publish' AND $wpdb->posts.post_parent = 0 AND $wpdb->postmeta.meta_key = '_navigation_position' AND $wpdb->posts.ID NOT IN (SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_show_navigation' AND meta_value='0') ORDER BY $wpdb->postmeta.meta_value ASC";

					$navigation_pages_query = $wpdb->get_results($navigation_pages_query, ARRAY_A);  //Gets all pages that have the navigation_position meta key set.

					$navigation_pages_query_no_meta = "SELECT $wpdb->posts.* FROM $wpdb->posts WHERE $wpdb->posts.post_type = 'page' AND $wpdb->posts.post_status = 'publish' AND $wpdb->posts.post_parent = 0 AND $wpdb->posts.ID NOT IN (SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_show_navigation' AND meta_value='0') AND $wpdb->posts.ID NOT IN (SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_navigation_position') ORDER BY $wpdb->posts.ID ASC";  //Gets all pages that DON'T have the navigation_position meta key set.

					$navigation_pages_query_no_meta = $wpdb->get_results($navigation_pages_query_no_meta, ARRAY_A);

					if($navigation_pages_query_no_meta && $navigation_pages_query) $navigation_pages_query = array_merge($navigation_pages_query_no_meta, $navigation_pages_query);
					if($navigation_pages_query_no_meta && !$navigation_pages_query) $navigation_pages_query = $navigation_pages_query_no_meta;

					

				
				
					$navigation_pages = '<input type="hidden" value="" name="navigation-page-order" id="navigation-control-input" />';
				

				    if ($navigation_pages_query):
					    foreach ($navigation_pages_query as $page):
					

						
							$children_pages_query[$page['ID']] = "SELECT $wpdb->posts.* FROM $wpdb->posts INNER JOIN $wpdb->postmeta on $wpdb->posts.ID = $wpdb->postmeta.post_id WHERE $wpdb->posts.ID = $wpdb->postmeta.post_id AND $wpdb->posts.post_type = 'page' AND $wpdb->posts.post_status = 'publish' AND $wpdb->posts.post_parent = $page[ID] AND $wpdb->postmeta.meta_key = '_navigation_position' AND $wpdb->posts.ID NOT IN (SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_show_navigation' AND meta_value='0') ORDER BY $wpdb->postmeta.meta_value ASC";
							
							
							
							
						    $children_pages_query[$page['ID']] = $wpdb->get_results($children_pages_query[$page['ID']], ARRAY_A);
						
						    $children_pages_query_no_meta[$page['ID']] = "SELECT $wpdb->posts.* FROM $wpdb->posts WHERE $wpdb->posts.post_type = 'page' AND $wpdb->posts.post_status = 'publish' AND $wpdb->posts.post_parent = $page[ID] AND $wpdb->posts.ID NOT IN (SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_show_navigation' AND meta_value='0') AND $wpdb->posts.ID NOT IN (SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_navigation_position') ORDER BY $wpdb->posts.ID ASC";
								
								
							$children_pages_query_no_meta[$page['ID']] = $wpdb->get_results($children_pages_query_no_meta[$page['ID']], ARRAY_A);
							
							if($children_pages_query_no_meta[$page['ID']] && $children_pages_query[$page['ID']]) $children_pages_query[$page['ID']] = array_merge($children_pages_query_no_meta[$page['ID']], $children_pages_query[$page['ID']]);
							if($children_pages_query_no_meta[$page['ID']] && !$children_pages_query[$page['ID']]) $children_pages_query[$page['ID']] = $children_pages_query_no_meta[$page['ID']];
													
						
							if ($children_pages_query[$page['ID']] && get_option('show-subpages')):
							
								$children_pages[$page['ID']] = '<ul id="navigation-'.$page['ID'].'-children" class="sub-pages">';
								$children_pages[$page['ID']] .= '<input type="hidden" value="" name="navigation-children['.$page['ID'].']" id="navigation-'.$page['ID'].'-children-input" />';
								
							    foreach ($children_pages_query[$page['ID']] as $child_page):
							
									$navigation_name = get_post_meta($child_page['ID'], '_navigation_name', true);
									$child_page['post_title'] = ($navigation_name) ? $navigation_name : $child_page['post_title'];
								
									$children_pages[$page['ID']] .= '<li id="page-'.$child_page['ID'].'" class="sortable"><input type="text" value="'.$child_page['post_title'].'" id="page-'.$child_page['ID'].'-input" name="page-input['.$child_page['ID'].']" /></li>';	
								
								endforeach;
								
								$children_pages[$page['ID']] .= '</ul>';
								
							endif;
								
						
							$navigation_name = get_post_meta($page['ID'], '_navigation_name', true);
							$page['post_title'] = ($navigation_name) ? $navigation_name : $page['post_title']; 
							
							$navigation_pages .= '
								<li id="page-'.$page['ID'].'" class="sortable-child">
									<input type="text" value="'.$page['post_title'].'" id="page-'.$page['ID'].'-input" name="page-input['.$page['ID'].']" />
									'.$children_pages[$page['ID']].'
								</li>
							';
						?>		
					    <?php 
						endforeach;
				    endif;
				
					echo $navigation_pages;
					?>
					
				

			</ul>
			
		</div>
		
		<div id="seo">
			<p class="notice"><b>Warning:</b> We recommend that if you do not know what a particular option does here, don't mess with it until you have familiarized yourself with this section by reading <a href="http://headwaythemes.com/documentation/search-engine-optimization/configuration/">Headway Search Engine Optimization &rsaquo; Configuration</a>.</p>
			
			<h3>Title</h3>
			
			<table class="form-table">
			<tbody>
				<tr>
					<th scope="row"><label for="title-home">Home Title</th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(get_option('title-home'))?>" id="title-home" name="title-home" /> 
					<span class="description"><br /><span class="available-variables">Available Variables:</span>
						<ul>
							<li><code>%blogname%</code> - <?php echo get_bloginfo('name')?></li>
							<li><code>%tagline%</code> - <?php echo get_bloginfo('description')?></li>
						</ul>
					</span></td>
				</tr>
				
				<? if(get_option('page_for_posts') != get_option('page_on_front')): ?>
				<tr>
					<th scope="row"><label for="title-posts-page">Posts Page Title</th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(get_option('title-posts-page'))?>" id="title-posts-page" name="title-posts-page" /> 
					<span class="description"><br /><span class="available-variables">Available Variables:</span>
						<ul>
							<li><code>%blogname%</code> - <?php echo get_bloginfo('name')?></li>
							<li><code>%tagline%</code> - <?php echo get_bloginfo('description')?></li>
						</ul>
					</span></td>
				</tr>				
				<? endif; ?>
				
				<tr>
					<th scope="row"><label for="title-page">Page Title</th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(get_option('title-page'))?>" id="title-page" name="title-page" />
						<span class="description"><br /><span class="available-variables">Available Variables:</span>
							<ul>
								<li><code>%page%</code> - Will return the title of the current page you are on.</li>
								<li><code>%blogname%</code> - <?php echo get_bloginfo('name')?></li>
								<li><code>%tagline%</code> - <?php echo get_bloginfo('description')?></li>
							</ul>
						</span></td>
				</tr>
				
				
				
				
				
				<tr>
					<th scope="row"><label for="title-single">Single Post Title</th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(get_option('title-single'))?>" id="title-single" name="title-single" />
						<span class="description"><br /><span class="available-variables">Available Variables:</span>
							<ul>
								<li><code>%postname%</code> - Will return the name of the current post you are viewing.</li>
								<li><code>%blogname%</code> - <?php echo get_bloginfo('name')?></li>
								<li><code>%tagline%</code> - <?php echo get_bloginfo('description')?></li>
							</ul>
						</span></td>
				</tr>
				
				
				
				<tr>
					<th scope="row"><label for="title-404">404 Title</th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(get_option('title-404'))?>" id="title-404" name="title-404" />
						<span class="description"><br /><span class="available-variables">Available Variables:</span>
							<ul>
								<li><code>%blogname%</code> - <?php echo get_bloginfo('name')?></li>
								<li><code>%tagline%</code> - <?php echo get_bloginfo('description')?></li>
							</ul>
						</span></td>
				</tr>
				
				<tr>
					<th scope="row"><label for="title-category">Category Title</th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(get_option('title-category'))?>" id="title-category" name="title-category" />
						<span class="description"><br /><span class="available-variables">Available Variables:</span>
							<ul>
								<li><code>%category%</code> - Will return the current category archive you are viewing.</li>
								<li><code>%category_description%</code> - Will return the description of the category that is being viewed.  You can define a category's description in the <a href="<? bloginfo('url') ?>/wp-admin/categories.php" target="_blank">Posts &rsaquo; Categories</a> page.</li>								
								<li><code>%blogname%</code> - <?php echo get_bloginfo('name')?></li>
								<li><code>%tagline%</code> - <?php echo get_bloginfo('description')?></li>
							</ul>
						</span></td>
				</tr>
				
				<tr>
					<th scope="row"><label for="title-tag">Tag Title</th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(get_option('title-tag'))?>" id="title-tag" name="title-tag" />
						<span class="description"><br /><span class="available-variables">Available Variables:</span>
							<ul>
								<li><code>%tag%</code> - Will return the current tag you are viewing.</li>
								<li><code>%blogname%</code> - <?php echo get_bloginfo('name')?></li>
								<li><code>%tagline%</code> - <?php echo get_bloginfo('description')?></li>
							</ul>
						</span></td>
				</tr>
				
				<tr>
					<th scope="row"><label for="title-archives">Archives Title</th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(get_option('title-archives'))?>" id="title-archives" name="title-archives" />
						<span class="description"><br /><span class="available-variables">Available Variables:</span>
							<ul>
								<li><code>%archive%</code> - Will return the current archive you are viewing.  For example, <?php echo date('F Y')?>.</li>
								<li><code>%blogname%</code> - <?php echo get_bloginfo('name')?></li>
								<li><code>%tagline%</code> - <?php echo get_bloginfo('description')?></li>
							</ul>
						</span></td>
				</tr>
				
				<tr>
					<th scope="row"><label for="title-search">Search Title</th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(get_option('title-search'))?>" id="title-search" name="title-search" />
						<span class="description"><br /><span class="available-variables">Available Variables:</span>
							<ul>
								<li><code>%search%</code> - Will return the search query.  For example, when someone searches for 'WordPress', the <code>%search%</code> variable would be WordPress.</li>
								<li><code>%blogname%</code> - <?php echo get_bloginfo('name')?></li>
								<li><code>%tagline%</code> - <?php echo get_bloginfo('description')?></li>
							</ul>
						</span></td>
				</tr>
				
				
				
				
				
				
				<tr>
					<th scope="row"><label for="title-author-archives">Author Archives Title</th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(get_option('title-author-archives'))?>" id="title-author-archives" name="title-author-archives" />
						<span class="description"><br /><span class="available-variables">Available Variables:</span>
							<ul>
								<li><code>%blogname%</code> - <?php echo get_bloginfo('name')?></li>
								<li><code>%author_name%</code> - Will return the author's "nicename".  This is set in the users panel of WordPress.</li>
								<li><code>%author_description%</code> - This will return the author's description.  This is changed inthe users panel in WordPress by editing the Bio box.</li>
							</ul>
						</span></td>
				</tr>
				
				

					
				
			</tbody>
			</table>
			
			<h3 class="border-top"><code>META</code> Content</h3>
			
			<table class="form-table">
			<tbody>
			
				<tr valign="top">
					<th scope="row"><label for="home-description">Home Description</label></th>
					<td><textarea rows="5" cols="45" class="regular-text" id="" name="home-description"><?php echo stripslashes(get_option('home-description'))?></textarea>
					<span class="description">This will be the META description for the homepage.  The META description is what shows up underneath your website name in Google.  If this is left blank then it will default to no description.</span></td>
				</tr>
			
				<tr valign="top">
					<th scope="row"><label for="home-keywords">Home Keywords</label></th>
					<td><textarea rows="5" cols="45" class="regular-text" id="" name="home-keywords"><?php echo stripslashes(get_option('home-keywords'))?></textarea>
					<span class="description">Place relevant words about your website in here separated by commas.  Be sure to not overload this, try to keep it below 10-15 keywords.</span></td>
				</tr>
				
				
				<tr valign="top">
					<th scope="row">Treat Categories as META Keywords</th>
					<td> 
						<fieldset>
							<legend class="hidden">Treat Categories as META Keywords</legend>
							<label for="categories-meta">
								<?php buildCheckbox('categories-meta') ?>
								Treat Categories as META Keywords
							</label>
						</fieldset>
					<span class="description">If this is enabled the categories of a specific post will be appended to the <code>META</code> keywords of a post.  You can add keywords to a post in the write panel under the Search Engine Optimization box.</span></td>
				</tr>



				<tr valign="top">
					<th scope="row">Treat Tags as META Keywords</th>
					<td> 
						<fieldset>
							<legend class="hidden">Treat Tags as META Keywords</legend>
							<label for="tags-meta">
								<?php buildCheckbox('tags-meta') ?>
								Treat Tags as META Keywords
							</label>
						</fieldset>
					<span class="description">If this is enabled the tags of a specific post will be appended to the <code>META</code> keywords of a post.  You can add keywords to a post in the write panel under the Search Engine Optimization box.</span></td>
				</tr>
				

				
				
				<tr valign="top">
					<th scope="row">Canonical URLs</th>
					<td> 
						<fieldset>
							<legend class="hidden">Canonical URLs</legend>
							<label for="canonical">
								<?php buildCheckbox('canonical') ?>
								Enable Canonical URLs
							</label>
						</fieldset>
					<span class="description">Canonical URLs tell search engines how to treat duplicate content, which increases your rating.  When search engines detect duplicate content they will not know which to index therefore hurting you.  Canonical URLs will fix this.</span></td>
				</tr>
				
				
			
			</tbody>
			</table>
			
			
			
			<h3 class="border-top"><code>nofollow</code> Configuration</h3>
			
			<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row">Comment Authors' URL</th>
					<td> 
						<fieldset>
							<legend class="hidden">Add nofollow To Comment Authors' URLs</legend>
							<label for="nofollow-comment-author">
								<?php buildCheckbox('nofollow-comment-author') ?>
								Add nofollow To Comment Authors' URL
							</label>
						</fieldset>
					<span class="description">Adding <code>nofollow</code> to the comment authors' URLs will tell search engines to not visit there website and to stay on yours.  Many bloggers frown upon this, which can sometimes discourage comments.  Only enable this if you are 100% sure you know you want to.</span></td>
				</tr>
			
				<tr valign="top">
					<th scope="row">Home Page Link</th>
					<td> 
						<fieldset>
							<legend class="hidden">Add nofollow To Home Page Link</legend>
							<label for="nofollow-home">
								<?php buildCheckbox('nofollow-home') ?>
								Add nofollow To Home Page Link
							</label>
						</fieldset>
					<span class="description">Adding <code>nofollow</code> to the home page links will keep search engine bots from winding themselves up in a circle.  This will help them get to every nook and cranny in your website.</span></td>
				</tr>
				
				<p>If you need to add <code>nofollow</code> to any other page, there is an option in the Search Engine Optimization box on the write page.</p>
			</tbody>
			</table>
			
			
			<h3 class="border-top"><code>noindex</code> Configuration</h3>
			
			<table class="form-table">
			<tbody>
				
				<p>We recommend that you add <code>noindex</code> to the following.  Doing so will help avoid duplicate indexing, thus helping your SEO.  This will keep the posts in focus for the search engine instead of indexing all the category archives, chronological archives, and tags archives.</p>
				
				<tr valign="top">
					<th scope="row">Category Archives</th>
					<td> 
						<fieldset>
							<legend class="hidden">Add noindex To Category Archives</legend>
							<label for="noindex-category-archives">
								<?php buildCheckbox('noindex-category-archives') ?>
								Add noindex To Category Archives
							</label>
						</fieldset>
					</td>
				</tr>
				
				
				
				<tr valign="top">
					<th scope="row">Archives</th>
					<td> 
						<fieldset>
							<legend class="hidden">Add noindex To Archives</legend>
							<label for="noindex-archives">
								<?php buildCheckbox('noindex-archives') ?>
								Add noindex To Archives
							</label>
						</fieldset>
					</td>
				</tr>
				
				
				
				
				
				<tr valign="top">
					<th scope="row">Tag Archives</th>
					<td> 
						<fieldset>
							<legend class="hidden">Add noindex Tag Archives</legend>
							<label for="noindex-tag-archives">
								<?php buildCheckbox('noindex-tag-archives') ?>
								Add noindex To Tag Archives
							</label>
						</fieldset>
					</td>
				</tr>
				
				
				
				
				<tr valign="top">
					<th scope="row">Author Archives</th>
					<td> 
						<fieldset>
							<legend class="hidden">Add noindex To Author Archives</legend>
							<label for="noindex-author-archives">
								<?php buildCheckbox('noindex-author-archives') ?>
								Add noindex To Author Archives
							</label>
						</fieldset>
					</td>
				</tr>
		
		
				<p>Much like <code>nofollow</code>, you have the option to enable <code>noindex</code> in the Search Engine Optimization box on the write panel for all pages and posts.</p>
		
		
		
		
			</tbody>
			</table>
			
			
			
			
		</div>
		
		<div id="social-networking">
			<h3>Twitter</h3>
			<p>Headway can automatically publish a Tweet when you write a new post.  Don't worry, your information will not be sent to anyone but Twitter.</p>
			<table class="form-table">
			<tbody>
				<tr>
					<th scope="row"><label for="twitter-username">Twitter Username</th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(get_option('twitter-username')) ?>" id="twitter-username" name="twitter-username" />
					</td>
				</tr>


				<tr>
					<th scope="row"><label for="twitter-password">Twitter Password</th>
					<td><input type="password" class="regular-text" value="<?php echo stripslashes(get_option('twitter-password')) ?>" id="twitter-password" name="twitter-password"/>
					</td>
				</tr>
				
				
				<tr>
					<th scope="row"><label for="tweet-format">Tweet Format</label></th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(get_option('tweet-format'))?>" id="tweet-format" name="tweet-format" /> &nbsp; Available variables: <code>%postname%</code> <code>%category%</code> <code>%blogname%</code> <code>%url%</code><br />
					<span class="description">This is how Headway will send the Tweet to Twitter (gotta love the Twitter terminology).  Use the variables listed to get the desired look.</span></td>
				</tr>
				
				
				
				
				<tr valign="top">
					<th scope="row">Post to Twitter by Default</th>
					<td> 
						<fieldset>
							<legend class="hidden">Post to Twitter by Default</legend>
							<label for="headway-post-to-twitter">
								<?php buildCheckbox('headway-post-to-twitter') ?>
								Post to Twitter by Default
							</label>
						</fieldset>
					</td>
				</tr>
				
				
			</tbody>
			</table>	
		

			</div>	
			
			
			
			
			
			
			
			
			
			

		</div>
		
		
	</div>

	<p class="submit">
	<input type="submit" value="Save Changes" class="button-primary" name="Submit"/>
	</p>
</form>