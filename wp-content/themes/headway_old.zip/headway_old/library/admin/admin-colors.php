<?php
global $scheme;

$scheme['default'] = array(	
	'background' 							=> 'ffffff', 
	'default-hyperlink' 					=> '444444', 
			
	'wrapper-border' 						=> 'ffffff',
				
	'header-background' 					=> 'ffffff',
	'header-link'							=> '336699', 
	'header-link-underline'					=> 'ffffff', 	
	'header-tagline'						=> 'aaaaaa', 
	'header-bottom-border'					=> 'eeeeee',

	'navigation-background'					=> 'ffffff',
	'navigation-link-color'					=> '555555',
	'navigation-link-color-active'			=> '336699',
	'navigation-link-background-active'		=> 'ffffff',
	'navigation-link-border'				=> 'eeeeee',
	'navigation-bottom-border'				=> 'eeeeee',
				
	'breadcrumbs-background'				=> 'ffffff',
	'breadcrumbs-bottom-border'				=> 'eeeeee',
	'breadcrumbs-color'						=> '666666',
	'breadcrumbs-hyperlink-color'			=> '336699',
	
			
	'post-title'							=> '336699', 
	'post-title-hover'						=> '5b8dbf', 
	'post-content'							=> '444444', 
	'post-hyperlink'						=> '336699',
	'post-meta'								=> '888888', 
	'post-meta-hyperlink'					=> '888888', 
	'post-content-h2'						=> '666666',
	'post-content-h3'						=> '666666',
	'post-content-h4'						=> '336699',
	'post-bottom-border'					=> 'eeeeee',
	
	'leaf-title'							=> '555555', 
	'leaf-title-hyperlink'	 				=> '555555', 
	'leaf-title-underline'	 				=> '555555', 
	'leaf-content'	 						=> '333333', 
		
	'sidebar-bg'							=> 'ffffff',
	'widget-title'							=> '999999', 		
	'sidebar-hyperlinks'					=> '555555',
	
	'footer-text'							=> '444444',
	'footer-hyperlinks'						=> '444444',
	'footer-bg'								=> 'ffffff',
	'footer-top-border'						=> 'dddddd');




$scheme['grey'] = array(	
	'background' 							=> '414141', 
	'default-hyperlink' 					=> '444444', 
			                                    
	'wrapper-border' 						=> '222222',
				                                
	'header-background' 					=> 'ffffff',
	'header-link'							=> '444444', 
	'header-link-underline'					=> 'd9d9d9', 	
	'header-tagline'						=> '888888', 
	'header-bottom-border'					=> 'cccccc',
                                                
	'navigation-background'					=> 'ffffff',
	'navigation-link-color'					=> '555555',
	'navigation-link-color-active'			=> '555555',
	'navigation-link-background-active'		=> 'eeeeee',
	'navigation-link-border'				=> 'cccccc',
	'navigation-bottom-border'				=> 'cccccc',
				                                
	'breadcrumbs-background'				=> 'ffffff',
	'breadcrumbs-bottom-border'				=> 'cccccc',
	'breadcrumbs-color'						=> '666666',
	'breadcrumbs-hyperlink-color'			=> '555555',
	                                            
			                                    
	'post-title'							=> '555555', 
	'post-title-hover'						=> '333333', 
	'post-content'							=> '444444', 
	'post-hyperlink'						=> '555555',
	'post-meta'								=> '888888', 
	'post-meta-hyperlink'					=> '888888', 
	'post-content-h2'						=> '666666',
	'post-content-h3'						=> '666666',
	'post-content-h4'						=> '444444',
	'post-bottom-border'					=> 'dddddd',
	                                            
	'leaf-title'							=> '333333', 
	'leaf-title-hyperlink'	 				=> '333333', 
	'leaf-title-underline'	 				=> '333333', 
	'leaf-content'	 						=> '333333', 
		                 
	'sidebar-bg'							=> 'ffffff',                       
	'widget-title'							=> '999999', 		
	'sidebar-hyperlinks'					=> '555555',
                                                
	'footer-text'							=> '444444',
	'footer-hyperlinks'						=> '444444',
	'footer-bg'								=> 'ffffff',
	'footer-top-border'						=> 'dddddd');
	
	
	
	
	
	
	
$scheme['red'] = array(	
	'background' 							=> 'ffffff', 
	'default-hyperlink' 					=> '444444', 
			                                    
	'wrapper-border' 						=> 'ffffff',
				                                
	'header-background' 					=> 'ffffff',
	'header-link'							=> 'cc0000', 
	'header-link-underline'					=> 'eeeeee', 	
	'header-tagline'						=> 'bbbbbb', 
	'header-bottom-border'					=> 'dddddd',
                                                
	'navigation-background'					=> 'ffffff',
	'navigation-link-color'					=> '555555',
	'navigation-link-color-active'			=> 'ffffff',
	'navigation-link-background-active'		=> 'cc0000',
	'navigation-link-border'				=> 'dddddd',
	'navigation-bottom-border'				=> 'dddddd',
				                                
	'breadcrumbs-background'				=> 'ffffff',
	'breadcrumbs-bottom-border'				=> 'dddddd',
	'breadcrumbs-color'						=> '666666',
	'breadcrumbs-hyperlink-color'			=> 'cc0000',
	                                            
			                                    
	'post-title'							=> '555555', 
	'post-title-hover'						=> 'cc0000', 
	'post-content'							=> '444444', 
	'post-hyperlink'						=> 'cc0000',
	'post-meta'								=> '888888', 
	'post-meta-hyperlink'					=> '888888', 
	'post-content-h2'						=> '666666',
	'post-content-h3'						=> '666666',
	'post-content-h4'						=> 'cc0000',
	'post-bottom-border'					=> 'dddddd',
	                                            
	'leaf-title'							=> '333333', 
	'leaf-title-hyperlink'	 				=> '333333', 
	'leaf-title-underline'	 				=> '333333', 
	'leaf-content'	 						=> '333333', 
		                                        
	'sidebar-bg'							=> 'ffffff',
	'widget-title'							=> '999999', 		
	'sidebar-hyperlinks'					=> '555555',
	
	'footer-text'							=> '444444',
	'footer-hyperlinks'						=> '444444',
	'footer-bg'								=> 'ffffff',
	'footer-top-border'						=> 'dddddd');
	
	
	
$scheme['grey-tabs'] = array(	
	'background' 							=> '414141', 
	'default-hyperlink' 					=> '444444', 
			                                    
	'wrapper-border' 						=> 'none',
				                                
	'header-background' 					=> '414141',
	'header-link'							=> 'ffffff', 
	'header-link-underline'					=> 'none', 	
	'header-tagline'						=> '969696', 
	'header-bottom-border'					=> 'none',
                                                
	'navigation-background'					=> '414141',
	'navigation-link-color'					=> 'ffffff',
	'navigation-link-color-active'			=> '414141',
	'navigation-link-background-active'		=> 'ffffff',
	'navigation-link-border'				=> 'none',
	'navigation-bottom-border'				=> 'ffffff',
				                                
	'breadcrumbs-background'				=> 'ffffff',
	'breadcrumbs-bottom-border'				=> 'eeeeee',
	'breadcrumbs-color'						=> '666666',
	'breadcrumbs-hyperlink-color'			=> '339933',
	                                            
			                                    
	'post-title'							=> '555555', 
	'post-title-hover'						=> '414141', 
	'post-content'							=> '444444', 
	'post-hyperlink'						=> '339933',
	'post-meta'								=> '888888', 
	'post-meta-hyperlink'					=> '888888', 
	'post-content-h2'						=> '666666',
	'post-content-h3'						=> '666666',
	'post-content-h4'						=> '339933',
	'post-bottom-border'					=> 'dddddd',
	                                            
	'leaf-title'							=> '333333', 
	'leaf-title-hyperlink'	 				=> '333333', 
	'leaf-title-underline'	 				=> '333333', 
	'leaf-content'	 						=> '333333', 
		                                     
	'sidebar-bg'							=> 'ffffff',   
	'widget-title'							=> '999999', 		
	'sidebar-hyperlinks'					=> '555555',
                                                
	'footer-text'							=> '444444',
	'footer-hyperlinks'						=> '444444',
	'footer-bg'								=> 'ffffff',
	'footer-top-border'						=> 'dddddd');
		
	
$scheme['green-tabs'] = array(	
	'background' 							=> '339933', 
	'default-hyperlink' 					=> '444444', 
			                                    
	'wrapper-border' 						=> 'none',
				                                
	'header-background' 					=> '339933',
	'header-link'							=> 'ffffff', 
	'header-link-underline'					=> 'none', 	
	'header-tagline'						=> 'eeeeee', 
	'header-bottom-border'					=> 'none',
                                                
	'navigation-background'					=> '339933',
	'navigation-link-color'					=> 'ffffff',
	'navigation-link-color-active'			=> '339933',
	'navigation-link-background-active'		=> 'ffffff',
	'navigation-link-border'				=> 'none',
	'navigation-bottom-border'				=> 'ffffff',
				                                
	'breadcrumbs-background'				=> 'ffffff',
	'breadcrumbs-bottom-border'				=> 'eeeeee',
	'breadcrumbs-color'						=> '666666',
	'breadcrumbs-hyperlink-color'			=> '339933',
	                                            
			                                    
	'post-title'							=> '555555', 
	'post-title-hover'						=> '339933', 
	'post-content'							=> '444444', 
	'post-hyperlink'						=> '339933',
	'post-meta'								=> '888888', 
	'post-meta-hyperlink'					=> '888888', 
	'post-content-h2'						=> '666666',
	'post-content-h3'						=> '666666',
	'post-content-h4'						=> '339933',
	'post-bottom-border'					=> 'dddddd',
	                                            
	'leaf-title'							=> '333333', 
	'leaf-title-hyperlink'	 				=> '333333', 
	'leaf-title-underline'	 				=> '333333', 
	'leaf-content'	 						=> '333333', 
		                                     
	'sidebar-bg'							=> 'ffffff',   
	'widget-title'							=> '999999', 		
	'sidebar-hyperlinks'					=> '555555',
                                                
	'footer-text'							=> '444444',
	'footer-hyperlinks'						=> '444444',
	'footer-bg'								=> 'ffffff',
	'footer-top-border'						=> 'dddddd');
	
	
	
	
	



foreach($scheme as $colors){
	$scheme_check[] = md5(implode('', array_values($colors)));
}