<?php
require 'admin-write.php';


function headway_inject_css(){
	echo '<link rel="stylesheet" href="'.get_bloginfo('template_directory').'/library/admin/css/admin-all.css" type="text/css" media="all" />'."\n";
}
add_action('admin_print_scripts', 'headway_inject_css');



add_action('admin_menu', 'headway_add_menus');
function headway_add_menus() {
	$configuration_page = add_theme_page( 'Headway Configuration', 'Headway Configuration', 10, 'headway-configuration', 'headway_configuration');
	$design_page = add_theme_page( 'Headway Design', 'Headway Design', 10, 'headway-design', 'headway_design');
	$layout_page = add_theme_page( 'Headway Layout Editor', 'Headway Layout Editor', 10, 'headway-layout', 'headway_layout');
	$hooks_page = add_theme_page( 'Headway Easy Hooks', 'Headway Easy Hooks', 10, 'headway-easy-hooks', 'headway_easy_hooks');

	
	
	add_action( "admin_print_scripts-$layout_page", 'headway_layout_head' );
	add_action( "admin_print_scripts-$configuration_page", 'headway_configuration_head' );
	add_action( "admin_print_scripts-$design_page", 'headway_design_head' );
	add_action( "admin_print_scripts-$hooks_page", 'headway_easy_hooks_head' );
}

function headway_configuration_head(){
	echo '<link rel="stylesheet" href="'.get_bloginfo('template_directory').'/library/admin/css/admin-configuration.css" type="text/css" media="all" />'."\n";
	
	wp_enqueue_script('headway_jquery', get_bloginfo('template_directory').'/media/js/jquery.js');
	wp_enqueue_script('headway_jquery_ui', get_bloginfo('template_directory').'/library/admin/js/jquery.ui.js');
	wp_enqueue_script('headway_admin', get_bloginfo('template_directory').'/library/admin/js/admin-configuration.js');
}


function headway_design_head(){	
	echo '<link rel="stylesheet" href="'.get_bloginfo('template_directory').'/library/admin/css/admin-configuration.css" type="text/css" media="all" />'."\n";
	echo '<link rel="stylesheet" href="'.get_bloginfo('template_directory').'/library/admin/css/colorpicker.css" type="text/css" media="all" />'."\n";

	
	
	wp_enqueue_script('headway_jquery', get_bloginfo('template_directory').'/media/js/jquery.js');
	wp_enqueue_script('headway_jquery_ui', get_bloginfo('template_directory').'/library/admin/js/jquery.ui.js');
	wp_enqueue_script('headway_admin', get_bloginfo('template_directory').'/library/admin/js/admin-configuration.js');
	wp_enqueue_script('headway_colorpicker_include', get_bloginfo('template_directory').'/library/admin/js/colorpicker-include.js');
	wp_enqueue_script('headway_colorpicker', get_bloginfo('template_directory').'/library/admin/js/colorpicker.js');	
}


function headway_layout_head(){
	echo '<link rel="stylesheet" href="'.get_bloginfo('template_directory').'/library/admin/css/admin-layout.css" type="text/css" media="all" />'."\n";
		
	wp_enqueue_script('headway_functions', get_bloginfo('template_directory').'/library/admin/js/admin-layout-functions.js');
	wp_enqueue_script('headway_jquery', get_bloginfo('template_directory').'/media/js/jquery.js');
	wp_enqueue_script('headway_jquery_ui', get_bloginfo('template_directory').'/library/admin/js/jquery.ui.js');
	wp_enqueue_script('headway_jquery_json', get_bloginfo('template_directory').'/library/admin/js/jquery.json.js');
	wp_enqueue_script('headway_admin', get_bloginfo('template_directory').'/library/admin/js/admin-layout.php');
?>
	<script type="text/javascript">
		var count = <?php echo (get_post_meta(3, '_leaf_count', true))?get_post_meta(3, '_leaf_count', true):'0'; ?>;
		<?php
			$page_select_options = '<option value=""></option>';
			$page_select_query = get_pages();
			foreach($page_select_query as $page){ 
				$page_select_options .= '<option value="'.$page->ID.'">'.addslashes($page->post_title).'</option>';
			}
			
			$categories_select_query = get_categories();
			
			foreach($categories_select_query as $category){ 
				$category_select_options .= '<option value="'.$category->term_id.'">'.addslashes($category->name).'</option>';

			}
		?>
		var about_pages = '<?php echo $page_select_options?>';
		var categories_select = '<?php echo $category_select_options?>';
	</script>
<?php
}

function headway_easy_hooks_head(){
	echo '<link rel="stylesheet" href="'.get_bloginfo('template_directory').'/library/admin/css/admin-configuration.css" type="text/css" media="all" />'."\n";
}



function headway_admin_header(){
	echo '<div id="wrapper" class="wrap">';
	echo '<div id="headway-admin-top">
			<a href="http://www.headwaythemes.com/documentation">Headway Documentation</a>
			<a href="http://www.headwaythemes.com/members/forums">Headway Support Forums</a>
			<a href="http://www.headwaythemes.com/documentation/faqs">Headway FAQs</a>
			<a href="http://www.wicked-wordpress-themes.com">More Wordpress Themes</a>
		 </div>';
}

function headway_admin_footer(){
	echo '</div> <!-- #wrapper -->';
}




function headway_configuration(){
	headway_admin_header();
		include 'admin-configuration.php';	
	headway_admin_footer();
}

function headway_design(){
	headway_admin_header();
		include 'admin-design.php';	
	headway_admin_footer();
}

function headway_layout(){
	headway_admin_header();
		include 'admin-layout.php';
	headway_admin_footer();
}

function headway_easy_hooks(){
	headway_admin_header();
		include 'admin-easy-hooks.php';
	headway_admin_footer();
}