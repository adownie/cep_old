<h2>Headway Layout Editor</h2>

<? if(!is_ie()){ ?>
	<?php
	if($_POST['layout-page']):
		if($_POST['layout-change-submit'] || $_POST['layout-change-submit-copy-go']){
			$order = ($order != 'item[]=') ? explode('&item[]=', substr($_POST['order'], 7)) : NULL;
			$config = $_POST['config'];
			$delete = $_POST['delete'];
		
				
			if($order[0] != NULL):
				foreach ($order as $item) : 
				  $array[] = "item_$item";
				endforeach; 
			endif;
		
			if($delete):
				foreach ($delete as $delete_item => $true):
					delete_post_meta($_POST['layout-page'], '_'.$delete_item);	
					delete_post_meta($_POST['layout-page'], '_'.$delete_item.'_options');	
					if(get_post_meta($_POST['layout-page'], '_'.$delete_item.'_text')) delete_post_meta($_POST['layout-page'], '_'.$delete_item.'_text');					
				endforeach;
			endif;
		
		
			if($order[0] != NULL):
				$leaf_count = count($array);
			else:
				$leaf_count = 0;
				$array = '';
			endif;
		
		
			if($_POST['order'] != 'item[]=' && $_POST['order'] != 'item[]=Array'):  //Funky bug requires this to be here.
				update_post_meta($_POST['layout-page'], '_leafs', $array);
				update_post_meta($_POST['layout-page'], '_leaf_count', $leaf_count);
			endif;
		
			if($order[0] != NULL):
				
				$sidebar_present = false;
				
				if($config):
				foreach ($config as $item => $config):			
					$config = explode(' | ', $config);
			
					$item_config = get_post_meta($_POST['layout-page'], '_'.$item, true);
			
		
					$item_config[0] = $config[0];
					$item_config[1] = $config[1];
					$item_config[2] = $config[2];
					$item_config[3] = $config[3];
					$item_config[4] = $config[4];
					$item_config[5] = $config[5];
						
			
					update_post_meta($_POST['layout-page'], '_'.$item, $item_config);
					
					
					if($item_config[0] == 'sidebar'):
						
						$sidebar_present = true;
						
						$headway_sidebars = get_option('headway_sidebars');
						
						if($headway_sidebars){
							if(!in_array($_POST['layout-page'], $headway_sidebars)){  array_push($headway_sidebars, $_POST['layout-page']); }
						} else {
							$headway_sidebars = array($_POST['layout-page']);
						}
						
						update_option('headway_sidebars', $headway_sidebars);
						
						
					endif;
					
					
					
					
					
				endforeach;
				endif;
				
				
				
				if($sidebar_present === false){
					$headway_sidebars = get_option('headway_sidebars');
					if($headway_sidebars):
						$headway_sidebars = array_diff($headway_sidebars, array($_POST['layout-page']));
						update_option('headway_sidebars', $headway_sidebars);
					endif;
				}
								
				
				
				
			endif;
		
		
			if($_POST['options']){
				foreach($_POST['options'] as $option => $options):
					
					$options = leaf_to_db($options);				
						
					update_post_meta($_POST['layout-page'], '_'.$option.'_options', $options);
				endforeach;
			}
			
			if($_POST['text']){
				foreach($_POST['text'] as $id => $text):						
					update_post_meta($_POST['layout-page'], '_'.$id.'_text', $text);
				endforeach;
			}
			
			if($_POST['copy-pages'] && $_POST['layout-change-submit-copy-go']){
				foreach($_POST['copy-pages'] as $copy_id){
					update_post_meta($copy_id, '_leaf_template', $_POST['layout-page']);
				}
			}
			if($_POST['page-leaf-template']){
				update_post_meta($_POST['layout-page'], '_leaf_template', $_POST['page-leaf-template']);
			}
			elseif(!$_POST['page-leaf-template']){
				delete_post_meta($_POST['layout-page'], '_leaf_template');
			}
		
		
			$wrapper_width = get_option('wrapper-width')-40;
			echo '<div class="success" style="width:'.$wrapper_width.'px"><span>Layout Updated!</span> <a href="'.get_bloginfo('url').'">View Site &raquo;</a></div>';
		}
	endif;
	
	
	if($_POST['layout-system-page']):
		if($_POST['layout-change-submit']){
			$order = explode('&item[]=', substr($_POST['order'], 7));
			$config = $_POST['config'];
			$delete = $_POST['delete'];
		
				
			if($order[0] != NULL):
				foreach ($order as $item) : 
				  $array[] = "item_$item";
				endforeach; 
			endif;
		
			if($delete):
				foreach ($delete as $delete_item => $true):
					delete_option('system-page-'.$_POST['layout-system-page'].'-'.$delete_item);
					delete_option('system-page-'.$_POST['layout-system-page'].'-'.$delete_item.'_options');	
					if(get_option('system-page-'.$_POST['layout-system-page'].'-'.$delete_item.'_text')) delete_post_meta('system-page-'.$_POST['layout-system-page'].'-'.$delete_item.'_text');					
				endforeach;
			endif;
		
		
			if($order[0] != NULL):
				$leaf_count = count($array);
			else:
				$leaf_count = 0;
				$array = '';
			endif;
		
		
			if($_POST['order'] != 'item[]=' && $_POST['order'] != 'item[]=Array'):  //Funky bug requires this to be here.
				update_option('system-page-'.$_POST['layout-system-page'].'-leafs', $array);
				update_option('system-page-'.$_POST['layout-system-page'].'-leaf_count', $leaf_count);
			endif;
		 
			if($order[0] != NULL):
				
				$sidebar_present = false;
				
				if($config):
				foreach ($config as $item => $config):			
					$config = explode(' | ', $config);
			
					$item_config = get_option('system-page-'.$_POST['layout-system-page'].'-'.$item);
			
		
					$item_config[0] = $config[0];
					$item_config[1] = $config[1];
					$item_config[2] = $config[2];
					$item_config[3] = $config[3];
					$item_config[4] = $config[4];
					$item_config[5] = $config[5];
		
						
			
					update_option('system-page-'.$_POST['layout-system-page'].'-'.$item, $item_config);
					
					
					if($item_config[0] == 'sidebar'):
						
						$sidebar_present = true;
						
						$headway_sidebars_system = get_option('headway_sidebars_system');
						
						if($headway_sidebars_system){
							if(!in_array($_POST['layout-system-page'], $headway_sidebars_system)){  array_push($headway_sidebars_system, $_POST['layout-system-page']); }
						} else {
							$headway_sidebars_system = array($_POST['layout-system-page']);
						}
						
						update_option('headway_sidebars_system', $headway_sidebars_system);
						
						
					endif;
					
					
				endforeach;
				endif;
				
				
				
				if($sidebar_present === false){
					$headway_sidebars_system = get_option('headway_sidebars_system');
					if($headway_sidebars_system):
						$headway_sidebars_system = array_diff($headway_sidebars_system, array($_POST['layout-system-page']));
					
						update_option('headway_sidebars_system', $headway_sidebars_system);
					endif;
				}
								
				
				
				
			endif;
		
		
			if($_POST['options']){
				foreach($_POST['options'] as $option => $options):
					
					$options = leaf_to_db($options);				
						
					update_option('system-page-'.$_POST['layout-system-page'].'-'.$option.'_options', $options);
				endforeach;
			}

			if($_POST['text']){
				foreach($_POST['text'] as $id => $text):						
					update_option('system-page-'.$_POST['layout-system-page'].'-'.$id.'_text', $text);
				endforeach;
			}
		
		
			$wrapper_width = get_option('wrapper-width')-40;
			echo '<div class="success" style="width:'.$wrapper_width.'px"><span>Layout Updated!</span> <a href="'.get_bloginfo('url').'">View Site &raquo;</a></div>';
		}
	endif;
	?>
	



	<div class="layout-nav" style="width:<?php echo get_option('wrapper-width')?>px">
		<div id="layout-nav-form">
			<form method="post">
				<?php wp_dropdown_pages(array('exclude_tree' => $post->ID, 'selected' => $_POST['layout-page'] , 'name' => 'layout-page', 'show_option_none' => __('-Pages-'), 'sort_column'=> 'menu_order, post_title')); ?>
				<input type="submit" class="button-secondary" value="Show Page Layout"/>
			</form>
			
			
			
			<form method="post">
				<select id="show-system-page" name="layout-system-page" style="width: 150px;">
					<option value="">-System Pages-</option>
					<option value="index"<?php if($_POST['layout-system-page'] == 'index') echo ' selected="selected"'; ?>>Blog Index</option>
					<option value="single"<?php if($_POST['layout-system-page'] == 'single') echo ' selected="selected"'; ?>>Single Post</option>
					<option value="category"<?php if($_POST['layout-system-page'] == 'category') echo ' selected="selected"'; ?>>Category Archive</option>
					<option value="archives"<?php if($_POST['layout-system-page'] == 'archives') echo ' selected="selected"'; ?>>Archives</option>
					<option value="tag"<?php if($_POST['layout-system-page'] == 'tag') echo ' selected="selected"'; ?>>Tag Archive</option>
					<option value="author"<?php if($_POST['layout-system-page'] == 'author') echo ' selected="selected"'; ?>>Author Archive</option>
					<option value="search"<?php if($_POST['layout-system-page'] == 'search') echo ' selected="selected"'; ?>>Search</option>
					<option value="four04"<?php if($_POST['layout-system-page'] == 'four04') echo ' selected="selected"'; ?>>404 Page</option>
				</select>
		
		
				<input type="submit" class="button-secondary" value="Show System Page Layout"/>
			</form>

		
		

		</div>
		
		<?php if($_POST['layout-page'] || $_POST['layout-system-page'] ): ?>
			
		<?php if($_POST['layout-page']){ ?>
		<h4 id="layout-heading">Editing Page: <strong><?php echo get_the_title($_POST['layout-page']) ?></strong></h4>
		<?php } else { ?>
		<h4 id="layout-heading">Editing System Page: <strong><?php echo ($_POST['layout-system-page'] != 'four04') ? ucwords($_POST['layout-system-page']) : '404' ?></strong></h4>
		<?php } ?>
			
		<?
		$content['layout_options_link'] = 'Layout Options';
		if(get_write_box_value('leaf_template', false, $_POST['layout-page'])){
			$display['overlay_panel'] = ' style="display:block;opacity:1;"';
			$display['buttons'] = ' style="display:none;"';
			$content['layout_options_link'] = 'Close Layout Options';
		}
		?>
			
		<div id="add-leafs">
			<a href="#" id="add-leafs-first" class="plus"<?=$display['buttons']?>>Add a Leaf</a>
			<ul class="add-leafs">
				<li class="rotator"><span>Image Rotator Leaf</span> <a href="" id="add-image-rotator">Add</a></li>
				<li class="about"><span>About Leaf</span> <a href="" id="add-about">Add</a></li>
				<li class="featured"><span>Featured Post Leaf</span> <a href="" id="add-featured">Add</a></li>
				<li class="feed"><span>RSS/Recent Posts Leaf</span> <a href="" id="add-feed">Add</a></li>
				<li class="text"><span>Text/HTML Leaf</span> <a href="" id="add-text">Add </a></li>
				<li class="twitter"><span>Twitter Leaf</span> <a href="" id="add-twitter">Add</a></li>
				<li class="separator"></li>
				<li class="sidebar"><span>Widget Ready Sidebar</span> <a href="" id="add-sidebar">Add</a></li>
				<li class="content"><span>Content</span> <a href="" id="add-content">Add</a></li>

			</ul>
		</div>
	

		
		<?php endif; ?>
	</div>


<?php if($_POST['layout-page']): ?>
	<form method="post" id="layout_configuration">
	<ul id="layout" style="width:<?php echo get_option('wrapper-width')?>px">
	
	
		<?php
		$leaf_order = get_post_meta($_POST['layout-page'], '_leafs', true);
		
		if($leaf_order){
			foreach($leaf_order as $leaf){
				$leaf_config = get_post_meta($_POST['layout-page'], '_'.$leaf, true);
				$item_options = get_post_meta($_POST['layout-page'], '_'.$leaf.'_options', true);
				
				

				$count = substr(5, $leaf);
			
					if(file_exists(TEMPLATEPATH.'/library/leafs/'.$leaf_config[0].'/index.php')):
						include TEMPLATEPATH.'/library/leafs/'.$leaf_config[0].'/index.php';
					endif;
					
				
				$right_float = null; //Reset variable.
				$alignment = null; //Again
				
					
				$fluid_class = null; //Reset variable.
				$fluid = null; //Again
				
				if($leaf_config[4] == 1):
				 	$right_float = ' float: right'; 
					$alignment = ' checked="checked"';
				endif;
				if($leaf_config[5] == 1):
				 	$fluid_class = ' fluid'; 
					$fluid = ' checked="checked"';
				endif;
				
					
				echo '<li id="'.$leaf.'" class="sortable '.$leaf_config[0].$fluid_class.'" style="width:'.$leaf_config[2].'px; height: '.$leaf_config[3].'px;'.$right_float.'">
					<strong><input type="text" class="title" id="'.$leaf.'_title" name="item_titles['.$leaf.']" value="'.$leaf_config[1].'" /><span class="edit">Edit</span></strong>
				
				
					<span class="dimension">Width:</span>
					<input type="text" value="'.$leaf_config[2].'" id="'.$leaf.'_width" class="dimension dimension-width" />
				
					<span class="dimension">Height:</span>
					<input type="text" value="'.$leaf_config[3].'" id="'.$leaf.'_height" class="dimension dimension-height" />
					
					<input type="checkbox" value="'.$leaf_config[4].'" id="'.$leaf.'_alignment" class="dimension alignment alignment-checkbox" value="right"'.$alignment.' /> <label for="'.$leaf.'_alignment" class="dimension">Align To Right</label>
					<input type="checkbox" value="'.$leaf_config[5].'" id="'.$leaf.'_fluid" class="dimension alignment fluid-checkbox" value="fluid"'.$fluid.' /> <label for="'.$leaf.'_fluid" class="dimension">Fluid Height</label>
				
					<div class="sortable-inner" id="'.$leaf.'_inner" title="'.$leaf_config[1].'"><div id="'.$leaf.'_options_form">'.$leaf_inner.'</div></div></li>';
			}
		}
		$content['layout_options_link'] = 'Layout Options';
		if(get_write_box_value('leaf_template', false, $_POST['layout-page'])){
			$display['overlay_panel'] = ' style="display:block;opacity:1;"';
			$display['buttons'] = ' style="display:none;"';
			$content['layout_options_link'] = 'Close Layout Options';
		}
		?>
		<div id="layout-editor-overlay-panel"<?=$display['overlay_panel']?>>
			<div id="layout-editor-overlay-panel-bg"></div>
			
			<div id="layout-editor-options-panel-content"<?=$display['overlay_panel']?> class="layout-editor-overlay-content">

				<p>Select a page below to copy the leafs from.  This will tell the page you are currently editing to fetch the leafs exactly like the page you select.  You can also change this value in the page editor.  <strong>If this is set to another page it will disable the layout editor for this page.  Choose the "-Do Not Copy-" option if you want to re-enable the editor.</strong></p>
				
				<p class="input" id="copy-select">
					<?php wp_dropdown_pages(array('exclude_tree' => $_POST['layout-page'], 'selected' => get_write_box_value('leaf_template', false, $_POST['layout-page']) , 'name' => 'page-leaf-template', 'show_option_none' => __('-Do Not Copy-'), 'sort_column'=> 'menu_order, post_title')); ?>
				</p>
				
				
				
			</div>
			
			<div id="layout-editor-copy-panel-content" class="layout-editor-overlay-content">
				
					<p>Choose the pages below you would like to copy the leafs to.  You can hold down control (command/Apple on a Mac) to select multiple pages.</p>
					
				
					<p class="input">
						<select name="copy-pages[]" id="copy-pages" size="10" multiple>
						<?php 
						  if(function_exists('get_pages')):
							$copy_pages = '';
							$copy_pages_query = get_pages();
							foreach($copy_pages_query as $copy_page){ 
								$copy_pages .= ($copy_page->ID != $_POST['layout-page']) ? '<option value="'.$copy_page->ID.'">'.$copy_page->post_title.'</option>' : '';
							}
							echo $copy_pages;
						endif;
						 ?>
						</select>
					</p>
					
					<p class="input">
						<input type="submit" value="Save and Copy" name="layout-change-submit-copy-go" id="submit" class="button-secondary layout-save" />
					</p>
				
			</div>
		</div>
	</ul>
	

		<?php
		if($order[0] != NULL):
			$order = ($leaf_order) ? implode('&item[]=', $leaf_order) : NULL;
			$order = str_replace('item_', '', $order);
		endif;
		?>
		<input type="hidden" value="<?php echo 'item[]='.$order?>" name="order" id="order" />
		<?php
		if($leaf_order){
		foreach($leaf_order as $item){
			$item_config = get_post_meta($_POST['layout-page'], '_'.$item, true);
			$item_options = get_post_meta($_POST['layout-page'], '_'.$item.'_options', true);			
			$item_text = get_post_meta($_POST['layout-page'], '_'.$item.'_text', true);
			
			$item_options = str_replace('\"', '\\\"', $item_options);
			
						
			$item_options = ($item_options) ? base64_encode($item_options) : '';		
			
			if($item_config[4] == NULL) $item_config[4] = 0;
			if($item_config[5] == NULL) $item_config[5] = 0;
		?>
		
			<input type="hidden" value="<?php echo $item_config[0]?> | <?php echo $item_config[1]?> | <?php echo $item_config[2]?> | <?php echo $item_config[3]?> | <?php echo $item_config[4]?> | <?php echo $item_config[5]?>" name="config[<?php echo $item?>]" id="<?php echo $item?>_config" />
			<input type="hidden" value='<?php echo $item_options?>' name="options[<?php echo $item?>]" id="<?php echo $item?>_options" />
			<? if($item_config[0] == 'text'){ ?>
			<input type="hidden" value='<?php echo $item_text?>' name="text[<?php echo $item?>]" id="<?php echo $item?>_text" />
			<? } ?>


		<?php } } ?>
		<input type="hidden" value="<?php echo $_POST['layout-page']?>" name="layout-page" />
		<div id="layout-button-container" style="width:<?php echo get_option('wrapper-width')?>px">
			<input type="submit" value="Save Changes" name="layout-change-submit" id="submit" class="button-primary layout-save" />
			<input type="submit" value="Save and Copy Changes" name="layout-change-submit-copy" id="submit-copy" class="button-secondary layout-save layout-save-copy"<?=$display['buttons']?> />
			
			<a href="#layout-options" id="layout-options-link"<?=$display['buttons']?>><?=$content['layout_options_link']?></a>
		</div>
		
	</form>
	
<?php elseif($_POST['layout-system-page']): ?>
		<ul id="layout" style="width:<?php echo get_option('wrapper-width')?>px">


			<?
			$leaf_order = get_option('system-page-'.$_POST['layout-system-page'].'-leafs');

			if($leaf_order){
				foreach($leaf_order as $leaf){
					$leaf_config = get_option('system-page-'.$_POST['layout-system-page'].'-'.$leaf);
					$item_options = get_option('system-page-'.$_POST['layout-system-page'].'-'.$leaf.'_options');

					$count = substr(5, $leaf);

						if(file_exists(TEMPLATEPATH.'/library/leafs/'.$leaf_config[0].'/index.php')):
							include TEMPLATEPATH.'/library/leafs/'.$leaf_config[0].'/index.php';
						endif;


					$right_float = null; //Reset variable.
					$alignment = null; //Again
					
					$fluid_class = null; //Reset variable.
					$fluid = null; //Again

					if($leaf_config[4] == 1):
					 	$right_float = ' float: right'; 
						$alignment = ' checked="checked"';
					endif;
					if($leaf_config[5] == 1):
					 	$fluid_class = ' fluid'; 
						$fluid = ' checked="checked"';
					endif;


					echo '<li id="'.$leaf.'" class="sortable '.$leaf_config[0].$fluid_class.'" style="width:'.$leaf_config[2].'px; height: '.$leaf_config[3].'px;'.$right_float.'">
						<strong><input type="text" class="title" id="'.$leaf.'_title" name="item_titles['.$leaf.']" value="'.$leaf_config[1].'" /><span class="edit">Edit</span></strong>


						<span class="dimension">Width:</span>
						<input type="text" value="'.$leaf_config[2].'" id="'.$leaf.'_width" class="dimension dimension-width" />

						<span class="dimension">Height:</span>
						<input type="text" value="'.$leaf_config[3].'" id="'.$leaf.'_height" class="dimension dimension-height" />

						<input type="checkbox" value="'.$leaf_config[4].'" id="'.$leaf.'_alignment" class="dimension alignment alignment-checkbox" value="right"'.$alignment.' /> <label for="'.$leaf.'_alignment" class="dimension">Align To Right</label>
						<input type="checkbox" value="'.$leaf_config[5].'" id="'.$leaf.'_fluid" class="dimension alignment fluid-checkbox" value="fluid"'.$fluid.' /> <label for="'.$leaf.'_fluid" class="dimension">Fluid Height</label>


						<div class="sortable-inner" id="'.$leaf.'_inner" title="'.$leaf_config[1].'"><div id="'.$leaf.'_options_form">'.$leaf_inner.'</div></div></li>';
				}
			}
			?>


		</ul>

		<form method="post" id="layout_configuration">
			<?
			if($order[0] != NULL):
				$order = ($leaf_order) ? implode('&item[]=', $leaf_order) : NULL;
				$order = str_replace('item_', '', $order);
			endif;
			?>
			<input type="hidden" value="<?php echo 'item[]='.$order?>" name="order" id="order" />
			<?
			if($leaf_order){
			foreach($leaf_order as $item){
				$item_config = get_option('system-page-'.$_POST['layout-system-page'].'-'.$item);
				$item_options = get_option('system-page-'.$_POST['layout-system-page'].'-'.$item.'_options');
				$item_text = get_option('system-page-'.$_POST['layout-system-page'].'-'.$item.'_text');
				
				
				$item_options = str_replace('\"', '\\\"', $item_options);
				
				
				$item_options = ($item_options) ? base64_encode($item_options) : '';		

				if($item_config[4] == NULL) $item_config[4] = 0;
				if($item_config[5] == NULL) $item_config[5] = 0;

			?>

				<input type="hidden" value="<?php echo $item_config[0]?> | <?php echo $item_config[1]?> | <?php echo $item_config[2]?> | <?php echo $item_config[3]?> | <?php echo $item_config[4]?> | <?php echo $item_config[5]?>" name="config[<?php echo $item?>]" id="<?php echo $item?>_config" />
				<input type="hidden" value='<?php echo $item_options?>' name="options[<?php echo $item?>]" id="<?php echo $item?>_options" />
				<? if($item_config[0] == 'text'){ ?>
				<input type="hidden" value='<?php echo $item_text?>' name="text[<?php echo $item?>]" id="<?php echo $item?>_text" />
				<? } ?>

			<? } } ?>
			<div id="layout-button-container" style="width:<?php echo get_option('wrapper-width')?>px">
				<input type="hidden" value="<?php echo $_POST['layout-system-page']?>" name="layout-system-page" />
				<input type="submit" value="Save Changes" name="layout-change-submit" id="submit" class="button-primary layout-save" />
			</div>
		</form>
<? else: ?>
<p class="notice">Choose a page or system page to modify using the form above.</p>
<? endif; ?>
<? } else{
	echo '<p>We are incredibly sorry, but the Headway Layout Editor does not support your browser.  We recommend you upgrade to Firefox, Safari, or Chrome.  If you\'re hesitant to switch, don\'t worry.  Your experience will be much better (not to mention they are a bajillion times faster than Internet Explorer).  Firefox will even transfer all of your Internet Explorer bookmarks, settings, etc. over for you automatically.</p><p><strong>Click <a href="http://www.mozilla.com/en-US/products/download.html">Here</a> to download Firefox.</strong></p>';
}
?>