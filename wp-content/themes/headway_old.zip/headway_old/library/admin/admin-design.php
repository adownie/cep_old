<h2>Headway Design</h2>

<?php
 	if($_POST): 

	if(!isset($scheme_check)) include 'admin-colors.php';
	
		
	foreach(array_reverse($_POST) as $key => $value):
		
		if($key == 'color-scheme'){
			if(!$colors_changed){
				if($value != 'custom'){
					foreach($scheme[$value] as $part['scheme'] => $color['scheme']){
						update_option('color-'.$part['scheme'], $color['scheme']);
					}
				}
				update_option('color-scheme', $value);
			}
		}
	
			
		if(strpos($key, '_unchecked')){
				$key = str_replace('_unchecked', '', $key);
				if($_POST[$key] == NULL) $value = 0;
		}
			
		if($key == 'featured-posts') $value = ($value > get_option('posts_per_page')) ? get_option('posts_per_page') : $value;
	
		if($key == 'color'){
			$existing_colors_keys = array(
				'background', 
				'default-hyperlink', 

				'wrapper-border',

				'header-background',
				'header-link', 
				'header-link-underline', 	
				'header-tagline', 
				'header-bottom-border',

				'navigation-background',
				'navigation-link-color',
				'navigation-link-color-active',
				'navigation-link-background-active',
				'navigation-link-border',
				'navigation-bottom-border',

				'breadcrumbs-background',
				'breadcrumbs-bottom-border',
				'breadcrumbs-color',
				'breadcrumbs-hyperlink-color',


				'post-title', 
				'post-title-hover', 
				'post-content', 
				'post-hyperlink',
				'post-meta', 
				'post-meta-hyperlink', 
				'post-content-h2',
				'post-content-h3',
				'post-content-h4',
				'post-bottom-border',

				'leaf-title', 
				'leaf-title-hyperlink', 
				'leaf-title-underline', 
				'leaf-content', 

				'sidebar-bg',   
				'widget-title', 		
				'sidebar-hyperlinks',

				'footer-text',
				'footer-hyperlinks',
				'footer-bg',
				'footer-top-border');	
			foreach($existing_colors_keys as $existing_color) $existing_colors[$existing_color] = get_option('color-'.$existing_color);

			
			foreach($value as $part['normal'] => $color['normal']){ 
				if(md5(implode('', array_values($value))) != md5(implode('', array_values($existing_colors)))){
					update_option('color-'.$part['normal'], $color['normal']);
			 		update_option('color-scheme', 'custom');
			
					$colors_changed = true;
				}
			}			
		}
		elseif($key != 'color-scheme'){
			update_option($key, $value);
		}
		
	endforeach;

	$disabled['stylesheet'] = (get_option('skin')) ? get_option('headway_skin_disabled') : NULL;
	$disabled['colors'] = (get_option('skin')) ? get_option('headway_colors_disabled') : NULL;
?>
<div class="success"><span>Design Updated!</span> <a href="<?php echo get_bloginfo('url')?>">View Site &raquo;</a></div>
<?php endif; ?>

<form method="post">
	<div id="tabs">
		<ul>
			<li><a href="#stylesheets">Stylesheets / Skins</a></li>
			<li><a href="#dimensions">Site Size / Dimensions</a></li>
			<li><a href="#header">Header</a></li>
			<li><a href="#post-display">Post Display / Comments</a></li>
			<li><a href="#typography">Typography (Fonts)</a></li>
			<?php if(get_option('site-style') == 'headway' && get_option('disable-color-stylesheet') != 1){ ?>
			<li><a href="#colors">Colors</a></li>
			<? } ?>
			<li><a href="#footer-options">Footer</a></li>
		</ul>
		

		<div id="stylesheets">
			<h3>Stylesheets</h3>


			<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row"><label for="site-style">Site Style</label></th>
					<td>
						<select id="site-style" name="site-style"<?php echo $disabled['stylesheet']['site-style']?>>
							<?php $selected['site-style'][get_option('site-style')] = ' selected'; ?>
							<optgroup label="Build-in Styles">
							<option value="headway"<?php echo $selected['site-style']['headway']?>>Headway Default</option>
							<option value=""></option>
							</optgroup>
							<optgroup label="Developer Stylesheets">
							<option value="layout-only"<?php echo $selected['site-style']['layout-only']?>>Bare Bones — Layout CSS Only</option>
							<option value="no-css"<?php echo $selected['site-style']['no-css']?>>Complete Bare Bones - XHTML Only</option>
							</optgroup>
						</select>
						<span class="description">You can select which built-in stylesheet you want to use.  We recommend the <i>Bare Bones - Layout Only</i> stylesheet for development.</span>
					</td>
				</tr>



				<tr valign="top">
					<th scope="row">Custom Stylesheet</th>
					<td> 
					<fieldset>
						<legend class="hidden">Custom Stylesheet</legend>
						<label for="custom-stylesheet">
						<?php buildCheckbox('custom-stylesheet', true) ?>
						Enable Custom Stylesheet
						</label>
					</fieldset>
					<span class="description">The custom stylesheet is located in the <code>root</code> directory of the theme.  Its full path is usually located in <code><? bloginfo('template_directory') ?>/custom.css</code></td>
				</tr>



				<tr valign="top">
					<th scope="row"><label for="additional-stylesheet">Additional Stylesheet</label></th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(htmlentities(html_entity_decode(get_option('additional-stylesheet')))) ?>" id="additional-stylesheet" name="additional-stylesheet"/>
						<span class="description">This is if you need to use another stylesheet <b>along with</b> custom.css.  If this applies to you then type in the full URL to the stylesheet.</span></td>
				</tr>
				
				
				
				
				<tr valign="top">
					<th scope="row">Color Stylesheet</th>
					<td> 
					<fieldset>
						<legend class="hidden">Color Stylesheet</legend>
						<label for="disable-color-stylesheet">
						<?php buildCheckbox('disable-color-stylesheet', true, $disabled['colors']['colors']) ?>
						Disable Color Stylesheet/Pickers
						</label>
					</fieldset>
					<span class="description">The color stylesheet is the stylesheet that is automatically produced by the color pickers in the colors tab.  If you disable this then that tab, along with the stylesheet being loaded, will temporarily go away until you reactivate this.  If you're using a custom stylesheet, it is recommended that you disable this.</code></td>
				</tr>
				
				
			</tbody>
			</table>
			
		
			<h3 class="border-top">Skins</h3>


			<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row"><label for="skin">Active Skin</label></th>
					<td>
						<select id="skin" name="skin">
							<?php $selected['skin'][get_option('skin')] = ' selected'; ?>
								<option value="">None</option>

							<?php foreach(get_skins() as $skin){ ?>
								<option value="<?php echo $skin ?>"<?php echo $selected['skin'][$skin]?>><?php echo ucwords(str_replace('_', ' ', str_replace('-', ' ', $skin))) ?></option>
							<?php } ?>
						</select>
					<span class="description">Headway has a powerful skinning system which allows you to download and install some pretty rockin' looks to spice up your Headway website.</span></td>
				</tr>


			</tbody>
			</table>
		</div>
		
		
		<div id="dimensions">
			<h3>Site Dimensions/Sizes</h3>

			<table class="form-table">
			<tbody>

				<tr>
					<th scope="row"><label for="wrapper-width">Wrapper Width</label></th>
					<td><input type="text" class="small-text" value="<?php echo stripslashes(htmlentities(html_entity_decode(get_option('wrapper-width')))) ?>" id="wrapper-width" name="wrapper-width" /><abbr title="Pixels — Short for picture elements.">px</abbr>
					<span class="description">This is the size of the main container of your website.  Be sure to keep this under 960 pixels or your website will not display properly on some computers.</span></td>
				</tr>	

				
				<? if(get_option('header-position') == 'inside'): ?>

				<tr>
					<th scope="row"><label for="wrapper-margin">Wrapper Margin</label></th>
					<td><input type="text" class="small-text" value="<?php echo stripslashes(htmlentities(html_entity_decode(get_option('wrapper-margin')))) ?>" id="wrapper-margin" name="wrapper-margin" /><abbr title="Pixels — Short for picture elements.">px</abbr>
					<span class="description">This is how far the <code>wrapper</code> will be from the top of the browser window or header if the header is set to outside.  Try to keep this below 30 pixels or so.</span></td>
				</tr>
				
				<? endif; ?>


			</tbody>
			</table>
		</div>
		
		
		<div id="header">
				<h3>Header</h3>

				<table class="form-table">
				<tbody>

					<tr valign="top">
						<th scope="row"><label for="header-position">Header Position</label></th>
						<td>
							<? $selected['header-position'][get_option('header-position')] = ' selected'; ?>
							<select id="header-position" name="header-position">
									<option value="inside"<?php echo $selected['header-position']['inside']?>>Inside Wrapper</option>
									<option value="outside"<?php echo $selected['header-position']['outside']?>>Outside Wrapper (Fluid Header)</option>
							</select></td>
					</tr>


					<tr valign="top">
						<th scope="row"><label for="header-position">Navigation Position</label></th>
						<td>
							<? $selected['navigation-position'][get_option('navigation-position')] = ' selected'; ?>
							<select id="navigation-position" name="navigation-position">
									<option value="below"<?php echo $selected['navigation-position']['below']?>>Below Header</option>
									<option value="above"<?php echo $selected['navigation-position']['above']?>>Above Header</option>
									<option value="invisible"<?php echo $selected['header-position']['invisible']?>>Do NOT Display The Navigation</option>
							</select></td>
					</tr>



					<tr valign="top">
						<th scope="row">Tagline</th>
						<td> 
							<fieldset>
								<legend class="hidden">Tagline</legend>
								<label for="show_tagline">
									<?php buildCheckbox('show_tagline', true) ?>
									Show Tagline/Slogan
								</label>
							</fieldset>
						<span class="description">The tagline is defined in <a href="<? bloginfo('url') ?>/wp-admin/options-general.php">Settings &rsaquo; General Options</a>.  This is generally a slogan.</td>
					</tr>


					<tr>
						<th scope="row"><label for="header-image">Header Image/Logo</th>
						<td><input type="text" class="regular-text" value="<?php echo stripslashes(htmlentities(html_entity_decode(get_option('header-image')))) ?>" id="header-image" name="header-image"/>
						<span class="description">Upload an image or logo to use in your website's header.  Be sure it matches the background color of the header.</span></td>
					</tr>
					
					
					
					<tr>
						<th scope="row"><label for="header-image-margin">Header Image/Logo Margin</th>
						<td><input type="text" class="regular-text" value="<?php echo stripslashes(htmlentities(html_entity_decode(get_option('header-image-margin')))) ?>" id="header-image-margin" name="header-image-margin"/>
						<span class="description">Specify the margin of the header image/logo here.  The default is 15px.  If you want to modify the margin for specific sides you can use the following format.  <code><b>TOP</b><small>px</small> <b>RIGHT</b><small>px</small> <b>BOTTOM</b><small>px</small> <b>LEFT</b><small>px</small></code>.  Just replace the top, right, etc. with the value you want.</span></td>
					</tr>


					<tr valign="top">
						<th scope="row">Breadcrumbs</th>
						<td> 
							<fieldset>
								<legend class="hidden">Breadcrumbs</legend>
								<label for="show_breadcrumbs">
									<?php buildCheckbox('show_breadcrumbs', true) ?>
									Show Breadcrumbs
								</label>
							</fieldset>
						<span class="description">"Breadcrumbs" is an odd term for the part of the website that helps tell you exactly where you are.  An example breadcrumbs would be: Home &raquo; Blog &raquo; Awesome Post Name</span></td>
					</tr>





					<tr valign="top">
						<th scope="row"><label for="header-position">Breadcrumbs Position</label></th>
						<td>
							<? $selected['breadcrumbs-position'][get_option('breadcrumbs-position')] = ' selected'; ?>
							<select id="breadcrumbs-position" name="breadcrumbs-position">
									<option value="below-header-navigation"<?php echo $selected['breadcrumbs-position']['below-header-navigation']?>>Below Header (Below Navigation)</option>
									<option value="below-header"<?php echo $selected['breadcrumbs-position']['below-header']?>>Below Header (Above Navigation)</option>
									<option value="above-header"<?php echo $selected['breadcrumbs-position']['above-header']?>>Above Header</option>
									<option value="above-header-navigation"<?php echo $selected['breadcrumbs-position']['above-header-navigation']?>>Above Header and Navigation</option>
							</select></td>
					</tr>



				</tbody>
				</table>
		</div>
			
	
		<div id="post-display">
			<h3>Post Display</h3>
	
	
			<table class="form-table">
			<tbody>


				<tr>
					<th scope="row"><label id="post-date-format">Date Format</label></th>
					<td><select name="post-date-format" id="post-date-format">
						<? $selected['post-date-format'][get_option('post-date-format')] = ' selected'; ?>
						<option value="1"<?php echo $selected['post-date-format']['1']?>>January 1, 2009</option>
						<option value="2"<?php echo $selected['post-date-format']['2']?>>MM/DD/YY</option>
						<option value="3"<?php echo $selected['post-date-format']['3']?>>DD/MM/YY</option>
						<option value="4"<?php echo $selected['post-date-format']['4']?>>Jan 1</option>
						<option value="5"<?php echo $selected['post-date-format']['5']?>>Jan 1, 2009</option>
						<option value="6"<?php echo $selected['post-date-format']['6']?>>January 1</option>
						<option value="7"<?php echo $selected['post-date-format']['7']?>>January 1st</option>
						<option value="8"<?php echo $selected['post-date-format']['8']?>>January 1st, 2009</option>
					</select></td>
				</tr>


	
				<tr>
				<td colspan="2">
		
					<span class="description"><span class="available-variables">In the following comment format forms, you are allowed to use the <em>%num%</em> variable shown below.</span>
						<ul>
							<li><code>%num%</code> - Shows the numbers of comments.</li>
						</ul>
					</span>
	
				</td>
				</tr>
	
				<tr>
					<th scope="row" style="width: 280px;"><label for="post-comment-format-0">Comment Format &mdash; 0 Comments</th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(htmlentities(get_option('post-comment-format-0'))) ?>" id="post-comment-format-0" name="post-comment-format-0"/>
					<span class="description">Customize the format of how the comment links will appear when there are 0 comments.</span></td>
				</tr>
	
				<tr>
					<th scope="row" style="width: 280px;"><label for="post-comment-format-1">Comment Format &mdash; 1 Comment</th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(htmlentities(get_option('post-comment-format-1'))) ?>" id="post-comment-format-1" name="post-comment-format-1"/>
					<span class="description">Customize the format of how the comment links will appear when there is 1 comment.</span></td>
				</tr>
	
				<tr>
					<th scope="row" style="width: 280px;"><label for="post-comment-format">Comment Format &mdash; More Than 1 Comment</th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(htmlentities(get_option('post-comment-format'))) ?>" id="post-comment-format" name="post-comment-format"/>
					<span class="description">Customize the format of how the comment links will appear when there is more than 1 comment.</span></td>
				</tr>
	
	
	
	
				<tr>
					<th scope="row"><label for="post-respond-format">Respond Format</th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(htmlentities(get_option('post-respond-format'))) ?>" id="post-respond-format" name="post-respond-format"/>
					<span class="description">Change the way your respond link will appear.  Could range from anything from "Leave a Comment" or "Flame me Here!".  Let your imagination run wild.</span></td>
				</tr>
	
	
	
				<tr>
				<td colspan="2">
		
					<span class="description"><span class="available-variables">The following variables can be placed in all of the boxes below to customize your posts.</span>
						<ul>
							<li><code>%date%</code> - Will return the date of the post and will be displayed in the format you choose above.</li>
							<li><code>%author%</code> - Displays the author of the post.</li>
							<li><code>%author_no_link%</code> - Displays the author of the post, but doesn't surround it in a hyperlink.</li>
							<li><code>%categories%</code> - Shows the post categories and their links.</li>
							<li><code>%comments%</code> - Shows the number of comments and the link to the comments in the post.  Customize the format above.</li>
							<li><code>%comments_link%</code> - Does the same exact thing as <code>%comments%</code>, but surrounds it in a hyperlink linking to the post comments.</li>
							<li><code>%respond%</code> - Shows a link that will take a visitor directly to the comment form to leave a comment.</li>
							<li><code>%tags%</code> - Shows the posts tags.</li>
							<li><code>%edit%</code> - If an admin, editor, or author is logged in they will be able to see this link and edit the post.</li>
						</ul>
					</span>
	
				</td>
				</tr>




				<tr>
					<th scope="row"><label for="post-above-title-left">Above Title - Left</th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(htmlentities(get_option('post-above-title-left'))) ?>" id="post-above-title-left" name="post-above-title-left" /></td>
				</tr>
	
				<tr>
					<th scope="row"><label for="post-above-title-right">Above Title - Right</th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(htmlentities(get_option('post-above-title-right'))) ?>" id="post-above-title-right" name="post-above-title-right" /></td>
				</tr>
	
				<tr>
					<th scope="row"><label for="post-below-title-left">Below Title - Left</th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(htmlentities(get_option('post-below-title-left'))) ?>" id="post-below-title-left" name="post-below-title-left" /></td>
				</tr>
	
				<tr>
					<th scope="row"><label for="post-below-title-right">Below Title - Right</th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(htmlentities(get_option('post-below-title-right'))) ?>" id="post-below-title-right" name="post-below-title-right" /></td>
				</tr>
	
				<tr>
					<th scope="row"><label for="post-below-content-left">Below Content - Left</th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(htmlentities(get_option('post-below-content-left'))) ?>" id="post-below-content-left" name="post-below-content-left" /></td>
				</tr>
	
				<tr>
					<th scope="row"><label for="post-below-content-right">Below Content - Right</th>
					<td><input type="text" class="regular-text" value="<?php echo stripslashes(htmlentities(get_option('post-below-content-right'))) ?>" id="post-below-content-right" name="post-below-content-right" /></td>
				</tr>


				<tr>
					<th scope="row"><label for="featured-posts">Featured Posts</label></th>
					<td><input type="text" class="small-text" value="<?php echo stripslashes(htmlentities(html_entity_decode(get_option('featured-posts')))) ?>" id="featured-posts" name="featured-posts" />
					<span class="description">Featured posts contain the whole post content on the blog index.  After the number of featured posts, it will start to show excerpts instead of the content.</span></td>
				</tr>
				
				
				<tr>
					<th scope="row">Small Excerpts</th>
					<td> 
						<fieldset>
							<legend class="hidden">Enable Small Excerpts</legend>
							<label for="small-excerpts">
								<?php buildCheckbox('small-excerpts', true) ?>
								Enable Small Excerpts
							</label>
						</fieldset>
					<span class="description">Enabling this will cause the post excerpts to be much smaller and fit two per row.</span></td>
				</tr>

			</tbody>
			</table>



			<h3 class="border-top">Comments</h3>



			<table class="form-table">
			<tbody>
			<tr valign="top">
				<th scope="row">Show Commenter Avatars</th>
				<td> 
					<fieldset>
						<legend class="hidden">Show Commenter Avatars</legend>
						<label for="show-avatars">
							<?php buildCheckbox('show-avatars', true) ?>
							Show Commenter Avatars
						</label>
					</fieldset>
				<span class="description">This will enable or disable the little pictures that appear beside the commenter's name.</span></td>
			</tr>

			<tr>
				<th scope="row">Disable Comments On Pages</th>
				<td> 
					<fieldset>
						<legend class="hidden">Disable Comments On Pages</legend>
						<label for="headway-disable-comments-pages">
							<?php buildCheckbox('headway-disable-comments-pages', true) ?>
							Disable Comments On Pages
						</label>
					</fieldset>
				<span class="description">You can disable the comments on every single page with this checkbox.  If you need to disable comments for just one page, you can do it on that page's write panel.</span></td>
			</tr>



			<tr>
				<th scope="row"><label for="default-avatar">Default Avatar</label></th>
				<td><input type="text" class="regular-text" value="<?php echo get_option('default-avatar')?>" id="default-avatar" name="default-avatar" />
				<span class="description">If you're sick of looking at the little grey man, you can upload a small image to be your default avatar.  Just enter the URL to the image here.</span></td>
			</tr>

			<tr>
				<th scope="row"><label for="avatar-size">Avatar Size</label></th>
				<td><input type="text" class="small-text" value="<?php echo get_option('avatar-size')?>" id="avatar-size" name="avatar-size" /><code>PX</code>
				<span class="description">Change the size of the comment avatars here.  The default is <code>48px</code>.</span></td>
			</tr>

			</tbody>
			</table>
		</div>
			
			
		<div id="typography">
			<h3>Typography / Fonts</h3>


			<table class="form-table">
			<tbody>

				<?
				$fonts = array('Body' => 'body', 'Header' => 'header', 'Header Tagline' => 'header-tagline', 'Navigation' => 'navigation', 'Breadcrumbs' => 'breadcrumbs', 'Sidebar' => 'sidebar', 'Sidebar Widget Heading' => 'sidebar-widget-heading', 'Leaf Headings' => 'leaf-headings', 'Content' => 'content', 'Page/Post Titles' => 'titles', 'Post &lt;h2&gt;' => 'post-h2', 'Post &lt;h3&gt;' => 'post-h3', 'Post &lt;h4&gt;' => 'post-h4');

				foreach($fonts as $title => $id):
				?>
					<tr valign="top">
						<th scope="row"><label for="fonts-<?php echo $id?>"><?php echo $title?></label></th>
						<td>
							<? $selected['fonts-'.$id][get_option('fonts-'.$id)] = ' selected'; ?>
							<select id="fonts-<?php echo $id?>" name="fonts-<?php echo $id?>">
								<optgroup label="Serif Fonts">
									<option value="georgia"<?php echo $selected['fonts-'.$id]['georgia']?>>Georgia</option>
									<option value="times"<?php echo $selected['fonts-'.$id]['times']?>>Times</option>
									<option value="times-new-roman"<?php echo $selected['fonts-'.$id]['times-new-roman']?>>Times New Roman</option>
									<option value=""></option>
								</optgroup>
								<optgroup label="Sans-Serif Fonts">
									<option value="helvetica"<?php echo $selected['fonts-'.$id]['helvetica']?>>Helvetica</option>
									<option value="arial"<?php echo $selected['fonts-'.$id]['arial']?>>Arial</option>
									<option value="arial-black"<?php echo $selected['fonts-'.$id]['arial-black']?>>Arial Black</option>
									<option value="verdana"<?php echo $selected['fonts-'.$id]['verdana']?>>Verdana</option>
									<option value="tahoma"<?php echo $selected['fonts-'.$id]['tahoma']?>>Tahoma</option>
									<option value="courier"<?php echo $selected['fonts-'.$id]['courier']?>>Courier</option>
									<option value="courier-new"<?php echo $selected['fonts-'.$id]['courier-new']?>>Courier New</option>
									<option value="lucida-grande"<?php echo $selected['fonts-'.$id]['lucida-grande']?>>Lucida Grande</option>
									<option value="gill-sans"<?php echo $selected['fonts-'.$id]['gill-sans']?>>Gill Sans</option>

								</optgroup>
							</select>
							
							<? if($id != 'body'){ ?>
							<? $selected['fonts-'.$id.'-size'][get_option('fonts-'.$id.'-size')] = ' selected'; ?>
							<select id="fonts-<?php echo $id?>-size" name="fonts-<?php echo $id?>-size">
									<option value="1"<?php echo $selected['fonts-'.$id.'-size']['1']?>>10pt</option>
									<option value="1.1"<?php echo $selected['fonts-'.$id.'-size']['1.1']?>>11pt</option>
									<option value="1.2"<?php echo $selected['fonts-'.$id.'-size']['1.2']?>>12pt</option>
									<option value="1.3"<?php echo $selected['fonts-'.$id.'-size']['1.3']?>>13pt</option>
									<option value="1.4"<?php echo $selected['fonts-'.$id.'-size']['1.4']?>>14pt</option>
									<option value="1.5"<?php echo $selected['fonts-'.$id.'-size']['1.5']?>>15pt</option>
									<option value="1.6"<?php echo $selected['fonts-'.$id.'-size']['1.6']?>>16pt</option>
									<option value="1.7"<?php echo $selected['fonts-'.$id.'-size']['1.7']?>>17pt</option>
									<option value="1.8"<?php echo $selected['fonts-'.$id.'-size']['1.8']?>>18pt</option>
									<option value="1.9"<?php echo $selected['fonts-'.$id.'-size']['1.9']?>>19pt</option>
									<option value="2"<?php echo $selected['fonts-'.$id.'-size']['2']?>>20pt</option>
									<option value="2.2"<?php echo $selected['fonts-'.$id.'-size']['2.2']?>>22pt</option>
									<option value="2.4"<?php echo $selected['fonts-'.$id.'-size']['2.4']?>>24pt</option>
									<option value="2.6"<?php echo $selected['fonts-'.$id.'-size']['2.6']?>>26pt</option>
									<option value="2.8"<?php echo $selected['fonts-'.$id.'-size']['2.8']?>>28pt</option>
									<option value="3"<?php echo $selected['fonts-'.$id.'-size']['3']?>>30pt</option>
									<option value="3.2"<?php echo $selected['fonts-'.$id.'-size']['3.2']?>>32pt</option>
									<option value="3.4"<?php echo $selected['fonts-'.$id.'-size']['3.4']?>>34pt</option>
							</select>
							<? } ?>
							
						</td>
					</tr>			
				<?
				endforeach;
				?>








				<tr>
					<th scope="row"><label for="fonts-content-line-height">Content Line-Height</label></th>
					<td><input type="text" class="medium-text" value="<?php echo get_option('fonts-content-line-height')?>" id="fonts-content-line-height" name="fonts-content-line-height" /><abbr title="Pixels — Short for picture elements.">px</abbr>/<abbr title="In typography, a point is the smallest unit of measure, being a subdivision of the larger pica. It is commonly abbreviated as pt. The traditional printer's point, from the era of hot metal typesetting and presswork, varied between 0.18 and 0.4 mm depending on various definitions of the foot.">pt</abbr>/<abbr title="An em is a unit of measurement in the field of typography, equal to the point size of the current font. This unit is not defined in terms of any specific typeface, and thus is the same for all fonts at a given point size.">em</abbr>
					<span class="description">This is the amount of space between each line in your blog posts or pages.  For quick reference, 1em is equal to single-spacing and 2em is equal to double-spacing.</span></td>
				</tr>
			</tbody>
			</table>
		</div>
			
		<?php if(get_option('site-style') == 'headway' && get_option('disable-color-stylesheet') != 1){ ?>	
		<div id="colors">
			<h3>Colors</h3>
			
			
			<table class="form-table">
			<tbody>

					<tr valign="top">
						<th scope="row"><label for="color-scheme">Color Scheme</label></th>
						<td>
							<?php $selected['color-scheme'][get_option('color-scheme')] = ' selected'; ?>
							<select id="color-scheme" name="color-scheme">
								<option value="custom"<?php echo $selected['color-scheme']['custom'] ?>>-Custom-</option>
								
								<option value="default"<?php echo $selected['color-scheme']['default'] ?>>Staying Simple (Default)</option>
								<option value="grey"<?php echo $selected['color-scheme']['grey'] ?>>Galvanized Grey</option>
								<option value="grey-tabs"<?php echo $selected['color-scheme']['grey-tabs'] ?>>Galvanized Grey (Tab Navigation)</option>
								<option value="red"<?php echo $selected['color-scheme']['red'] ?>>Raging Red</option>
								<option value="green-tabs"<?php echo $selected['color-scheme']['green-tabs'] ?>>Going Green (Tab Navigation)</option>
							</select>
							<span class="description">Choose a beautiful color scheme to the left to spice up your site!  Want to customize a color scheme?  No problem, choose it and start tinkering away.<br /> <strong>WARNING: By switching to another color scheme you will lose all previous color changes.</strong></span>
						</td>
					</tr>

				

				<?php
				$colors = array(
					'Page' => 'title',
					
					'Background' => 'background', 
					'Default Hyperlink' => 'default-hyperlink', 
					
					
					'Wrapper' => 'title',
					
					'Wrapper Border' => 'wrapper-border', 
					
					
					
					'Header' => 'title',
					
					'Header Background' => 'header-background', 
					'Header Link/Title' => 'header-link', 
					'Header Link Underline' => 'header-link-underline', 
					'Header Tagline' => 'header-tagline', 
					'Header Bottom Border' => 'header-bottom-border',
					
					
					
					
					'Navigation' => 'title',
					
					'Navigation Background' => 'navigation-background',
					'Navigation Link Color' => 'navigation-link-color',
					'Navigation Link Color (Active)' => 'navigation-link-color-active',
					'Navigation Link Background (Active)' => 'navigation-link-background-active',
					'Navigation Link Border' => 'navigation-link-border',
					'Navigation Bottom Border' => 'navigation-bottom-border',
					
					
					'Breadcrumbs' => 'title',
					
					'Breadcrumbs Background' => 'breadcrumbs-background',
					'Breadcrumbs Bottom Border' => 'breadcrumbs-bottom-border',
					'Breadcrumbs Text Color' => 'breadcrumbs-color',
					'Breadcrumbs Hyperlink Color' => 'breadcrumbs-hyperlink-color',
					
					
					
					'Posts' => 'title',
					
					'Post Title' => 'post-title', 
					'Post Title (Hover)' => 'post-title-hover', 
					'Post Content' => 'post-content', 
					'Post Content Hyperlink' => 'post-hyperlink', 
					'Post Meta' => 'post-meta', 
					'Post Meta Hyperlink' => 'post-meta-hyperlink', 
					'Post Content &lt;h2&gt;' => 'post-content-h2',
					'Post Content &lt;h3&gt;' => 'post-content-h3',
					'Post Content &lt;h4&gt;' => 'post-content-h4',
					'Post Bottom Border' => 'post-bottom-border',
					
					
					
					'Leafs' => 'title',
					
					'Leaf Title' => 'leaf-title', 
					'Leaf Title (Hyperlink)' => 'leaf-title-hyperlink', 
					'Leaf Title Underline' => 'leaf-title-underline', 
					'Leaf Content' => 'leaf-content', 
					
					
					
					'Sidebar' => 'title',
					
					'Sidebar Background' => 'sidebar-bg',
					'Widget Title' => 'widget-title',
					'Sidebar Hyperlinks' => 'sidebar-hyperlinks',
					
					
					'Footer' => 'title',
					
					'Footer Text'		=> 'footer-text',
					'Footer Hyperlinks'	=> 'footer-hyperlinks',
					'Footer Background' => 'footer-bg',
					'Footer Top Border' => 'footer-top-border'
				);

				foreach($colors as $title => $id):
				?>
					<? if($id != 'title'){ ?>
					<tr>
						<th scope="row"><label for="color-<?php echo $id ?>"><?php echo $title ?></th>
						<td>#<input type="text" class="color-text" size="6" maxlength="6" value="<?php echo get_option('color-'.$id) ?>" id="color-<?php echo $id ?>" name="color[<?php echo $id ?>]" />
						</td>
					</tr>
					<? } else { ?>
					<tr>
						<td colspan="2"><h3 class="border-top"><?php echo $title ?></h3></td>
					</tr>
					<? } ?>
				<?
				endforeach;
				?>
				

			</tbody>
			</table>
			
			
			
			
		</div>
		<?php } ?>	
		
		<div id="footer-options">
			<h3>Footer</h3>
			
			<table class="form-table">
			<tbody>
				<tr valign="top">
					<th scope="row">Show Admin Link</th>
					<td> 
						<fieldset>
							<legend class="hidden">Show Admin Link</legend>
							<label for="show-avatars">
								<?php buildCheckbox('show-admin-link', true) ?>
								Show Admin Link
							</label>
						</fieldset>
					<span class="description">Shows a simple admin login (link when logged in) to the admin panel.  Uncheck this to hide it.</span></td>
				</tr>
			</tbody>
			</table>
		</div>
		
	</div>

	<p class="submit">
	<input type="submit" value="Save Changes" class="button-primary" name="Submit"/>
	</p>
</form>