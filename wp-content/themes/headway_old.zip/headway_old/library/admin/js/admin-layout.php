<?php
	include '../../../../../../wp-blog-header.php';
	header("content-type: application/x-javascript");
	define('TEMPLATEPATH', str_replace('/library/admin/js', '', dirname(__FILE__)));
?>
$(function(){
	$('#layout').sortable( {
		accept: 'sortable',
		opacity:  0.35,
		forcePlaceholderSize: true,
		items: 'li',
		update: function () { 
		var order = $('#layout').sortable('serialize'); 
			$('#order').attr('value', order);
		}
	});
	
	
	$('p#copy-select select').change(function () {
		if($("p#copy-select select option:selected").text() == '-Do Not Copy-' && $('#add-leafs-first').css('display') == 'none'){
			$('#add-leafs-first').show();
			$('#submit-copy').show();
			$('#layout-options-link').show();
		}
		if($("p#copy-select select option:selected").text() != '-Do Not Copy-' && $('#add-leafs-first').css('display') == 'block'){
			$('#add-leafs-first').hide();
			$('#submit-copy').hide();
			$('#layout-options-link').hide();
		}
	});
	
	
	$('#layout-options-link').click(function(){
		if($('#layout-editor-copy-panel-content').css('display') == 'block'){
			$('#layout-editor-copy-panel-content').animate({
				opacity: 0
			}, 'normal', false, function(){ $('#layout-editor-copy-panel-content').hide() });
			$('#submit-copy').attr('Value', 'Submit and Copy Changes');
		}
		if($('#layout-editor-overlay-panel').css('display') == 'block' && $('#layout-editor-copy-panel-content').css('display') == 'none'){
			$('#layout-editor-overlay-panel').animate({
				opacity: 0
			}, 'normal', false, function(){ $('#layout-editor-overlay-panel').hide() });
			$('#layout-editor-options-panel-content').hide();
			$(this).text('Layout Options');
			return false;
		}
		else
		{
			$('#layout-editor-overlay-panel').show();
			$('#layout-editor-options-panel-content').show();
			$('#layout-editor-overlay-panel, #layout-editor-options-panel-content').animate({
				opacity: 1
			});
			$(this).text('Close Layout Options');
			return false;
		}
	});
	
	
	
	
	$('#submit-copy').click(function(){
		if($('#layout-editor-options-panel-content').css('display') == 'block'){
			$('#layout-editor-options-panel-content').animate({
				opacity: 0
			}, 'normal', false, function(){ $('#layout-editor-options-panel-content').hide() });
			$('#layout-options-link').text('Layout Options');
		}
		if($('#layout-editor-overlay-panel').css('display') == 'block' && $('#layout-editor-options-panel-content').css('display') == 'none'){
			$('#layout-editor-overlay-panel').animate({
				opacity: 0
			}, 'normal', false, function(){ $('#layout-editor-overlay-panel').hide() });
			$('#layout-editor-copy-panel-content').hide();
			$(this).attr('value', 'Save and Copy Changes');
			return false;
		}
		else
		{
			$('#layout-editor-overlay-panel').show()
			$('#layout-editor-copy-panel-content').show();
			$('#layout-editor-overlay-panel, #layout-editor-copy-panel-content').animate({
				opacity: 1
			});
			$(this).attr('value', 'Cancel Save and Copy Changes');
			return false;
		}
	});
	
	 
	
	
	
	function initiate_inline_title(id){
		$(id).blur(function(){
			this_value = $(this).attr('value');
			this_parent_id = $(this).parent().parent().attr('id');
			this_config_current = $('#'+this_parent_id+'_config').attr('value');
			this_config_current = this_config_current.split(' | ', 6);
			this_config_current[1] = this_value;
			this_config_fixed = this_config_current.join(' | ');
		
			$('#'+this_parent_id+'_config').attr('value', this_config_fixed);
		});
	}
	
	initiate_inline_title('strong input');
	
	
	
	
	function initiate_aligner(id){
		$(id).click(function() {
			
			this_parent_id = $(this).parent().attr('id');
			
			if($(this).is(':checked')){
				
				this_value = $(this).attr('value');
			
				this_config_current = $('#'+this_parent_id+'_config').attr('value');
				this_config_current = this_config_current.split(' | ', 6);
			
				this_config_current[4] = 1;
				$('#'+this_parent_id).css('float', 'right');
				
				this_config_fixed = this_config_current.join(' | ');
	
				$('#'+this_parent_id+'_config').attr('value', this_config_fixed);
	
	
				var order = $('#layout').sortable('serialize'); 
				$('#order').attr('value', order);
			
			}
			else {
				
				this_config_current = $('#'+this_parent_id+'_config').attr('value');
				this_config_current = this_config_current.split(' | ', 6);
			
				this_config_current[4] = 0;
				$('#'+this_parent_id).css('float', 'left');
				
				this_config_fixed = this_config_current.join(' | ');
	
				$('#'+this_parent_id+'_config').attr('value', this_config_fixed);
	
	
				var order = $('#layout').sortable('serialize'); 
				$('#order').attr('value', order);
				
			}
		
		});
	}
	
	initiate_aligner('input.alignment-checkbox');
	
	
	
	
	
	
	
	function initiate_fluid(id){
		$(id).click(function() {
			
			this_parent_id = $(this).parent().attr('id');
			
			if($(this).is(':checked')){
				
				this_value = $(this).attr('value');
			
				this_config_current = $('#'+this_parent_id+'_config').attr('value');
				this_config_current = this_config_current.split(' | ', 6);
			
				this_config_current[5] = 1;
				$('#'+this_parent_id).addClass('fluid');
				
				this_config_fixed = this_config_current.join(' | ');
	
				$('#'+this_parent_id+'_config').attr('value', this_config_fixed);
	
	
				var order = $('#layout').sortable('serialize'); 
				$('#order').attr('value', order);
			
			}
			else {
				
				this_config_current = $('#'+this_parent_id+'_config').attr('value');
				this_config_current = this_config_current.split(' | ', 6);
			
				this_config_current[5] = 0;
				$('#'+this_parent_id).removeClass('fluid');
				
				this_config_fixed = this_config_current.join(' | ');
	
				$('#'+this_parent_id+'_config').attr('value', this_config_fixed);
	
	
				var order = $('#layout').sortable('serialize'); 
				$('#order').attr('value', order);
				
			}
		
		});
	}
	
	initiate_fluid('input.fluid-checkbox');
	
	
	
	
	function initiate_inline_dimensions(id, which){
		$(id).blur(function(){
			this_value = $(this).attr('value');
			this_parent_id = $(this).parent().attr('id');			
		
			
			this_config_current = $('#'+this_parent_id+'_config').attr('value');
			this_config_current = this_config_current.split(' | ', 6);
			if(which == 'width'){
				this_config_current[2] = this_value;
				$('#'+this_parent_id).css('width', this_value+'px');
			}
			else if(which == 'height'){
				this_config_current[3] = this_value;
				$('#'+this_parent_id).css('height', this_value+'px');
				
			}
			this_config_fixed = this_config_current.join(' | ');
	
			$('#'+this_parent_id+'_config').attr('value', this_config_fixed);
	
	
			var order = $('#layout').sortable('serialize'); 
			$('#order').attr('value', order);
			

		});
	}
	
	initiate_inline_dimensions('input.dimension-width', 'width');
	initiate_inline_dimensions('input.dimension-height', 'height');

	
	 
	function resizable(id){
		$(id).resizable({
			maxWidth: <?php echo get_option('wrapper-width')-30?>, 
			minHeight: 115, 
			minWidth: 220,
			resize: function(event, ui) { 
				resize_element = '#' + $(this).attr('id') + '_config';
		
				item_class = $(this).attr('class').split(' ', 3)[1];
				
				this_id = $(this).attr('id');
				this_config_current = $('#'+this_id+'_config').attr('value');
				this_config_current = this_config_current.split(' | ', 6);
				this_config_current[0] = item_class;
				this_config_current[2] = ui.size.width;
				this_config_current[3] = ui.size.height;
				this_config_fixed = this_config_current.join(' | ');
		
				$(resize_element).attr('value', this_config_fixed);
		
				var order = $('#layout').sortable('serialize'); 
				$('#order').attr('value', order);
				
				$('#' + $(this).attr('id') + '_width').attr('value', ui.size.width);
				$('#' + $(this).attr('id') + '_height').attr('value', ui.size.height);
				
				
			}
		});
	}
	
	function initiate_dialog(id){
			$(id).dialog({
				autoOpen: false,
				modal: true, 
				position: ['center',15],
				width: 540,
				buttons: {
					Okay: function() {
						var id = $(this).attr('id').replace('_inner', '');
						options_array = $('#'+id+'_options_form :input:not(.text-content)').serializeArray();
						if($('#'+id+'_options_form .text-content').val()){
							text_content = $('#'+id+'_options_form .text-content').val();
							text_content = Base64.encode(text_content);
							$('#'+id+'_text').attr('value', text_content);
						}
						


						options_array = $.each( options_array, function(i, val){							
							val.value = val.value.htmlEntities();
							return this;
						});

						options_json = Base64.encode($.toJSON(options_array));
									
						
						 $('#'+id+'_options').attr('value', options_json);
						
						$(this).dialog('close');
					},
					Delete: function() {
						var id = $(this).attr('id').replace('_inner', '');
						var id_remove = id;
						count--;
						$(this).dialog('destroy');
						$('#'+id_remove).remove();
						$('#'+id_remove+'_inner').remove();
						$('#'+id_remove+'_config').remove();
						$('#'+id_remove+'_options').remove();


						$("#layout_configuration").append('<input type="hidden" name="delete['+id_remove+']" id="'+id_remove+'_delete" value="true" />');
						var order = $('#layout').sortable('serialize'); 
						$('#order').attr('value', order);

					}
				}
			});
	}

	
	
	function initiate_edit_links(id){
		$(id).click(function(){var id = $(this).parent().parent().attr('id'); var id = '#' + id + '_inner';$(id).dialog('open');return false;});
	}
	
	
	function add_leaf(leaf_name, leaf_class, leaf_inner, fluid){
		
		var fluid_class = '';
		var fluid_active = '';
		var fluid_checked = '';
		if(fluid){ 
			var fluid_class = ' fluid'; 
			var fluid_active = '1';
			var fluid_checked = ' checked';
		}	
		if(!fluid){
			var fluid = false;
		}
		
		
		$("#layout").append('<li id="item_'+count+'" class="sortable '+leaf_class+fluid_class+'" style="height:115px;">\
		<strong>\
			<input type="text" class="title" value="'+leaf_name+'" />\
			<span class="edit">Edit</span>\
		</strong>\
		\
		<span class="dimension">Width:</span>\
		<input type="text" value="250" id="item_'+count+'_width" class="dimension dimension-width" />\
		\
		<span class="dimension">Height:</span>\
		<input type="text" value="115" id="item_'+count+'_height" class="dimension dimension-height" />\
		\
		<input type="checkbox" value="1" id="item_'+count+'_alignment" class="dimension alignment alignment-checkbox" value="right" /> <label for="item_'+count+'_alignment" class="dimension">Align To Right</label>\
		\
		<input type="checkbox" value="1" id="item_'+count+'_fluid" class="dimension alignment fluid-checkbox" value="right"'+ fluid_checked +' /> <label for="item_'+count+'_fluid" class="dimension">Fluid Height</label>\
		\
		<div class="sortable-inner" id="item_'+count+'_inner" title="'+leaf_name+'">'+leaf_inner+'</div></li>');
		
		
		initiate_dialog('#item_' + count + '_inner');
		
		
		initiate_edit_links('#item_' + count + ' strong span.edit');
				
		
		resizable('#item_' + count);
		var order = $('#layout').sortable('serialize'); 
		$('#order').attr('value', order);
		

		
		$("#layout_configuration").append('<input type="hidden" name="config[item_'+count+']" id="item_'+count+'_config" value="' +leaf_class+ ' | '+leaf_name+' | 250 | 115 | 0 | ' + fluid_active + '" />');
		$("#layout_configuration").append('<input type="hidden" name="options[item_'+count+']" id="item_'+count+'_options" value="" />');
		if(leaf_class == 'text'){
			$("#layout_configuration").append('<input type="hidden" name="text[item_'+count+']" id="item_'+count+'_text" value="" />');
		}

		
		$('#item_'+count+'_delete').remove();
		
		initiate_inline_title('#item_'+count+' strong input');
		
		initiate_inline_dimensions('#item_'+count+' input.dimension-width', 'width');
		initiate_inline_dimensions('#item_'+count+' input.dimension-height', 'height');
		
		initiate_aligner('#item_'+count+' input.alignment-checkbox');
		initiate_fluid('#item_'+count+' input.fluid-checkbox');
		
		
		
		
		options_array = $('#item_'+count+'_options_form :input:not(.text-content)').serializeArray();
		options_json = Base64.encode($.toJSON(options_array));
					
		
		 $('#item_'+count+'_options').attr('value', options_json);
	}
	






	$('a#add-image-rotator').click(function(){
		count = Math.floor(Math.random()*10*Math.random()*100)+count;
		
		
		<?php
			$javascript = true;

			include '../../leafs/rotator/index.php';
			$leaf_inner = str_replace("\n", '', $leaf_inner);
		?>
		var rotator_inner = '<?php echo $leaf_inner?>'.replace(/{{leaf_id_replace}}/g, 'item_'+count);
			

		
		add_leaf('Image Rotator', 'rotator', rotator_inner);
		return false;
	});
	
	
	
	
	$('a#add-twitter').click(function(){
		count = Math.floor(Math.random()*10*Math.random()*100)+count;
		
		
		<?php
			$javascript = true;

			include '../../leafs/twitter/index.php';
			$leaf_inner = str_replace("\n", '', $leaf_inner);
		?>
		var twitter_inner = '<?php echo $leaf_inner?>'.replace(/{{leaf_id_replace}}/g, 'item_'+count);
			

		
		add_leaf('Twitter', 'twitter', twitter_inner);
		return false;
	});
	
	
	
	
	
	
	
	
	$('a#add-content').click(function(){
		count = Math.floor(Math.random()*10*Math.random()*100)+count;
		
		
		<?php
			$javascript = true;

			include '../../leafs/content/index.php';
			$leaf_inner = str_replace("\n", '', $leaf_inner);
		?>
		var content_inner = '<?php echo $leaf_inner?>'.replace('{{select[categories_select]}}', categories_select).replace(/{{leaf_id_replace}}/g, 'item_'+count).replace('{{select[pages]}}', about_pages);
			

		
		add_leaf('Content', 'content', content_inner, true);
		return false;
	});
	
	
	
	

	
	

	
	$('a#add-featured').click(function(){
		count = Math.floor(Math.random()*10*Math.random()*100)+count;
		
		<?php
			$javascript = true;
			
			include '../../leafs/featured/index.php';
			$leaf_inner = str_replace("\n", '', $leaf_inner);
		?>
		var featured_inner = '<?php echo $leaf_inner?>'.replace('{{select[categories_select]}}', categories_select).replace(/{{leaf_id_replace}}/g, 'item_'+count);
				
		add_leaf('Featured', 'featured', featured_inner);
		return false;
	});
	
	
	
	
	
	$('a#add-about').click(function(){
		count = Math.floor(Math.random()*10*Math.random()*100)+count;
		
		<?php
			$javascript = true;
			
			include '../../leafs/about/index.php';
			$leaf_inner = str_replace("\n", '', $leaf_inner);
		?>
		var about_inner = '<?php echo $leaf_inner?>'.replace('{{select[about_pages]}}', about_pages).replace(/{{leaf_id_replace}}/g, 'item_'+count);
				
		add_leaf('About', 'about', about_inner);
		return false;
	});
	
	
	
	
	$('a#add-feed').click(function(){
		count = Math.floor(Math.random()*10*Math.random()*100)+count;
		
		
		<?php
			$javascript = true;
			
			include '../../leafs/feed/index.php';
			$leaf_inner = str_replace("\n", '', $leaf_inner);
		?>
		var feed_inner = '<?php echo $leaf_inner?>'.replace('{{select[categories_select]}}', categories_select).replace(/{{leaf_id_replace}}/g, 'item_'+count);
		
		add_leaf('Feed', 'feed', feed_inner);
		return false;
	});
	

	
	$('a#add-text').click(function(){
		count = Math.floor(Math.random()*10*Math.random()*100)+count;
		
		<?php
			$javascript = true;
			
			include '../../leafs/text/index.php';
			$leaf_inner = str_replace("\n", '', $leaf_inner);
		?>
		var text_inner = '<?php echo $leaf_inner?>'.replace(/{{leaf_id_replace}}/g, 'item_'+count);
		
		add_leaf('Text', 'text', text_inner);
		return false;
	});
	
	$('a#add-sidebar').click(function(){
		count = Math.floor(Math.random()*10*Math.random()*100)+count;
	
		<?php
			$javascript = true;
			
			include '../../leafs/sidebar/index.php';
			$leaf_inner = str_replace("\n", '', $leaf_inner);
		?>
		var sidebar_inner = '<?php echo $leaf_inner?>'.replace(/{{leaf_id_replace}}/g, 'item_'+count).replace(/{{id_formatted}}/g, count);
		
		add_leaf('Sidebar', 'sidebar', sidebar_inner, true);
		return false;
	});
	
	
	
	
	
	
	
	
	
	
	

	
	$('a#add-leafs-first').click(function(){
		$('ul.add-leafs').toggle();
		$('#add-leafs-first').toggleClass('minus');
		$('#add-leafs-first').toggleClass('plus');
		this_text = $(this).text();
		if(this_text == 'Add a Leaf'){
			$(this).text('Cancel');
		} else {
			$(this).text('Add a Leaf');
		}
		return false;
	});

	
	
	
	
	
	
	initiate_dialog('.sortable-inner');
	resizable('.sortable');
	

	
	initiate_edit_links('.sortable span.edit');
	
	
});