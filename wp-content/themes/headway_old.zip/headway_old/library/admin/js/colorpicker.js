$(function(){
	$('#color-background, #color-default-hyperlink, #color-wrapper-border, #color-header-background, #color-header-link, #color-header-link-underline, #color-header-tagline, #color-header-bottom-border, #color-navigation-background, #color-navigation-link-color, #color-navigation-link-color-active, #color-navigation-link-background-active, #color-navigation-link-border, #color-navigation-bottom-border, #color-breadcrumbs-background, #color-breadcrumbs-bottom-border, #color-breadcrumbs-color, #color-breadcrumbs-hyperlink-color, #color-post-title, #color-post-title-hover, #color-post-content, #color-post-hyperlink, #color-post-meta, #color-post-meta-hyperlink, #color-post-content-h3, #color-post-content-h4, #color-post-bottom-border, #color-leaf-title, #color-leaf-title-hyperlink, #color-leaf-title-underline, #color-leaf-content, #color-widget-title, #color-sidebar-bg, #color-sidebar-hyperlinks, #color-footer-bg, #color-footer-top-border').ColorPicker({
		onSubmit: function(hsb, hex, rgb, el) {
			$(el).val(hex);
			$(el).ColorPickerHide();
		},
		onBeforeShow: function () {
			$(this).ColorPickerSetColor(this.value);
		}
	})
	.bind('keyup', function(){
		$(this).ColorPickerSetColor(this.value);
	});
});