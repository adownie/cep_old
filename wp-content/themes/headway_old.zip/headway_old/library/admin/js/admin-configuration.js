$(function() {
		$("#tabs").tabs();
		
		$('#navigation-control').sortable( {
			accept: 'sortable',
			opacity:  0.35,
			forcePlaceholderSize: true,
			update: function () { 
			var order = $(this).sortable('serialize'); 
				$('#navigation-control-input').attr('value', order);
				console.log($('#navigation-control-input').attr('value'));		
			}
		});
		
		
		$('ul.sub-pages').sortable( {
			opacity:  0.35,
			forcePlaceholderSize: true,
			update: function () { 
			var order = $(this).sortable('serialize'); 
				$('#' + $(this).attr('id') + '-input').attr('value', order);
				console.log($('#' + $(this).attr('id') + '-input').attr('value'));
			}
		});
});