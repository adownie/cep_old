<?php
/*
Store all of your custom functions, actions, and so on in this file.

For more on hooks go here: http://headwaythemes.com/documentation/customizing-your-headway-site/using-hooks/

Here are examples of an action and filter.

function an_example_action_function(){
	echo 'This will echo something.';
}
add_action('some_action', 'an_example_action_function');


function an_example_filter_function($content){
	return $content;
}
add_filter('some_filter', 'an_example_filter_function');
*/

