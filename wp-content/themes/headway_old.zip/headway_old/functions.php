<?php
define('HEADWAYROOT', TEMPLATEPATH);
define('HEADWAYLIBRARY', HEADWAYROOT.'/library');
define('HEADWAYADMIN', HEADWAYLIBRARY.'/admin');
define('HEADWAYCORE', HEADWAYLIBRARY.'/core');
define('HEADWAYLEAFS', HEADWAYLIBRARY.'/leafs');
define('HEADWAYWIDGETS', HEADWAYLIBRARY.'/widgets');
define('HEADWAYCUSTOM', HEADWAYROOT.'/custom');
define('HEADWAYSKINS', HEADWAYROOT.'/skins');
define('HEADWAYFOLDER', basename(get_bloginfo('template_url')));

require HEADWAYCORE.'/core-installation.php';
require HEADWAYCORE.'/core-functions.php';

if(is_admin()):
	require HEADWAYADMIN.'/admin.php';
	require HEADWAYCORE.'/core-admin.php';
endif;

require HEADWAYCORE.'/core-navigation.php';
require HEADWAYCORE.'/core-data-handling.php';
require HEADWAYCORE.'/core-posts.php';
require HEADWAYCORE.'/core-filters-actions.php';
require HEADWAYCORE.'/core-layout.php';
require HEADWAYCORE.'/core-head.php';
require HEADWAYCORE.'/core-css-classes.php';
require HEADWAYCORE.'/core-comments.php';
require HEADWAYCORE.'/core-twitter.php';
require HEADWAYCORE.'/core-skins.php';
require HEADWAYCORE.'/core-leafs.php';
require HEADWAYCORE.'/core-additional.php';

require HEADWAYWIDGETS.'/functions.php';