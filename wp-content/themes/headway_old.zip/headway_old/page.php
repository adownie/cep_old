<?php get_header() ?>

	<div id="container" class="clearfix">
	<?php chgfontsize_display_options(); ?>
		<?php get_page_leafs() ?>
				

	</div><!-- #container -->
 

<?php get_footer() ?>