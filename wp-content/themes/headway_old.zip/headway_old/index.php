<?php get_header() ?>

	<div id="container" class="clearfix">

			<?php get_system_page_leafs('index'); ?>

	</div><!-- #container -->

<?php get_footer() ?>